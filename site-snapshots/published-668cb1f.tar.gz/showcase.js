"use strict";(()=>{var Hp=Object.create;var Ws=Object.defineProperty;var Bp=Object.getOwnPropertyDescriptor;var Vp=Object.getOwnPropertyNames;var Up=Object.getPrototypeOf,Wp=Object.prototype.hasOwnProperty;var ma=(e,n,t)=>()=>{if(t)throw t[0];try{return e&&(n=e(e=0)),n}catch(o){throw t=[o],o}};var Je=(e,n)=>()=>{try{return n||e((n={exports:{}}).exports,n),n.exports}catch(t){throw n=0,t}};var Gp=(e,n,t,o)=>{if(n&&typeof n=="object"||typeof n=="function")for(let i of Vp(n))!Wp.call(e,i)&&i!==t&&Ws(e,i,{get:()=>n[i],enumerable:!(o=Bp(n,i))||o.enumerable});return e};var ke=(e,n,t)=>(t=e!=null?Hp(Up(e)):{},Gp(n||!e||!e.__esModule?Ws(t,"default",{value:e,enumerable:!0}):t,e));var F,E=ma(()=>{F={schemaVersion:1,baseline:"Mushroom v5.2.3",commit:"d8a90ffff1b217fbbf9cb8210ee672be99596231",states:{"sensor.parity":{state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}},"light.parity":{state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}},"fan.parity":{state:"on",attributes:{friendly_name:"Island fan",percentage:50,percentage_step:10,oscillating:!0,direction:"forward",preset_modes:["auto","sleep"],preset_mode:"auto",supported_features:63}},"cover.parity":{state:"open",attributes:{friendly_name:"Island cover",current_position:60,current_tilt_position:40,supported_features:255}},"climate.parity":{state:"heat",attributes:{friendly_name:"Island climate",temperature:22,current_temperature:21,hvac_modes:["off","heat","cool","auto"],min_temp:7,max_temp:35,target_temp_step:.5,supported_features:1}},"humidifier.parity":{state:"on",attributes:{friendly_name:"Island humidifier",humidity:50,min_humidity:20,max_humidity:80,available_modes:["auto","normal"],mode:"auto",supported_features:1}},"lock.parity":{state:"locked",attributes:{friendly_name:"Island lock",supported_features:1}},"alarm_control_panel.parity":{state:"disarmed",attributes:{friendly_name:"Island alarm",supported_features:63,code_arm_required:!1}},"media_player.parity":{state:"playing",attributes:{friendly_name:"Island player",media_title:"Island song",media_artist:"K.K.",volume_level:.4,is_volume_muted:!1,shuffle:!1,repeat:"off",supported_features:1048575}},"number.parity":{state:"4",attributes:{friendly_name:"Island number",min:0,max:10,step:.5,mode:"slider"}},"select.parity":{state:"Spring",attributes:{friendly_name:"Island season",options:["Spring","Summer","Autumn","Winter"]}},"person.parity":{state:"home",attributes:{friendly_name:"Island villager"}},"update.parity":{state:"on",attributes:{friendly_name:"Island update",installed_version:"1.0",latest_version:"1.1",in_progress:!1,supported_features:1}},"vacuum.parity":{state:"docked",attributes:{friendly_name:"Island vacuum",battery_level:80,fan_speed:"normal",fan_speed_list:["quiet","normal","turbo"],supported_features:8191}},"weather.parity":{state:"sunny",attributes:{friendly_name:"Island weather",temperature:22,temperature_unit:"\xB0C",humidity:40}}},shared:{entity_keys:["entity","name","icon"],appearance_keys:["layout","fill_container","primary_info","secondary_info","icon_type"],action_keys:["tap_action","hold_action","double_tap_action"],host_card_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility"],layout:["default","vertical","horizontal"],infos:["name","state","last-changed","last-updated","none"],icon_types:["icon","entity-picture","none"],name_values:["string",{type:"entity"},{type:"device"},{type:"area"},{type:"floor"},{type:"text",text:"custom"},"ordered array of NameItem"],actions:["none","toggle","more-info","call-service","perform-action","url","navigate","assist","fire-dom-event"],action_event:{name:"hass-action",detail:"{config, action: tap|hold|double_tap}",source:"src/ha/panels/lovelace/common/handle-actions.ts",ownership:"HA host executes action and confirmation. Component must forward the full config without losing fields."},action_fields:["confirmation","url_path","service","perform_action","service_data","data","target.entity_id","target.device_id","target.area_id","target.floor_id","target.label_id","navigation_path","pipeline_id","start_listening","custom fire-dom-event payload"],template_protocol:{type:"render_template",params:["template","entity_ids","variables","strict:true"],result:["result","listeners.all","listeners.domains","listeners.entities","listeners.time"],source:"src/ha/data/ws-templates.ts",lifecycle:["subscribe only templated keys","cache rendered results","unsubscribe config-key/entity changes","unsubscribe disconnectedCallback","retry after reconnect","handle template_error/not_found gracefully","do not evaluate Jinja as JavaScript"]},required_host_dependencies:["hass.states and attributes","hass.callService","hass.connection.subscribeMessage","hass.localize/locale/config units","hass.entities/devices/areas/floors for structured names","hass.themes/darkMode","hass.user","hass.hassUrl","window.loadCardHelpers","ha-form/selectors","native action-handler and hass-action","hui-card-features and editor","hui-conditional-base","customCards/customBadges registry"],default_actions:{traditional_base:{tap:"more-info",hold:"more-info",double_tap:"not set"},"climate/cover/fan/humidifier/light":{tap:"toggle",hold:"more-info",double_tap:"not set"},"light/template chips":{tap:"toggle",hold:"more-info",double_tap:"not set"},"template badge":{tap:"none"},title:{title_tap:"none",subtitle_tap:"none"}}},source_conflicts:[{id:"docs-humidifier-tap",finding:"Docs say more-info; runtime overrides tap to toggle. Follow runtime for behavioral parity.",source:"src/cards/humidifier-card/humidifier-card.ts"},{id:"docs-alarm-states",finding:"Docs default [armed_home,armed_away] is getStubConfig output, not unconditional runtime default. setConfig without states has no configured arm controls.",source:"src/cards/alarm-control-panel-card/alarm-control-panel-card.ts"},{id:"docs-template-actions",finding:"Docs generic defaults none; runtime entity present injects card more-info and domain-dependent icon toggle.",source:"src/cards/template-card/template-card.ts"},{id:"docs-template-inline",finding:"Docs say only first inline feature; v5.2.3 runtime renders remaining below on HA >=2026.9.",source:"src/cards/template-card/template-card.ts"},{id:"docs-title-schema",finding:"entity_id documented and runtime used, but omitted in TS config struct/editor; alignment supported by source/editor but absent docs table.",source:"src/cards/title-card/title-card-config.ts"},{id:"docs-name-type",finding:"Docs call name a string; source supports entity/device/area/floor/text NameItem or arrays.",source:"src/shared/config/entity-config.ts"},{id:"docs-vacuum-on-off",finding:"Source includes on_off command, omitted docs table list.",source:"src/cards/vacuum-card/vacuum-card-config.ts"},{id:"docs-double-tap-default",finding:"Many docs say default more-info; base setConfig only assigns tap/hold. Double-tap config absent and action-handler only enables detection when configured. Preserve runtime and test in HA.",source:"src/utils/base-card.ts"},{id:"legacy-excluded",finding:"Legacy Template exists as 19th card import but excluded from required18; new Template still migrates legacy-shaped config.",source:"src/mushroom.ts"},{id:"conditional-host",finding:"Current conditional-chip extends actual hui-conditional-base, so old checkConditionsMet helper is not complete condition support.",source:"src/cards/chips-card/chips/conditional-chip.ts"},{id:"chips-title-grid",finding:"Chips and Title have no getGridOptions implementation in v5.2.3. Do not falsely attribute 6x1 default method to upstream.",source:"src/cards/chips-card/chips-card.ts"}],cases:[{id:"card:alarm-control-panel",kind:"card",name:"alarm-control-panel",type:"custom:mushroom-alarm-control-panel-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/alarm-control-panel-card/alarm-control-panel-card.ts",source_path:"src/cards/alarm-control-panel-card/alarm-control-panel-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/alarm-control-panel-card/alarm-control-panel-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","states"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Alarm control panel entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"states",type:"list",documented_default:'`["armed_home", "armed_away"]`',description:"List of arm states to display"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/alarm-control-panel-card/alarm-control-panel-card-editor.ts",editor_named_fields:["entity","icon","states","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return Boolean(this._config?.states?.length);
  }`,priority:3,domains:["alarm_control_panel"],controls:["states"],services:["alarm_control_panel.alarm_arm_home","alarm_control_panel.alarm_arm_away","alarm_control_panel.alarm_arm_night","alarm_control_panel.alarm_arm_vacation","alarm_control_panel.alarm_arm_custom_bypass","alarm_control_panel.alarm_disarm"],states:["disarmed","armed_home","armed_away","armed_night","armed_vacation","armed_custom_bypass","arming","pending","triggered"],details:["states is selected arm-mode list; supported feature bits filter actual actions; disarm is contextual.","Required code uses extended entity registry default_code check and HA showEnterCodeDialog; cancelling must not call service.","Arming/pending/triggered colors and pulse; unsupported/unavailable modes must not execute."],original_config:{type:"custom:mushroom-alarm-control-panel-card",entity:"alarm_control_panel.parity",states:["armed_home","armed_away","armed_night","armed_vacation","armed_custom_bypass"]},island_config:{type:"custom:island-alarm-control-panel-card",entity:"alarm_control_panel.parity",states:["armed_home","armed_away","armed_night","armed_vacation","armed_custom_bypass"]},initial_state:"disarmed",grid:{columns:6,rows:"auto"}},{id:"card:chips",kind:"card",name:"chips",type:"custom:mushroom-chips-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips-card.ts",source_path:"src/cards/chips-card/chips-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips-card.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","chips","alignment"],documented_options:[{name:"alignment",type:"string",documented_default:"Optional",description:"Chips alignment (`end`, `center`, `justify`), when empty default behavior is `start`"},{name:"chips",type:"chip array",documented_default:"Optional",description:"Custom icon"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips-card-editor.ts",editor_named_fields:[],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/cards/chips-card/chips-card.ts",sizing:{getCardSize:`getCardSize(): number | Promise<number> {
    return 1;
  }`,getGridOptions:null,getLayoutOptions:null},controls_predicate:null,priority:2,domains:[],controls:["11 nested chip types","add/edit/reorder/remove nested configs","alignment start/center/end/justify"],services:[],states:["empty chips","single chip","all 11","wrapping","RTL","preview/editMode"],details:["Container propagates hass/preview/editMode to all children; conditional chip preview remains visible.","Use official 11-value CHIP_LIST; no invented chip substitutes."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}},{type:"alarm-control-panel",entity:"alarm_control_panel.parity"},{type:"back"},{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}},{type:"entity",entity:"sensor.parity"},{type:"light",entity:"light.parity"},{type:"menu"},{type:"quickbar"},{type:"spacer"},{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"},{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0}]},island_config:{type:"custom:island-chips-card",chips:[{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}},{type:"alarm-control-panel",entity:"alarm_control_panel.parity"},{type:"back"},{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}},{type:"entity",entity:"sensor.parity"},{type:"light",entity:"light.parity"},{type:"menu"},{type:"quickbar"},{type:"spacer"},{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"},{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0}]},initial_state:"configured",grid:null},{id:"card:climate",kind:"card",name:"climate",type:"custom:mushroom-climate-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/climate-card/climate-card.ts",source_path:"src/cards/climate-card/climate-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/climate-card/climate-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","show_temperature_control","hvac_modes","collapsible_controls"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Climate entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"hvac_modes",type:"list",documented_default:"`[]`",description:"List of hvac modes to display (auto, heat_cool, heat, cool, dry, fan_only, off)"},{name:"show_temperature_control",type:"boolean",documented_default:"`false`",description:"Show buttons to control target temperature"},{name:"collapsible_controls",type:"boolean",documented_default:"`false`",description:"Collapse controls when off. When used in section, it can produce a layout shift for cards below"},{name:"tap_action",type:"action",documented_default:"`toggle`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/climate-card/climate-card-editor.ts",editor_named_fields:["entity","icon","hvac_modes","show_temperature_control","collapsible_controls","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return this._controls.length > 0;
  }`,priority:2,domains:["climate"],controls:["show_temperature_control","hvac_modes","collapsible_controls"],services:["climate.set_temperature:temperature","climate.set_temperature:target_temp_low,target_temp_high","climate.set_hvac_mode:hvac_mode"],states:["off","heat","cool","heat_cool","auto","dry","fan_only"],details:["Intersect configured hvac_modes with entity attributes.hvac_modes and sort with upstream helper.","Temperature single target versus low/high range; respect min_temp/max_temp/target_temp_step and unit-specific default step.","Configured temperature and modes are switchable controls, not simultaneous invented controls."],original_config:{type:"custom:mushroom-climate-card",entity:"climate.parity",show_temperature_control:!0,hvac_modes:["off","heat","cool","auto"],collapsible_controls:!1},island_config:{type:"custom:island-climate-card",entity:"climate.parity",show_temperature_control:!0,hvac_modes:["off","heat","cool","auto"],collapsible_controls:!1},initial_state:"heat",grid:{columns:6,rows:"auto"}},{id:"card:cover",kind:"card",name:"cover",type:"custom:mushroom-cover-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/cover-card/cover-card.ts",source_path:"src/cards/cover-card/cover-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/cover-card/cover-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","show_buttons_control","show_position_control","show_tilt_position_control"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Cover entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"show_buttons_control",type:"boolean",documented_default:"`false`",description:"Show buttons to open, close and stop cover"},{name:"show_position_control",type:"boolean",documented_default:"`false`",description:"Show a slider to control position of the cover"},{name:"show_tilt_position_control",type:"boolean",documented_default:"`false`",description:"Show a slider to control tilt position of the cover"},{name:"tap_action",type:"action",documented_default:"`toggle`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/cover-card/cover-card-editor.ts",editor_named_fields:["entity","icon","show_position_control","show_tilt_position_control","show_buttons_control","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`getCardSize(): number | Promise<number> {
    return 1;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return this._controls.length > 0;
  }`,priority:2,domains:["cover"],controls:["show_buttons_control","show_position_control","show_tilt_position_control"],services:["cover.open_cover","cover.close_cover","cover.stop_cover","cover.set_cover_position:position","cover.set_cover_tilt_position:tilt_position"],states:["open","closed","opening","closing"],details:["Set-position and set-tilt require respective feature bits; buttons visible/disabled per supported features and motion/end state.","assumed_state permits commands otherwise disabled at end states.","Cycle available button/position/tilt modes; 0\u2013100 positions; device_class-specific icons."],original_config:{type:"custom:mushroom-cover-card",entity:"cover.parity",show_buttons_control:!0,show_position_control:!0,show_tilt_position_control:!0},island_config:{type:"custom:island-cover-card",entity:"cover.parity",show_buttons_control:!0,show_position_control:!0,show_tilt_position_control:!0},initial_state:"open",grid:{columns:6,rows:"auto"}},{id:"card:empty",kind:"card",name:"empty",type:"custom:mushroom-empty-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/empty-card/empty-card.ts",source_path:"src/cards/empty-card/empty-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/empty-card/empty-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/empty-card/empty-card-editor.ts",editor_named_fields:["description"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/cards/empty-card/empty-card.ts",sizing:{getCardSize:`public getCardSize(): number {
    return 1;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    return {
      rows: 1,
      columns: 6,
    };
  }`,getLayoutOptions:null},controls_predicate:null,priority:1,domains:[],controls:[],services:[],states:["normal invisible spacer","preview dotted placeholder"],details:["No semantic actions or entity; preserve spacing and preview behavior."],original_config:{type:"custom:mushroom-empty-card"},island_config:{type:"custom:island-empty-card"},initial_state:"configured",grid:{columns:6,rows:"auto"}},{id:"card:entity",kind:"card",name:"entity",type:"custom:mushroom-entity-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/entity-card/entity-card.ts",source_path:"src/cards/entity-card/entity-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/entity-card/entity-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","icon_color"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"icon_color",type:"string",documented_default:"`blue`",description:"Custom color for icon when entity is state is active"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/entity-card/entity-card-editor.ts",editor_named_fields:["entity","icon","icon_color","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:"false (inherited)",priority:1,domains:["any"],controls:[],services:[],states:["active","inactive","timestamp","numeric unit","unknown","unavailable"],details:["Supports any entity domain using HA formatting, entity pictures, native icons, relative time.","name accepts string, {type: entity/device/area/floor}, {type:text,text}, or ordered array of these."],original_config:{type:"custom:mushroom-entity-card",entity:"sensor.parity"},island_config:{type:"custom:island-entity-card",entity:"sensor.parity"},initial_state:"21",grid:{columns:6,rows:"auto"}},{id:"card:fan",kind:"card",name:"fan",type:"custom:mushroom-fan-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/fan-card/fan-card.ts",source_path:"src/cards/fan-card/fan-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/fan-card/fan-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","icon_animation","show_percentage_control","show_oscillate_control","show_direction_control","collapsible_controls"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Fan entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"icon_animation",type:"boolean",documented_default:"`false`",description:"Animate the icon when fan is `on`"},{name:"show_percentage_control",type:"boolean",documented_default:"`false`",description:"Show a slider to control speed"},{name:"show_oscillate_control",type:"boolean",documented_default:"`false`",description:"Show a button to control oscillation"},{name:"show_direction_control",type:"boolean",documented_default:"`false`",description:"Show a button to control direction"},{name:"collapsible_controls",type:"boolean",documented_default:"`false`",description:"Collapse controls when off. When used if section, it can produce a layout shift for cards below"},{name:"tap_action",type:"action",documented_default:"`toggle`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/fan-card/fan-card-editor.ts",editor_named_fields:["entity","icon","icon_animation","show_percentage_control","show_oscillate_control","show_direction_control","collapsible_controls","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return (
      Boolean(this._config?.show_percentage_control) ||
      Boolean(this._config?.show_oscillate_control) ||
      Boolean(this._config?.show_direction_control)
    );
  }`,priority:2,domains:["fan"],controls:["show_percentage_control","show_oscillate_control","show_direction_control","icon_animation","collapsible_controls"],services:["fan.set_percentage:percentage","fan.oscillate:oscillating","fan.set_direction:direction"],states:["on","off","oscillating true/false","direction forward/reverse"],details:["percentage_step and supported_features determine speed behavior; direction/oscillation controls are disabled when inactive.","Animate only configured icon_animation and active; respect reduced motion where applicable."],original_config:{type:"custom:mushroom-fan-card",entity:"fan.parity",show_percentage_control:!0,show_oscillate_control:!0,show_direction_control:!0,collapsible_controls:!1},island_config:{type:"custom:island-fan-card",entity:"fan.parity",show_percentage_control:!0,show_oscillate_control:!0,show_direction_control:!0,collapsible_controls:!1},initial_state:"on",grid:{columns:6,rows:"auto"}},{id:"card:humidifier",kind:"card",name:"humidifier",type:"custom:mushroom-humidifier-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/humidifier-card/humidifier-card.ts",source_path:"src/cards/humidifier-card/humidifier-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/humidifier-card/humidifier-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","show_target_humidity_control","collapsible_controls"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Humidifier entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"show_target_humidity_control",type:"boolean",documented_default:"Optional",description:"Show target humidity control"},{name:"collapsible_controls",type:"boolean",documented_default:"`false`",description:"Collapse controls when off. When used in section, it can produce a layout shift for cards below"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/humidifier-card/humidifier-card-editor.ts",editor_named_fields:["entity","icon","show_target_humidity_control","collapsible_controls","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return Boolean(this._config?.show_target_humidity_control);
  }`,priority:2,domains:["humidifier"],controls:["show_target_humidity_control","collapsible_controls"],services:["humidifier.set_humidity:humidity"],states:["on","off","humidifying","dehumidifying"],details:["Use humidity/current_humidity/min_humidity/max_humidity; target slider is not a temperature slider.","Runtime tap default is toggle, despite docs table saying more-info."],original_config:{type:"custom:mushroom-humidifier-card",entity:"humidifier.parity",show_target_humidity_control:!0,collapsible_controls:!1},island_config:{type:"custom:island-humidifier-card",entity:"humidifier.parity",show_target_humidity_control:!0,collapsible_controls:!1},initial_state:"on",grid:{columns:6,rows:"auto"}},{id:"card:light",kind:"card",name:"light",type:"custom:mushroom-light-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/light-card/light-card.ts",source_path:"src/cards/light-card/light-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/light-card/light-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","icon_color","show_brightness_control","show_color_temp_control","show_color_control","collapsible_controls","use_light_color"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Light entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"icon_color",type:"string",documented_default:"`blue`",description:"Custom color for icon and brightness bar when the lights is on and `use_light_color` is `false`"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"show_brightness_control",type:"boolean",documented_default:"`false`",description:"Show a slider to control brightness"},{name:"show_color_temp_control",type:"boolean",documented_default:"`false`",description:"Show a slider to control temperature color"},{name:"show_color_control",type:"boolean",documented_default:"`false`",description:"Show a slider to control RGB color"},{name:"collapsible_controls",type:"boolean",documented_default:"`false`",description:"Collapse controls when off. When used in section, it can produce a layout shift for cards below"},{name:"use_light_color",type:"boolean",documented_default:"`false`",description:"Colorize the icon and slider according light temperature or color"},{name:"tap_action",type:"action",documented_default:"`toggle`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/light-card/light-card-editor.ts",editor_named_fields:["entity","icon","icon_color","use_light_color","show_brightness_control","show_color_temp_control","show_color_control","collapsible_controls","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return this._controls.length > 0;
  }`,priority:2,domains:["light"],controls:["show_brightness_control","show_color_temp_control","show_color_control","use_light_color","collapsible_controls"],services:["light.turn_on:brightness_pct","light.turn_on:color_temp_kelvin","light.turn_on:rgb_color"],states:["on","off","brightness 0/1/128/255","color_temp","rgb","hs","xy","rgbw","rgbww","onoff-only"],details:["Three switchable controls filtered by supported_color_modes, not just supported_features.","Brightness commits percent 0\u2013100, not raw 0\u2013255; live UI may reflect local value pending hass update.","Temperature service is color_temp_kelvin with Kelvin bounds and compatibility conversion from old mired attributes.","Color is upstream rainbow slider converted to rgb_color; use_light_color controls icon and slider color."],original_config:{type:"custom:mushroom-light-card",entity:"light.parity",show_brightness_control:!0,show_color_temp_control:!0,show_color_control:!0,collapsible_controls:!1,use_light_color:!0},island_config:{type:"custom:island-light-card",entity:"light.parity",show_brightness_control:!0,show_color_temp_control:!0,show_color_control:!0,collapsible_controls:!1,use_light_color:!0},initial_state:"on",grid:{columns:6,rows:"auto"}},{id:"card:lock",kind:"card",name:"lock",type:"custom:mushroom-lock-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/lock-card/lock-card.ts",source_path:"src/cards/lock-card/lock-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/lock-card/lock-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Lock entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/lock-card/lock-card-editor.ts",editor_named_fields:["entity","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return true;
  }`,priority:3,domains:["lock"],controls:["contextual lock/unlock/open buttons"],services:["lock.lock","lock.unlock","lock.open"],states:["locked","unlocked","locking","unlocking","jammed","open","opening"],details:["No show_buttons_control option: controls always exist in sizing; actual button visibility is state/feature-based.","open requires OPEN feature; lock/unlock disable transitions/end state.","Device-effect tests use fake callService or isolated demo HA; never unlock a real door for testing."],original_config:{type:"custom:mushroom-lock-card",entity:"lock.parity"},island_config:{type:"custom:island-lock-card",entity:"lock.parity"},initial_state:"locked",grid:{columns:6,rows:"auto"}},{id:"card:media-player",kind:"card",name:"media-player",type:"custom:mushroom-media-player-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/media-player-card/media-player-card.ts",source_path:"src/cards/media-player-card/media-player-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/media-player-card/media-player-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","use_media_info","show_volume_level","volume_controls","media_controls","collapsible_controls"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Media Player entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"use_media_info",type:"boolean",documented_default:"`false`",description:"Use media info instead of name, state and icon when a media is playing"},{name:"show_volume_level",type:"boolean",documented_default:"`false`",description:"Show volume level next to media state when media is playing"},{name:"media_controls",type:"list",documented_default:"`[]`",description:"List of controls to display (on_off, shuffle, previous, play_pause_stop, next, repeat)"},{name:"volume_controls",type:"list",documented_default:"`[]`",description:"List of controls to display (volume_mute, volume_set, volume_buttons)"},{name:"collapsible_controls",type:"boolean",documented_default:"`false`",description:"Collapse controls when off. When used in section, it can produce a layout shift for cards below"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/media-player-card/media-player-card-editor.ts",editor_named_fields:["entity","icon","use_media_info","show_volume_level","volume_controls","media_controls","collapsible_controls","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return (
      Boolean(this._config?.media_controls?.length) ||
      Boolean(this._config?.volume_controls?.length)
    );
  }`,priority:2,domains:["media_player"],controls:["media_controls: on_off,shuffle,previous,play_pause_stop,next,repeat","volume_controls: volume_mute,volume_set,volume_buttons","use_media_info","show_volume_level","collapsible_controls"],services:["media_player.turn_on","media_player.turn_off","media_player.media_play","media_player.media_pause","media_player.media_stop","media_player.media_play_pause","media_player.media_next_track","media_player.media_previous_track","media_player.shuffle_set:shuffle","media_player.repeat_set:repeat","media_player.volume_set:volume_level","media_player.volume_mute:is_volume_muted","media_player.volume_up","media_player.volume_down"],states:["off","on","idle","standby","playing","paused","buffering","muted","shuffle on/off","repeat off/all/one"],details:["Controls selected by config AND supported feature bits; distinct pause/stop/play fallbacks.","repeat cycles off/all/one; shuffle toggles boolean. Volume is 0\u20131 API versus 0\u2013100 UI.","media title/artist/content type/artwork are displayed only per use_media_info and playback; preserve normal name fallback."],original_config:{type:"custom:mushroom-media-player-card",entity:"media_player.parity",use_media_info:!0,show_volume_level:!0,volume_controls:["volume_mute","volume_set","volume_buttons"],media_controls:["on_off","shuffle","previous","play_pause_stop","next","repeat"],collapsible_controls:!1},island_config:{type:"custom:island-media-player-card",entity:"media_player.parity",use_media_info:!0,show_volume_level:!0,volume_controls:["volume_mute","volume_set","volume_buttons"],media_controls:["on_off","shuffle","previous","play_pause_stop","next","repeat"],collapsible_controls:!1},initial_state:"playing",grid:{columns:6,rows:"auto"}},{id:"card:number",kind:"card",name:"number",type:"custom:mushroom-number-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/number-card/number-card.ts",source_path:"src/cards/number-card/number-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/number-card/number-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","icon_color","display_mode"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Number or input_number Entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"icon_color",type:"string",documented_default:"`blue`",description:"Custom color for icon when entity state is active"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"display_mode",type:"`slider` `buttons`",documented_default:"`slider`",description:"Type of control to display (button or slider)"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/number-card/number-card-editor.ts",editor_named_fields:["entity","icon","icon_color","display_mode","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return true;
  }`,priority:2,domains:["number","input_number"],controls:["display_mode slider/buttons"],services:["number.set_value:value","input_number.set_value:value"],states:["min","max","fractional step","negative range"],details:["Resolve service domain from entity_id; honor min/max/step/unit; invalid/unknown/unavailable disables.","Buttons and slider must produce same quantized value; getCardSize includes controls by default."],original_config:{type:"custom:mushroom-number-card",entity:"number.parity"},island_config:{type:"custom:island-number-card",entity:"number.parity"},initial_state:"4",grid:{columns:6,rows:"auto"}},{id:"card:person",kind:"card",name:"person",type:"custom:mushroom-person-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/person-card/person-card.ts",source_path:"src/cards/person-card/person-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/person-card/person-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Person entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/person-card/person-card-editor.ts",editor_named_fields:["entity","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:"false (inherited)",priority:1,domains:["person"],controls:[],services:[],states:["home","not_home","named zone","unknown","unavailable"],details:["Zone-dependent color and badge, GPS/away/home semantics, entity-picture choice and fallback."],original_config:{type:"custom:mushroom-person-card",entity:"person.parity"},island_config:{type:"custom:island-person-card",entity:"person.parity"},initial_state:"home",grid:{columns:6,rows:"auto"}},{id:"card:select",kind:"card",name:"select",type:"custom:mushroom-select-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/select-card/select-card.ts",source_path:"src/cards/select-card/select-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/select-card/select-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","icon_color"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Select or input_select Entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"icon_color",type:"string",documented_default:"`blue`",description:"Custom color for icon when entity state is active"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/select-card/select-card-editor.ts",editor_named_fields:["entity","icon","icon_color","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls(): boolean {
    return true;
  }`,priority:2,domains:["select","input_select"],controls:["options dropdown"],services:["select.select_option:option","input_select.select_option:option"],states:["valid selected option","missing current option","empty options"],details:["Options derived from entity.attributes.options; service domain follows entity_id.","Native select implementation branches at HA 2026.3; confirm UI works on targeted HA version."],original_config:{type:"custom:mushroom-select-card",entity:"select.parity"},island_config:{type:"custom:island-select-card",entity:"select.parity"},initial_state:"Spring",grid:{columns:6,rows:"auto"}},{id:"card:template",kind:"card",name:"template",type:"custom:mushroom-template-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/template-card/template-card.ts",source_path:"src/cards/template-card/template-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/template-card/template-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","area","primary","secondary","color","icon","picture","badge_icon","badge_text","badge_color","vertical","multiline_secondary","tap_action","hold_action","double_tap_action","icon_tap_action","icon_hold_action","icon_double_tap_action","features","features_position","entity_id","icon_color","layout","fill_container"],documented_options:[{name:"entity",type:"string",documented_default:"Optional",description:"Entity used for templating, actions, and card features."},{name:"area",type:"string",documented_default:"Optional",description:"Area used for templating and card features."},{name:"icon",type:"string",documented_default:"Optional",description:"Icon to display. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"color",type:"string",documented_default:"Optional",description:"Color applied to the icon, background effects, and card features. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"picture",type:"string",documented_default:"Optional",description:"Image to display instead of an icon. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"primary",type:"string",documented_default:"Optional",description:"Primary text (main label). Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"secondary",type:"string",documented_default:"Optional",description:"Secondary text (subtitle or status). Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"badge_icon",type:"string",documented_default:"Optional",description:"Icon displayed as a badge. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"badge_text",type:"string",documented_default:"Optional",description:"Text displayed inside the badge. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"badge_color",type:"string",documented_default:"Optional",description:"Color applied to the badge. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"multiline_secondary",type:"boolean",documented_default:"`false`",description:"If `true`, secondary text can span multiple lines."},{name:"vertical",type:"boolean",documented_default:"`false`",description:"If `true`, displays the icon above the text (vertical layout)."},{name:"tap_action",type:"action",documented_default:"`none`",description:"Action performed when the card is tapped."},{name:"hold_action",type:"action",documented_default:"`none`",description:"Action performed when the card is long-pressed."},{name:"double_tap_action",type:"action",documented_default:"`none`",description:"Action performed when the card is double-tapped."},{name:"icon_tap_action",type:"action",documented_default:"`none`",description:"Action performed when the icon is tapped."},{name:"icon_hold_action",type:"action",documented_default:"`none`",description:"Action performed when the icon is long-pressed."},{name:"icon_double_tap_action",type:"action",documented_default:"`none`",description:"Action performed when the icon is double-tapped."},{name:"features",type:"list",documented_default:"`none`",description:"Card features to display (e.g., controls or extra info)."},{name:"features_position",type:"string",documented_default:"`bottom`",description:"Where features are displayed: `bottom` (below the card) or `inline` (next to content). Note: when using `inline`, only the first feature is shown."},{name:"entity_id",type:"string / list",documented_default:"Optional",description:"Restricts template updates to these entities. Useful if automatic detection misses dependencies."}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/template-card/template-card-editor.ts",editor_named_fields:["context","entity","area","content","primary","secondary","color","icon","picture","badge","badge_icon","badge_text","badge_color","layout","content_layout","multiline_secondary","interactions","tap_action","icon_tap_action","features_position"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/cards/template-card/template-card.ts",sizing:{getCardSize:`public getCardSize(): number {
    const featuresPosition =
      this._config && this._featurePosition(this._config);
    const featureRows = this._config ? this._featureRows(this._config) : 0;

    const hasContent = Boolean(
      this._config?.icon ||
      this._config?.picture ||
      this._config?.primary ||
      this._config?.secondary
    );

    return (
      (hasContent || featuresPosition === "inline" ? 1 : 0) +
      (this._config?.vertical ? 1 : 0) +
      featureRows
    );
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    let columns = 6;
    let rows = 0;

    const hasContent = Boolean(
      this._config?.icon ||
      this._config?.picture ||
      this._config?.primary ||
      this._config?.secondary
    );

    rows = hasContent ? 1 : 0;

    const featurePosition = this._config && this._featurePosition(this._config);
    const featuresCount = this._config?.features?.length || 0;
    if (this._config && featuresCount) {
      if (featurePosition === "inline") {
        columns = 12;
        rows = 1 + this._featureRows(this._config);
      } else {
        rows += featuresCount;
      }
    }

    if (this._config?.vertical) {
      if (
        this._config.primary ||
        (this._config.secondary && !this._config.icon)
      ) {
        rows++;
      }
    }
    if (this._config?.multiline_secondary) {
      return {
        columns,
      };
    }
    return {
      columns,
      rows,
    };
  }`,getLayoutOptions:null},controls_predicate:null,priority:4,domains:["optional any entity","optional area"],controls:["8 templated display fields","6 card/icon actions","native HA card features","features_position bottom/inline","vertical","multiline_secondary","legacy config migration"],services:["render_template subscription","native hui-card-features services delegated by HA","hass-action event"],states:["static/no entity","valid template","render_template rejection","state-triggered update","time-triggered update","disconnect/reconnect","entity/area changes"],details:["New Template is Tile-based, not legacy-template. 8 templated keys: icon,color,primary,secondary,picture,badge_icon,badge_color,badge_text.","Template variables config,user,entity,area; entity_id maps to entity_ids; strict:true. Subscription cleanup and cached values required.","Card tap defaults more-info when entity exists; icon tap defaults toggle for toggle/button/input_button/scene domains, else none.","vertical forces bottom features. With inline, first feature inline; HA >=2026.9 shows remaining features below in at most 2 columns; earlier HA drops remaining features.","Backcompat: icon_color -> color if new key absent, layout -> vertical if new key absent, remove fill_container. Native features cannot be replaced by a few decorative fake buttons."],original_config:{type:"custom:mushroom-template-card",entity:"light.parity",features:[{type:"light-brightness"}],features_position:"bottom",primary:"{{ states('sensor.parity') }}",secondary:"Live server template",icon:"mdi:leaf"},island_config:{type:"custom:island-template-card",entity:"light.parity",features:[{type:"light-brightness"}],features_position:"bottom",primary:"{{ states('sensor.parity') }}",secondary:"Live server template",icon:"mdi:leaf"},initial_state:"on",grid:{columns:6,rows:"auto"}},{id:"card:title",kind:"card",name:"title",type:"custom:mushroom-title-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/title-card/title-card.ts",source_path:"src/cards/title-card/title-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/title-card/title-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","title","subtitle","alignment","title_tap_action","subtitle_tap_action","entity_id"],documented_options:[{name:"title",type:"string",documented_default:"Optional",description:"Title to render. May contain [templates](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"subtitle",type:"string",documented_default:"Optional",description:"Subtitle to render. May contain [templates](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"entity_id",type:"`string` `list`",documented_default:"Optional",description:"Only reacts to the state changes of these entities. This can be used if the automatic analysis fails to find all relevant entities."},{name:"title_tap_action",type:"action",documented_default:"`none`",description:"Home assistant action to perform on title tap"},{name:"subtitle_tap_action",type:"action",documented_default:"`none`",description:"Home assistant action to perform on subtitle tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/title-card/title-card-editor.ts",editor_named_fields:["title","subtitle","alignment","title_tap_action","subtitle_tap_action"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/cards/title-card/title-card.ts",sizing:{getCardSize:`getCardSize(): number | Promise<number> {
    return 1;
  }`,getGridOptions:null,getLayoutOptions:null},controls_predicate:null,priority:1,domains:[],controls:["title/subtitle independently templated and clickable","alignment"],services:["render_template subscription","hass-action event"],states:["title only","subtitle only","both absent","valid Jinja","template error"],details:["Templates supported for title/subtitle; variables config,user; runtime uses entity_id although TS config struct omits it.","Only title_tap_action/subtitle_tap_action are exposed, default none; no card hold/double tap config."],original_config:{type:"custom:mushroom-title-card",title:"Island parity",subtitle:"Same HA, same entities"},island_config:{type:"custom:island-title-card",title:"Island parity",subtitle:"Same HA, same entities"},initial_state:"configured",grid:null},{id:"card:update",kind:"card",name:"update",type:"custom:mushroom-update-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/update-card/update-card.ts",source_path:"src/cards/update-card/update-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/update-card/update-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","show_buttons_control","collapsible_controls"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Update entity"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"show_buttons_control",type:"boolean",documented_default:"`false`",description:"Show buttons to install and skip update"},{name:"collapsible_controls",type:"boolean",documented_default:"`false`",description:"Collapse controls when off. When used in section, it can produce a layout shift for cards below"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/update-card/update-card-editor.ts",editor_named_fields:["entity","icon","show_buttons_control","collapsible_controls","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls() {
    if (!this._stateObj || !this._config) return false;
    return (
      Boolean(this._config.show_buttons_control) &&
      supportsFeature(this._stateObj, UPDATE_SUPPORT_INSTALL)
    );
  }`,priority:3,domains:["update"],controls:["show_buttons_control","collapsible_controls"],services:["update.install","update.skip"],states:["on update available","off current","in_progress boolean","in_progress numeric","skipped_version","latest_version missing"],details:["Install feature flag gates controls; disable install while in progress; skipped latest version can still be installable.","Show version/progress/status correctly; install and skip have separate disabled conditions.","Never install real software to test parity. Use mock calls or isolated HA entities."],original_config:{type:"custom:mushroom-update-card",entity:"update.parity",show_buttons_control:!0,collapsible_controls:!1},island_config:{type:"custom:island-update-card",entity:"update.parity",show_buttons_control:!0,collapsible_controls:!1},initial_state:"on",grid:{columns:6,rows:"auto"}},{id:"card:vacuum",kind:"card",name:"vacuum",type:"custom:mushroom-vacuum-card",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/vacuum-card/vacuum-card.ts",source_path:"src/cards/vacuum-card/vacuum-card.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/vacuum-card/vacuum-card-config.ts",config_keys:["type","index","view_index","view_layout","layout_options","grid_options","visibility","entity","name","icon","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","icon_animation","commands"],documented_options:[{name:"entity",type:"string",documented_default:"Required",description:"Vacuum entity"},{name:"icon",type:"string",documented_default:"Optional",description:"Custom icon"},{name:"name",type:"string",documented_default:"Optional",description:"Custom name"},{name:"layout",type:"string",documented_default:"Optional",description:"Layout of the card. Vertical, horizontal and default layout are supported"},{name:"fill_container",type:"boolean",documented_default:"`false`",description:"Fill container or not. Useful when card is in a grid, vertical or horizontal layout"},{name:"primary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`name`",description:"Info to show as primary info"},{name:"secondary_info",type:"`name` `state` `last-changed` `last-updated` `none`",documented_default:"`state`",description:"Info to show as secondary info"},{name:"icon_type",type:"`icon` `entity-picture` `none`",documented_default:"`icon`",description:"Type of icon to display"},{name:"icon_animation",type:"boolean",documented_default:"`false`",description:"Animate the icon when vacuum is `cleaning`"},{name:"commands",type:"list",documented_default:"`[]`",description:"List of commands to display (start_pause, stop, locate, clean_spot, return_home)"},{name:"tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on tap"},{name:"hold_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on hold"},{name:"double_tap_action",type:"action",documented_default:"`more-info`",description:"Home assistant action to perform on double_tap"}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/vacuum-card/vacuum-card-editor.ts",editor_named_fields:["entity","icon","icon_animation","commands","layout","fill_container","primary_info","secondary_info","icon_type","tap_action","hold_action","double_tap_action","name"],editor_contract:["getConfigElement","setConfig","hass","config-changed"],size_provider:"src/utils/base-card.ts",sizing:{getCardSize:`public getCardSize(): number | Promise<number> {
    let height = 1;
    if (!this._config) return height;
    const appearance = computeAppearance(this._config);
    if (appearance.layout === "vertical") {
      height += 1;
    }
    if (
      appearance?.layout !== "horizontal" &&
      this.hasControls &&
      !(
        "collapsible_controls" in this._config &&
        this._config?.collapsible_controls
      )
    ) {
      height += 1;
    }
    return height;
  }`,getGridOptions:`public getGridOptions(): LovelaceGridOptions {
    if (!this._config) {
      return {
        columns: 6,
        rows: 1,
      };
    }

    const options = {
      min_rows: 1,
      min_columns: 4,
      columns: 6,
      rows: 0, // initial value
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.rows += 1;
      }
      if (hasInfo) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
      options.min_columns = 2;
    }

    if (appearance.layout === "horizontal") {
      options.rows = 1;
      options.columns = 12;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.rows += 1;
      }
      if (hasControls) {
        options.rows += 1;
      }
    }

    // If icon only, set 3x1 for size
    if (!hasControls && !hasInfo) {
      options.columns = 3;
      options.rows = 1;
      options.min_columns = 2;
    }

    // Ensure card has at least 1 row
    options.rows = Math.max(options.rows, 1);
    options.min_rows = options.rows;

    return options;
  }`,getLayoutOptions:`public getLayoutOptions(): LovelaceLayoutOptions {
    if (!this._config) {
      return {
        grid_columns: 2,
        grid_rows: 1,
      };
    }

    const options = {
      grid_columns: 2,
      grid_rows: 0,
    };

    const appearance = computeAppearance(this._config);

    const collapsible_controls =
      "collapsible_controls" in this._config &&
      Boolean(this._config.collapsible_controls);

    const hasInfo =
      appearance.primary_info !== "none" ||
      appearance.secondary_info !== "none";
    const hasIcon = appearance.icon_type !== "none";
    const active = this._stateObj && isActive(this._stateObj);

    const hasControls = this.hasControls && (!collapsible_controls || active);

    if (appearance.layout === "vertical") {
      if (hasIcon) {
        options.grid_rows += 1;
      }
      if (hasInfo) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    if (appearance.layout === "horizontal") {
      options.grid_rows = 1;
      options.grid_columns = 4;
    }

    if (appearance.layout === "default") {
      if (hasInfo || hasIcon) {
        options.grid_rows += 1;
      }
      if (hasControls) {
        options.grid_rows += 1;
      }
    }

    // If icon only, set 1x1 for size
    if (!hasControls && !hasInfo) {
      options.grid_columns = 1;
      options.grid_rows = 1;
    }

    // Ensure card has at least 1 row
    options.grid_rows = Math.max(options.grid_rows, 1);

    return options;
  }`},controls_predicate:`protected get hasControls() {
    if (!this._stateObj || !this._config) return false;
    return isCommandsControlSupported(
      this._stateObj,
      this._config.commands ?? []
    );
  }`,priority:2,domains:["vacuum"],controls:["commands on_off/start_pause/stop/locate/clean_spot/return_home","icon_animation"],services:["vacuum.turn_on","vacuum.turn_off","vacuum.start","vacuum.pause","vacuum.start_pause","vacuum.stop","vacuum.locate","vacuum.clean_spot","vacuum.return_to_base"],states:["cleaning","docked","idle","paused","returning","error","on","off"],details:["on_off is supported by source though omitted in docs list; API return_home maps to return_to_base.","If START supported use start or pause; if only PAUSE supported use start_pause fallback.","Each button capability/state visibility differs; animate only cleaning when configured."],original_config:{type:"custom:mushroom-vacuum-card",entity:"vacuum.parity",commands:["on_off","start_pause","stop","locate","clean_spot","return_home"]},island_config:{type:"custom:island-vacuum-card",entity:"vacuum.parity",commands:["on_off","start_pause","stop","locate","clean_spot","return_home"]},initial_state:"docked",grid:{columns:6,rows:"auto"}},{id:"chip:action",kind:"chip",name:"action",type:"action",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/action-chip.ts",source_path:"src/cards/chips-card/chips/action-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","icon","icon_color","tap_action","hold_action","double_tap_action"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/action-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:[],controls:[],services:[],states:["configured","preview/editMode","RTL"],details:["No entity required. Icon and icon_color plus all 3 configured actions; do not invent a default entity."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}}]},island_config:{type:"custom:island-chips-card",chips:[{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}}]},initial_state:"configured",grid:null},{id:"chip:alarm-control-panel",kind:"chip",name:"alarm-control-panel",type:"alarm-control-panel",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/alarm-control-panel-chip.ts",source_path:"src/cards/chips-card/chips/alarm-control-panel-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","entity","name","content_info","icon","icon_color","tap_action","hold_action","double_tap_action"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/alarm-control-panel-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:["optional entity"],controls:[],services:[],states:["configured","preview/editMode","RTL","unknown","unavailable","not_found"],details:["Alarm-specific icon/color/pulse and content_info; no embedded alarm-control buttons."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"alarm-control-panel",entity:"alarm_control_panel.parity"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"alarm-control-panel",entity:"alarm_control_panel.parity"}]},initial_state:"configured",grid:null},{id:"chip:back",kind:"chip",name:"back",type:"back",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/back-chip.ts",source_path:"src/cards/chips-card/chips/back-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","icon"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/back-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:[],controls:[],services:[],states:["configured","preview/editMode","RTL"],details:["window.history.back(); custom icon only. No generic tap/hold/double action config."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"back"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"back"}]},initial_state:"configured",grid:null},{id:"chip:conditional",kind:"chip",name:"conditional",type:"conditional",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/conditional-chip.ts",source_path:"src/cards/chips-card/chips/conditional-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","chip","conditions"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/conditional-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:4,domains:[],controls:[],services:[],states:["configured","preview/editMode","RTL"],details:["Extends real HA hui-conditional-base loaded with loadCardHelpers. Full HA condition dialect follows host version, not merely entity/state/state_not helper.","conditions + nested chip required; invalid/missing chip throws; editor/preview visibility; preserve recursive nested config."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}}]},island_config:{type:"custom:island-chips-card",chips:[{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}}]},initial_state:"configured",grid:null},{id:"chip:entity",kind:"chip",name:"entity",type:"entity",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/entity-chip.ts",source_path:"src/cards/chips-card/chips/entity-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","entity","name","content_info","icon","icon_color","use_entity_picture","tap_action","hold_action","double_tap_action"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/entity-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:["optional entity"],controls:[],services:[],states:["configured","preview/editMode","RTL","unknown","unavailable","not_found"],details:["content_info name/state/last-changed/last-updated/none; use_entity_picture, icon_color, structured name; timestamp formatting."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"entity",entity:"sensor.parity"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"entity",entity:"sensor.parity"}]},initial_state:"configured",grid:null},{id:"chip:light",kind:"chip",name:"light",type:"light",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/light-chip.ts",source_path:"src/cards/chips-card/chips/light-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","entity","name","content_info","icon","use_light_color","hold_action","tap_action","double_tap_action"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/light-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:["optional entity"],controls:[],services:[],states:["configured","preview/editMode","RTL","unknown","unavailable","not_found"],details:["Default tap toggle/hold more-info; use_light_color; content_info; no generic icon_color in official config."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"light",entity:"light.parity"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"light",entity:"light.parity"}]},initial_state:"configured",grid:null},{id:"chip:menu",kind:"chip",name:"menu",type:"menu",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/menu-chip.ts",source_path:"src/cards/chips-card/chips/menu-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","icon"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/menu-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:[],controls:[],services:[],states:["configured","preview/editMode","RTL"],details:["Fires hass-toggle-menu event; custom icon. Verify mobile drawer with real HA."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"menu"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"menu"}]},initial_state:"configured",grid:null},{id:"chip:quickbar",kind:"chip",name:"quickbar",type:"quickbar",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/quickbar-chip.ts",source_path:"src/cards/chips-card/chips/quickbar-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","icon","mode"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/quickbar-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:[],controls:[],services:[],states:["configured","preview/editMode","RTL"],details:["mode entity default -> KeyboardEvent key e; device -> d; command -> c; bubbles/composed true. Must actually open HA quickbar."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"quickbar"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"quickbar"}]},initial_state:"configured",grid:null},{id:"chip:spacer",kind:"chip",name:"spacer",type:"spacer",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/spacer-chip.ts",source_path:"src/cards/chips-card/chips/spacer-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type"],documented_options:[],editor_source:null,editor_contract:[],sizing:{},priority:2,domains:[],controls:[],services:[],states:["configured","preview/editMode","RTL"],details:["Only type; host flex-grow:1; no editor or actions required."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"spacer"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"spacer"}]},initial_state:"configured",grid:null},{id:"chip:template",kind:"chip",name:"template",type:"template",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/template-chip.ts",source_path:"src/cards/chips-card/chips/template-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","entity","hold_action","tap_action","double_tap_action","content","icon","icon_color","picture","entity_id"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/template-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:3,domains:["optional entity"],controls:[],services:[],states:["configured","preview/editMode","RTL","unknown","unavailable","not_found"],details:["4 templated keys content,icon,icon_color,picture; variables config,user,entity; entity_id watcher filter.","Defaults tap toggle, hold more-info; template lifecycle and weather-* SVG icons."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"}]},island_config:{type:"custom:island-chips-card",chips:[{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"}]},initial_state:"configured",grid:null},{id:"chip:weather",kind:"chip",name:"weather",type:"weather",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/weather-chip.ts",source_path:"src/cards/chips-card/chips/weather-chip.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/utils/lovelace/chip/types.ts",config_keys:["type","entity","tap_action","hold_action","double_tap_action","show_temperature","show_conditions"],documented_options:[],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/cards/chips-card/chips/weather-chip-editor.ts",editor_contract:["getConfigElement","setConfig","hass","config-changed"],sizing:{},priority:2,domains:["optional entity"],controls:[],services:[],states:["configured","preview/editMode","RTL","unknown","unavailable","not_found"],details:["weather entity; show_temperature and show_conditions are independent; default both false in runtime Boolean checks; icon always weather condition.","HA locale/unit temperature formatting and translated conditions; 14 weather SVG condition icons."],original_config:{type:"custom:mushroom-chips-card",chips:[{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0}]},island_config:{type:"custom:island-chips-card",chips:[{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0}]},initial_state:"configured",grid:null},{id:"badge:template",kind:"badge",name:"template",type:"custom:mushroom-template-badge",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/badges/template/template-badge.ts",source_path:"src/badges/template/template-badge.ts",config_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/badges/template/template-badge-config.ts",config_keys:["type","visibility","tap_action","hold_action","double_tap_action","entity","area","icon","color","label","content","picture","entity_id"],documented_options:[{name:"entity",type:"string",documented_default:"Optional",description:"Entity used for templating and interactions."},{name:"area",type:"string",documented_default:"Optional",description:"Area used for templating."},{name:"icon",type:"string",documented_default:"Optional",description:"Icon to display. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"color",type:"string",documented_default:"Optional",description:"Color applied to the icon or badge. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"label",type:"string",documented_default:"Optional",description:"Label displayed below the badge. Only shown if not empty. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"content",type:"string",documented_default:"Optional",description:"Main content inside the badge (e.g., state, text, number). Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"picture",type:"string",documented_default:"Optional",description:"Image to display instead of an icon. Supports [templating](https://www.home-assistant.io/docs/configuration/templating/)."},{name:"tap_action",type:"action",documented_default:"`none`",description:"Action performed when the badge is tapped."},{name:"hold_action",type:"action",documented_default:"`none`",description:"Action performed when the badge is long-pressed."},{name:"double_tap_action",type:"action",documented_default:"`none`",description:"Action performed when the badge is double-tapped."},{name:"entity_id",type:"string / list",documented_default:"Optional",description:"Restricts updates to these entities. Useful if automatic detection misses dependencies."}],editor_source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/src/badges/template/template-badge-editor.ts",editor_contract:["getConfigElement","getStubConfig","setConfig","hass","config-changed","window.customBadges registration"],sizing:{},priority:4,domains:["optional entity","optional area"],controls:["icon","color","label","content","picture templates"],services:["render_template subscription","hass-action event"],states:["static","templated","no entity","visibility condition","template error","disconnect/reconnect"],details:["Separate custom badge registered in customBadges, not a Chip or Card.","5 template keys icon,color,label,content,picture; variables config,user,entity,area; entity_id watcher filter; strict:true.","Default tap none; full 3 action configs. Native HA badge sizing/placement, not card getGridOptions."],original_config:{type:"custom:mushroom-template-badge",entity:"sensor.parity",label:"Island temperature",content:"{{ states('sensor.parity') }}",icon:"mdi:leaf"},island_config:{type:"custom:island-template-badge",entity:"sensor.parity",label:"Island temperature",content:"{{ states('sensor.parity') }}",icon:"mdi:leaf"},initial_state:"21",grid:null}]}});var H,z=ma(()=>{H={schemaVersion:1,status:"representative-tests-passed-not-full-acceptance",host:"Home Assistant",haVersion:"2026.9.0",generatedAt:"2026-11-06T19:26:06.204Z",commit:"668cb1fb427786ba02860f5e5682bdfdaee39584",fixtureStates:{"sensor.parity":{state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}},"light.parity":{state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}},"fan.parity":{state:"on",attributes:{friendly_name:"Island fan",percentage:50,percentage_step:10,oscillating:!0,direction:"forward",preset_modes:["auto","sleep"],preset_mode:"auto",supported_features:63}},"cover.parity":{state:"open",attributes:{friendly_name:"Island cover",current_position:60,current_tilt_position:40,supported_features:255}},"climate.parity":{state:"heat",attributes:{friendly_name:"Island climate",temperature:22,current_temperature:21,hvac_modes:["off","heat","cool","auto"],min_temp:7,max_temp:35,target_temp_step:.5,supported_features:1}},"humidifier.parity":{state:"on",attributes:{friendly_name:"Island humidifier",humidity:50,min_humidity:20,max_humidity:80,available_modes:["auto","normal"],mode:"auto",supported_features:1}},"lock.parity":{state:"locked",attributes:{friendly_name:"Island lock",supported_features:1}},"alarm_control_panel.parity":{state:"disarmed",attributes:{friendly_name:"Island alarm",supported_features:63,code_arm_required:!1}},"media_player.parity":{state:"playing",attributes:{friendly_name:"Island player",media_title:"Island song",media_artist:"K.K.",volume_level:.4,is_volume_muted:!1,shuffle:!1,repeat:"off",supported_features:1048575}},"number.parity":{state:"4",attributes:{friendly_name:"Island number",min:0,max:10,step:.5,mode:"slider"}},"select.parity":{state:"Spring",attributes:{friendly_name:"Island season",options:["Spring","Summer","Autumn","Winter"]}},"person.parity":{state:"home",attributes:{friendly_name:"Island villager"}},"update.parity":{state:"on",attributes:{friendly_name:"Island update",installed_version:"1.0",latest_version:"1.1",in_progress:!1,supported_features:1}},"vacuum.parity":{state:"docked",attributes:{friendly_name:"Island vacuum",battery_level:80,fan_speed:"normal",fan_speed_list:["quiet","normal","turbo"],supported_features:8191}},"weather.parity":{state:"sunny",attributes:{friendly_name:"Island weather",temperature:22,temperature_unit:"\xB0C",humidity:40}}},validation:{scope:"Representative live HA tests passed; full 1,131 acceptance cases are not individually mapped or certified.",runtimeStatus:"executed",commit:"668cb1fb427786ba02860f5e5682bdfdaee39584",haVersion:"2026.9.0",aggregateTests:22,aggregateExecutions:22,allExecutedPassed:!0,acceptance:{total:1131,requiresHA:392,individuallyMappedPassed:0},limitations:["Aggregate representative tests are not a 1,131-case acceptance mapping.","Synthetic entity states do not prove real hardware integration effects.","Screenshots prove only the captured configuration, state, dimensions and HA version."]},motion:{commit:"668cb1fb427786ba02860f5e5682bdfdaee39584",haVersion:"2026.9.0",host:"Home Assistant",status:"captured",authenticatedSyntheticDashboard:!0,video:"motion/island-motion.webm",width:1280,height:720,durationSeconds:7.28,observed:["press-scale","pointer-ripple","slider-sync","backend-state-change","reduced-motion"]},cases:{"card:alarm-control-panel":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"disarmed",original:"runtime/card-alarm-control-panel-original.png",island:"runtime/card-alarm-control-panel-island.png",config:{original:{type:"custom:mushroom-alarm-control-panel-card",entity:"alarm_control_panel.parity",states:["armed_home","armed_away","armed_night","armed_vacation","armed_custom_bypass"]},island:{type:"custom:island-alarm-control-panel-card",entity:"alarm_control_panel.parity",states:["armed_home","armed_away","armed_night","armed_vacation","armed_custom_bypass"]}},dimensions:{original:{x:513,y:140,width:246,height:125},island:{x:767,y:140,width:246,height:125}},entityStates:{original:{entity_id:"alarm_control_panel.parity",state:"disarmed",attributes:{friendly_name:"Island alarm",supported_features:63,code_arm_required:!1}},island:{entity_id:"alarm_control_panel.parity",state:"disarmed",attributes:{friendly_name:"Island alarm",supported_features:63,code_arm_required:!1}}},computedStyles:{original:{root:{tag:"mushroom-alarm-control-panel-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"36.4062px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"36.4062px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"36.3906px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"36.3906px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"36.4062px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"36.4062px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"36.3906px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"36.3906px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"36.4062px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"36.4062px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-alarm-control-panel-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"31.6094px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"31.6094px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"31.5938px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"31.5938px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"31.6094px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"31.6094px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"31.5938px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"31.5938px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"31.5938px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"31.5938px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:climate":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"heat",original:"runtime/card-climate-original.png",island:"runtime/card-climate-island.png",config:{original:{type:"custom:mushroom-climate-card",entity:"climate.parity",show_temperature_control:!0,hvac_modes:["off","heat","cool","auto"],collapsible_controls:!1},island:{type:"custom:island-climate-card",entity:"climate.parity",show_temperature_control:!0,hvac_modes:["off","heat","cool","auto"],collapsible_controls:!1}},dimensions:{original:{x:513,y:273,width:246,height:125},island:{x:767,y:273,width:246,height:125}},entityStates:{original:{entity_id:"climate.parity",state:"heat",attributes:{friendly_name:"Island climate",temperature:22,current_temperature:21,hvac_modes:["off","heat","cool","auto"],min_temp:7,max_temp:35,target_temp_step:.5,supported_features:1}},island:{entity_id:"climate.parity",state:"heat",attributes:{friendly_name:"Island climate",temperature:22,current_temperature:21,hvac_modes:["off","heat","cool","auto"],min_temp:7,max_temp:35,target_temp_step:.5,supported_features:1}}},computedStyles:{original:{root:{tag:"mushroom-climate-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"12px",boxShadow:"none",height:"30px",padding:"4px 0px 4px 4px",width:"25px",display:"flex"},{tag:"button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"12px",boxShadow:"none",height:"30px",padding:"4px 4px 4px 0px",width:"25px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-climate-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"50px",boxShadow:"none",height:"33px",padding:"4px 0px 4px 4px",width:"26.5px",display:"flex"},{tag:"button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"50px",boxShadow:"none",height:"33px",padding:"4px 4px 4px 0px",width:"26.5px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:cover":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"open",original:"runtime/card-cover-original.png",island:"runtime/card-cover-island.png",config:{original:{type:"custom:mushroom-cover-card",entity:"cover.parity",show_buttons_control:!0,show_position_control:!0,show_tilt_position_control:!0},island:{type:"custom:island-cover-card",entity:"cover.parity",show_buttons_control:!0,show_position_control:!0,show_tilt_position_control:!0}},dimensions:{original:{x:513,y:406,width:246,height:125},island:{x:767,y:406,width:246,height:125}},entityStates:{original:{entity_id:"cover.parity",state:"open",attributes:{friendly_name:"Island cover",current_position:60,current_tilt_position:40,supported_features:255}},island:{entity_id:"cover.parity",state:"open",attributes:{friendly_name:"Island cover",current_position:60,current_tilt_position:40,supported_features:255}}},computedStyles:{original:{root:{tag:"mushroom-cover-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"49.3281px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"49.3281px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"49.3438px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"49.3438px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"49.3281px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"49.3281px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-cover-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"44.3438px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"44.3438px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"44.3281px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"44.3281px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"44.3281px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"44.3281px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:entity":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"21",original:"runtime/card-entity-original.png",island:"runtime/card-entity-island.png",config:{original:{type:"custom:mushroom-entity-card",entity:"sensor.parity"},island:{type:"custom:island-entity-card",entity:"sensor.parity"}},dimensions:{original:{x:513,y:539,width:246,height:68},island:{x:767,y:539,width:246,height:68}},entityStates:{original:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}},island:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}}},computedStyles:{original:{root:{tag:"mushroom-entity-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"56px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-entity-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"68px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1}}},"card:fan":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"on",original:"runtime/card-fan-original.png",island:"runtime/card-fan-island.png",config:{original:{type:"custom:mushroom-fan-card",entity:"fan.parity",show_percentage_control:!0,show_oscillate_control:!0,show_direction_control:!0,collapsible_controls:!1},island:{type:"custom:island-fan-card",entity:"fan.parity",show_percentage_control:!0,show_oscillate_control:!0,show_direction_control:!0,collapsible_controls:!1}},dimensions:{original:{x:513,y:615,width:246,height:125},island:{x:767,y:595,width:246,height:125}},entityStates:{original:{entity_id:"fan.parity",state:"on",attributes:{friendly_name:"Island fan",percentage:50,percentage_step:10,oscillating:!0,direction:"forward",preset_modes:["auto","sleep"],preset_mode:"auto",supported_features:63}},island:{entity_id:"fan.parity",state:"on",attributes:{friendly_name:"Island fan",percentage:50,percentage_step:10,oscillating:!0,direction:"forward",preset_modes:["auto","sleep"],preset_mode:"auto",supported_features:63}}},computedStyles:{original:{root:{tag:"mushroom-fan-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"block"},{tag:"button",backgroundColor:"rgba(76, 175, 80, 0.2)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-fan-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"block"},{tag:"button",backgroundColor:"rgba(138, 198, 138, 0.2)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:humidifier":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"on",original:"runtime/card-humidifier-original.png",island:"runtime/card-humidifier-island.png",config:{original:{type:"custom:mushroom-humidifier-card",entity:"humidifier.parity",show_target_humidity_control:!0,collapsible_controls:!1},island:{type:"custom:island-humidifier-card",entity:"humidifier.parity",show_target_humidity_control:!0,collapsible_controls:!1}},dimensions:{original:{x:513,y:728,width:246,height:125},island:{x:767,y:297,width:246,height:125}},entityStates:{original:{entity_id:"humidifier.parity",state:"on",attributes:{friendly_name:"Island humidifier",humidity:50,min_humidity:20,max_humidity:80,available_modes:["auto","normal"],mode:"auto",supported_features:1}},island:{entity_id:"humidifier.parity",state:"on",attributes:{friendly_name:"Island humidifier",humidity:50,min_humidity:20,max_humidity:80,available_modes:["auto","normal"],mode:"auto",supported_features:1}}},computedStyles:{original:{root:{tag:"mushroom-humidifier-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-humidifier-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1}}},"card:light":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"on",original:"runtime/card-light-original.png",island:"runtime/card-light-island.png",config:{original:{type:"custom:mushroom-light-card",entity:"light.parity",show_brightness_control:!0,show_color_temp_control:!0,show_color_control:!0,collapsible_controls:!1,use_light_color:!0},island:{type:"custom:island-light-card",entity:"light.parity",show_brightness_control:!0,show_color_temp_control:!0,show_color_control:!0,collapsible_controls:!1,use_light_color:!0}},dimensions:{original:{x:513,y:430,width:246,height:125},island:{x:767,y:430,width:246,height:125}},entityStates:{original:{entity_id:"light.parity",state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}},island:{entity_id:"light.parity",state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}}},computedStyles:{original:{root:{tag:"mushroom-light-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-light-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:lock":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"locked",original:"runtime/card-lock-original.png",island:"runtime/card-lock-island.png",config:{original:{type:"custom:mushroom-lock-card",entity:"lock.parity"},island:{type:"custom:island-lock-card",entity:"lock.parity"}},dimensions:{original:{x:513,y:563,width:246,height:125},island:{x:767,y:563,width:246,height:125}},entityStates:{original:{entity_id:"lock.parity",state:"locked",attributes:{friendly_name:"Island lock",supported_features:1}},island:{entity_id:"lock.parity",state:"locked",attributes:{friendly_name:"Island lock",supported_features:1}}},computedStyles:{original:{root:{tag:"mushroom-lock-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"222px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"222px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-lock-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"222px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"222px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:media-player":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"playing",original:"runtime/card-media-player-original.png",island:"runtime/card-media-player-island.png",config:{original:{type:"custom:mushroom-media-player-card",entity:"media_player.parity",use_media_info:!0,show_volume_level:!0,volume_controls:["volume_mute","volume_set","volume_buttons"],media_controls:["on_off","shuffle","previous","play_pause_stop","next","repeat"],collapsible_controls:!1},island:{type:"custom:island-media-player-card",entity:"media_player.parity",use_media_info:!0,show_volume_level:!0,volume_controls:["volume_mute","volume_set","volume_buttons"],media_controls:["on_off","shuffle","previous","play_pause_stop","next","repeat"],collapsible_controls:!1}},dimensions:{original:{x:513,y:696,width:246,height:125},island:{x:767,y:595,width:246,height:125}},entityStates:{original:{entity_id:"media_player.parity",state:"playing",attributes:{friendly_name:"Island player",media_title:"Island song",media_artist:"K.K.",volume_level:.4,is_volume_muted:!1,shuffle:!1,repeat:"off",supported_features:1048575}},island:{entity_id:"media_player.parity",state:"playing",attributes:{friendly_name:"Island player",media_title:"Island song",media_artist:"K.K.",volume_level:.4,is_volume_muted:!1,shuffle:!1,repeat:"off",supported_features:1048575}}},computedStyles:{original:{root:{tag:"mushroom-media-player-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6562px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6562px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6562px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6562px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"19.6719px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"42px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-media-player-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1562px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1562px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1562px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1562px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"14.1719px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"45px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:number":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"4",original:"runtime/card-number-original.png",island:"runtime/card-number-island.png",config:{original:{type:"custom:mushroom-number-card",entity:"number.parity"},island:{type:"custom:island-number-card",entity:"number.parity"}},dimensions:{original:{x:513,y:728,width:246,height:125},island:{x:767,y:297,width:246,height:125}},entityStates:{original:{entity_id:"number.parity",state:"4",attributes:{friendly_name:"Island number",min:0,max:10,step:.5,mode:"slider"}},island:{entity_id:"number.parity",state:"4",attributes:{friendly_name:"Island number",min:0,max:10,step:.5,mode:"slider"}}},computedStyles:{original:{root:{tag:"mushroom-number-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-number-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1}}},"card:person":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"home",original:"runtime/card-person-original.png",island:"runtime/card-person-island.png",config:{original:{type:"custom:mushroom-person-card",entity:"person.parity"},island:{type:"custom:island-person-card",entity:"person.parity"}},dimensions:{original:{x:513,y:430,width:246,height:68},island:{x:767,y:430,width:246,height:68}},entityStates:{original:{entity_id:"person.parity",state:"home",attributes:{friendly_name:"Island villager"}},island:{entity_id:"person.parity",state:"home",attributes:{friendly_name:"Island villager"}}},computedStyles:{original:{root:{tag:"mushroom-person-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"56px",padding:"0px",width:"246px",display:"flex"},{tag:"div",backgroundColor:"rgb(76, 175, 80)",borderRadius:"50%",boxShadow:"none",height:"16px",padding:"0px",width:"16px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-person-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"68px",padding:"0px",width:"246px",display:"flex"},{tag:"div",backgroundColor:"rgb(138, 198, 138)",borderRadius:"50px",boxShadow:"none",height:"16px",padding:"0px",width:"16px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[],islandTheme:null,darkMode:!1}}},"card:select":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"Spring",original:"runtime/card-select-original.png",island:"runtime/card-select-island.png",config:{original:{type:"custom:mushroom-select-card",entity:"select.parity"},island:{type:"custom:island-select-card",entity:"select.parity"}},dimensions:{original:{x:513,y:506,width:246,height:125},island:{x:767,y:506,width:246,height:125}},entityStates:{original:{entity_id:"select.parity",state:"Spring",attributes:{friendly_name:"Island season",options:["Spring","Summer","Autumn","Winter"]}},island:{entity_id:"select.parity",state:"Spring",attributes:{friendly_name:"Island season",options:["Spring","Summer","Autumn","Winter"]}}},computedStyles:{original:{root:{tag:"mushroom-select-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"6px 10px",width:"222px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-select-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"6px 10px",width:"222px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:update":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"on",original:"runtime/card-update-original.png",island:"runtime/card-update-island.png",config:{original:{type:"custom:mushroom-update-card",entity:"update.parity",show_buttons_control:!0,collapsible_controls:!1},island:{type:"custom:island-update-card",entity:"update.parity",show_buttons_control:!0,collapsible_controls:!1}},dimensions:{original:{x:513,y:639,width:246,height:125},island:{x:767,y:595,width:246,height:125}},entityStates:{original:{entity_id:"update.parity",state:"on",attributes:{friendly_name:"Island update",installed_version:"1.0",latest_version:"1.1",in_progress:!1,supported_features:1}},island:{entity_id:"update.parity",state:"on",attributes:{friendly_name:"Island update",installed_version:"1.0",latest_version:"1.1",in_progress:!1,supported_features:1}}},computedStyles:{original:{root:{tag:"mushroom-update-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"106px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"106px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"106px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"106px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-update-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"103px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"103px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"103px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"103px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:vacuum":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"docked",original:"runtime/card-vacuum-original.png",island:"runtime/card-vacuum-island.png",config:{original:{type:"custom:mushroom-vacuum-card",entity:"vacuum.parity",commands:["on_off","start_pause","stop","locate","clean_spot","return_home"]},island:{type:"custom:island-vacuum-card",entity:"vacuum.parity",commands:["on_off","start_pause","stop","locate","clean_spot","return_home"]}},dimensions:{original:{x:513,y:728,width:246,height:125},island:{x:767,y:297,width:246,height:125}},entityStates:{original:{entity_id:"vacuum.parity",state:"docked",attributes:{friendly_name:"Island vacuum",battery_level:80,fan_speed:"normal",fan_speed_list:["quiet","normal","turbo"],supported_features:8191}},island:{entity_id:"vacuum.parity",state:"docked",attributes:{friendly_name:"Island vacuum",battery_level:80,fan_speed:"normal",fan_speed_list:["quiet","normal","turbo"],supported_features:8191}}},computedStyles:{original:{root:{tag:"mushroom-vacuum-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"56px",padding:"10px",width:"246px",display:"flex"}],buttons:[{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6562px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6562px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(189, 189, 189, 0.2)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6562px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6562px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"flex"},{tag:"mushroom-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"block"},{tag:"button",backgroundColor:"rgba(33, 33, 33, 0.05)",borderRadius:"12px",boxShadow:"none",height:"42px",padding:"0px",width:"28.6719px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-vacuum-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"125px",padding:"0px",width:"246px",display:"flex"}],stateItems:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"68px",padding:"16px 24px",width:"246px",display:"flex"}],buttons:[{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6562px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6562px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 236, 226)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6562px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6562px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"flex"},{tag:"island-button",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"block"},{tag:"button",backgroundColor:"rgb(240, 232, 216)",borderRadius:"50px",boxShadow:"none",height:"45px",padding:"0px",width:"23.6719px",display:"flex"}],islandTheme:null,darkMode:!1}}},"card:chips":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:null,original:"runtime/card-chips-original.png",island:"runtime/card-chips-island.png",config:{original:{type:"custom:mushroom-chips-card",chips:[{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}},{type:"alarm-control-panel",entity:"alarm_control_panel.parity"},{type:"back"},{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}},{type:"entity",entity:"sensor.parity"},{type:"light",entity:"light.parity"},{type:"menu"},{type:"quickbar"},{type:"spacer"},{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"},{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0}]},island:{type:"custom:island-chips-card",chips:[{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}},{type:"alarm-control-panel",entity:"alarm_control_panel.parity"},{type:"back"},{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}},{type:"entity",entity:"sensor.parity"},{type:"light",entity:"light.parity"},{type:"menu"},{type:"quickbar"},{type:"spacer"},{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"},{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0}]}},dimensions:{original:{x:513,y:430,width:246,height:176},island:{x:767,y:430,width:246,height:176}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-chips-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"176px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"176px",padding:"0px",width:"246px",display:"block"},{tag:"mushroom-action-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"mushroom-alarm-control-panel-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"89.8281px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"87.8281px",display:"flex"},{tag:"mushroom-back-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"mushroom-conditional-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"69.7344px",display:"block"},{tag:"mushroom-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"67.7344px",display:"flex"},{tag:"mushroom-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"69.7344px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"67.7344px",display:"flex"},{tag:"mushroom-light-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"56.9062px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"54.9062px",display:"flex"},{tag:"mushroom-menu-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"mushroom-quickbar-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"mushroom-spacer-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"90.2188px",display:"block"},{tag:"mushroom-template-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"55.7812px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"53.7812px",display:"flex"},{tag:"mushroom-weather-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"108px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"106px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:null},island:{root:{tag:"island-chips-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"176px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"168px",padding:"0px",width:"246px",display:"block"},{tag:"island-action-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"island-alarm-control-panel-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"90.6094px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"90.6094px",display:"flex"},{tag:"island-back-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"island-conditional-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"68.5156px",display:"block"},{tag:"island-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"68.5156px",display:"flex"},{tag:"island-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"68.5156px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"68.5156px",display:"flex"},{tag:"island-light-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"56.3906px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"56.3906px",display:"flex"},{tag:"island-menu-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"island-quickbar-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"},{tag:"island-spacer-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"96.5938px",display:"block"},{tag:"island-template-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"53.4062px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"53.4062px",display:"flex"},{tag:"island-weather-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"110.219px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"110.219px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:null}}},"card:empty":{host:"Home Assistant",haVersion:"2026.9.0",status:"expected-blank",state:null,original:null,island:null,config:{original:{type:"custom:mushroom-empty-card"},island:{type:"custom:island-empty-card"}},dimensions:{original:{x:513,y:614,width:246,height:0},island:{x:767,y:614,width:246,height:0}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-empty-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"246px",display:"block"},containers:[],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-empty-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"246px",display:"block"},containers:[],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"card:title":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:null,original:"runtime/card-title-original.png",island:"runtime/card-title-island.png",config:{original:{type:"custom:mushroom-title-card",title:"Island parity",subtitle:"Same HA, same entities"},island:{type:"custom:island-title-card",title:"Island parity",subtitle:"Same HA, same entities"}},dimensions:{original:{x:513,y:622,width:246,height:96},island:{x:767,y:622,width:246,height:96}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-title-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"96px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"12px",boxShadow:"none",height:"96px",padding:"24px 12px 8px",width:"246px",display:"block"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-title-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"96px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"20px",boxShadow:"none",height:"96px",padding:"24px 12px 8px",width:"246px",display:"block"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"card:template":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"on",original:"runtime/card-template-original.png",island:"runtime/card-template-island.png",config:{original:{type:"custom:mushroom-template-card",entity:"light.parity",features:[{type:"light-brightness"}],features_position:"bottom",primary:"{{ states('sensor.parity') }}",secondary:"Live server template",icon:"mdi:leaf"},island:{type:"custom:island-template-card",entity:"light.parity",features:[{type:"light-brightness"}],features_position:"bottom",primary:"{{ states('sensor.parity') }}",secondary:"Live server template",icon:"mdi:leaf"}},dimensions:{original:{x:513,y:726,width:246,height:110},island:{x:767,y:586,width:246,height:110}},entityStates:{original:{entity_id:"light.parity",state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}},island:{entity_id:"light.parity",state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}}},computedStyles:{original:{root:{tag:"mushroom-template-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[],buttons:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"12px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"block"},{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"9999px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],islandTheme:null,darkMode:!1},island:{root:{tag:"island-template-card",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"block"},containers:[{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"20px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"flex"}],stateItems:[],buttons:[{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"20px",boxShadow:"none",height:"110px",padding:"0px",width:"246px",display:"block"},{tag:"div",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],islandTheme:"light",darkMode:!1}}},"badge:template":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"21",original:"runtime/badge-template-original.png",island:"runtime/badge-template-island.png",config:{original:{type:"custom:mushroom-template-badge",entity:"sensor.parity",label:"Island temperature",content:"{{ states('sensor.parity') }}",icon:"mdi:leaf"},island:{type:"custom:island-template-badge",entity:"sensor.parity",label:"Island temperature",content:"{{ states('sensor.parity') }}",icon:"mdi:leaf"}},dimensions:{original:{x:626.25,y:-1518,width:134.296875,height:36},island:{x:768.546875,y:80,width:131.1875,height:36}},entityStates:{original:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}},island:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}}},computedStyles:{original:{root:{tag:"mushroom-template-badge",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},containers:[{tag:"mushroom-template-badge",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"div",backgroundColor:"rgb(255, 255, 255)",borderRadius:"18px",boxShadow:"none",height:"36px",padding:"0px 8px",width:"134.297px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-template-badge",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},containers:[{tag:"island-template-badge",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"div",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px 8px",width:"131.188px",display:"flex"}],stateItems:[],buttons:[],islandTheme:"light",darkMode:!1}}},"chip:action":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:null,original:"runtime/chip-action-original.png",island:"runtime/chip-action-island.png",config:{original:{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}},island:{type:"action",icon:"mdi:home",tap_action:{action:"navigate",navigation_path:"/lovelace/masonry"}}},dimensions:{original:{x:513,y:1888,width:38,height:38},island:{x:767,y:341,width:36,height:36}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-action-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},containers:[{tag:"mushroom-action-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-action-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},containers:[{tag:"island-action-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:alarm-control-panel":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"disarmed",original:"runtime/chip-alarm-control-panel-original.png",island:"runtime/chip-alarm-control-panel-island.png",config:{original:{type:"alarm-control-panel",entity:"alarm_control_panel.parity"},island:{type:"alarm-control-panel",entity:"alarm_control_panel.parity"}},dimensions:{original:{x:559,y:341,width:89.828125,height:38},island:{x:811,y:341,width:90.609375,height:36}},entityStates:{original:{entity_id:"alarm_control_panel.parity",state:"disarmed",attributes:{friendly_name:"Island alarm",supported_features:63,code_arm_required:!1}},island:{entity_id:"alarm_control_panel.parity",state:"disarmed",attributes:{friendly_name:"Island alarm",supported_features:63,code_arm_required:!1}}},computedStyles:{original:{root:{tag:"mushroom-alarm-control-panel-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"89.8281px",display:"block"},containers:[{tag:"mushroom-alarm-control-panel-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"89.8281px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"87.8281px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-alarm-control-panel-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"90.6094px",display:"block"},containers:[{tag:"island-alarm-control-panel-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"90.6094px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"90.6094px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:back":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:null,original:"runtime/chip-back-original.png",island:"runtime/chip-back-island.png",config:{original:{type:"back"},island:{type:"back"}},dimensions:{original:{x:656.828125,y:341,width:38,height:38},island:{x:909.609375,y:341,width:36,height:36}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-back-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},containers:[{tag:"mushroom-back-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-back-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},containers:[{tag:"island-back-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:conditional":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"21",original:"runtime/chip-conditional-original.png",island:"runtime/chip-conditional-island.png",config:{original:{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}},island:{type:"conditional",conditions:[{entity:"sensor.parity",state:"21"}],chip:{type:"entity",entity:"sensor.parity"}}},dimensions:{original:{x:513,y:387,width:69.734375,height:38},island:{x:767,y:385,width:68.515625,height:36}},entityStates:{original:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}},island:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}}},computedStyles:{original:{root:{tag:"mushroom-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},containers:[{tag:"mushroom-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"67.7344px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},containers:[{tag:"island-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"68.5156px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:entity":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"21",original:"runtime/chip-entity-original.png",island:"runtime/chip-entity-island.png",config:{original:{type:"entity",entity:"sensor.parity"},island:{type:"entity",entity:"sensor.parity"}},dimensions:{original:{x:513,y:387,width:69.734375,height:38},island:{x:767,y:385,width:68.515625,height:36}},entityStates:{original:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}},island:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}}},computedStyles:{original:{root:{tag:"mushroom-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},containers:[{tag:"mushroom-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"67.7344px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},containers:[{tag:"island-entity-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"68.5156px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:light":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"on",original:"runtime/chip-light-original.png",island:"runtime/chip-light-island.png",config:{original:{type:"light",entity:"light.parity"},island:{type:"light",entity:"light.parity"}},dimensions:{original:{x:668.46875,y:387,width:56.90625,height:38},island:{x:920.03125,y:385,width:56.390625,height:36}},entityStates:{original:{entity_id:"light.parity",state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}},island:{entity_id:"light.parity",state:"on",attributes:{friendly_name:"Island light",brightness:160,supported_color_modes:["hs","color_temp"],color_mode:"hs",hs_color:[35,65],rgb_color:[255,185,89],color_temp_kelvin:3e3,min_color_temp_kelvin:2e3,max_color_temp_kelvin:6500,supported_features:0}}},computedStyles:{original:{root:{tag:"mushroom-light-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"56.9062px",display:"block"},containers:[{tag:"mushroom-light-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"56.9062px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"54.9062px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-light-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"56.3906px",display:"block"},containers:[{tag:"island-light-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"56.3906px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"56.3906px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:menu":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:null,original:"runtime/chip-menu-original.png",island:"runtime/chip-menu-island.png",config:{original:{type:"menu"},island:{type:"menu"}},dimensions:{original:{x:513,y:433,width:38,height:38},island:{x:767,y:429,width:36,height:36}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-menu-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},containers:[{tag:"mushroom-menu-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-menu-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},containers:[{tag:"island-menu-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:quickbar":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:null,original:"runtime/chip-quickbar-original.png",island:"runtime/chip-quickbar-island.png",config:{original:{type:"quickbar"},island:{type:"quickbar"}},dimensions:{original:{x:559,y:433,width:38,height:38},island:{x:811,y:429,width:36,height:36}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-quickbar-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},containers:[{tag:"mushroom-quickbar-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"38px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-quickbar-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},containers:[{tag:"island-quickbar-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"36px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:spacer":{host:"Home Assistant",haVersion:"2026.9.0",status:"expected-blank",state:null,original:null,island:null,config:{original:{type:"spacer"},island:{type:"spacer"}},dimensions:{original:{x:605,y:433,width:90.21875,height:0},island:{x:855,y:429,width:96.59375,height:0}},entityStates:{original:null,island:null},computedStyles:{original:{root:{tag:"mushroom-spacer-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"90.2188px",display:"block"},containers:[{tag:"mushroom-spacer-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"90.2188px",display:"block"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-spacer-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"96.5938px",display:"block"},containers:[{tag:"island-spacer-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"0px",padding:"0px",width:"96.5938px",display:"block"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:template":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"21",original:"runtime/chip-template-original.png",island:"runtime/chip-template-island.png",config:{original:{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"},island:{type:"template",entity:"sensor.parity",content:"{{ states('sensor.parity') }}",icon:"mdi:thermometer"}},dimensions:{original:{x:703.21875,y:433,width:55.78125,height:38},island:{x:959.59375,y:429,width:53.40625,height:36}},entityStates:{original:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}},island:{entity_id:"sensor.parity",state:"21",attributes:{friendly_name:"Island temperature",unit_of_measurement:"\xB0C"}}},computedStyles:{original:{root:{tag:"mushroom-template-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"55.7812px",display:"block"},containers:[{tag:"mushroom-template-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"55.7812px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"53.7812px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-template-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"53.4062px",display:"block"},containers:[{tag:"island-template-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"53.4062px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"53.4062px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}},"chip:weather":{host:"Home Assistant",haVersion:"2026.9.0",status:"captured",state:"sunny",original:"runtime/chip-weather-original.png",island:"runtime/chip-weather-island.png",config:{original:{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0},island:{type:"weather",entity:"weather.parity",show_temperature:!0,show_conditions:!0}},dimensions:{original:{x:513,y:479,width:108,height:38},island:{x:767,y:473,width:110.21875,height:36}},entityStates:{original:{entity_id:"weather.parity",state:"sunny",attributes:{friendly_name:"Island weather",temperature:22,temperature_unit:"\xB0C",humidity:40}},island:{entity_id:"weather.parity",state:"sunny",attributes:{friendly_name:"Island weather",temperature:22,temperature_unit:"\xB0C",humidity:40}}},computedStyles:{original:{root:{tag:"mushroom-weather-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"108px",display:"block"},containers:[{tag:"mushroom-weather-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"38px",padding:"0px",width:"108px",display:"block"},{tag:"mushroom-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(255, 255, 255)",borderRadius:"19px",boxShadow:"none",height:"36px",padding:"0px",width:"106px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1},island:{root:{tag:"island-weather-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"110.219px",display:"block"},containers:[{tag:"island-weather-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"36px",padding:"0px",width:"110.219px",display:"block"},{tag:"island-chip",backgroundColor:"rgba(0, 0, 0, 0)",borderRadius:"0px",boxShadow:"none",height:"auto",padding:"0px",width:"auto",display:"inline"},{tag:"ha-card",backgroundColor:"rgb(247, 243, 223)",borderRadius:"50px",boxShadow:"none",height:"36px",padding:"0px",width:"110.219px",display:"flex"}],stateItems:[],buttons:[],islandTheme:null,darkMode:!1}}}}}});var B,O=ma(()=>{B={"card:climate":{width:249,height:130,path:"reference/climate-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/climate-light.png"},"card:cover":{width:251,height:130,path:"reference/cover-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/cover-light.png"},"card:entity":{width:251,height:74,path:"reference/entity-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/entity-light.png"},"card:fan":{width:251,height:130,path:"reference/fan-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/fan-light.png"},"card:light":{width:251,height:130,path:"reference/light-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/light-light.png"},"card:media-player":{width:251,height:132,path:"reference/media-player-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/media-player-light.png"},"card:number":{width:251,height:130,path:"reference/number-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/number-light.png"},"card:select":{width:301,height:135,path:"reference/select-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/select-light.png"},"card:template":{width:514,height:137,path:"reference/template-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/template-light.png"},"card:title":{width:330,height:90,path:"reference/title-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/title-light.png"},"card:vacuum":{width:250,height:132,path:"reference/vacuum-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/vacuum-light.png"},"chip:action":{width:98,height:50,path:"reference/chip-action-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/chip-action-light.png"},"chip:entity":{width:354,height:50,path:"reference/chip-entity-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/chip-entity-light.png"},"chip:light":{width:132,height:50,path:"reference/chip-light-light.png",source:"https://github.com/piitaya/lovelace-mushroom/blob/v5.2.3/docs/images/chip-light-light.png"}}});var tl=Je(T=>{"use strict";E();z();O();var Wt=Symbol.for("react.element"),Yp=Symbol.for("react.portal"),qp=Symbol.for("react.fragment"),Xp=Symbol.for("react.strict_mode"),Zp=Symbol.for("react.profiler"),Jp=Symbol.for("react.provider"),eu=Symbol.for("react.context"),nu=Symbol.for("react.forward_ref"),tu=Symbol.for("react.suspense"),ou=Symbol.for("react.memo"),iu=Symbol.for("react.lazy"),Gs=Symbol.iterator;function au(e){return e===null||typeof e!="object"?null:(e=Gs&&e[Gs]||e["@@iterator"],typeof e=="function"?e:null)}var Ks={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Ys=Object.assign,qs={};function dt(e,n,t){this.props=e,this.context=n,this.refs=qs,this.updater=t||Ks}dt.prototype.isReactComponent={};dt.prototype.setState=function(e,n){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,n,"setState")};dt.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Xs(){}Xs.prototype=dt.prototype;function fa(e,n,t){this.props=e,this.context=n,this.refs=qs,this.updater=t||Ks}var ya=fa.prototype=new Xs;ya.constructor=fa;Ys(ya,dt.prototype);ya.isPureReactComponent=!0;var $s=Array.isArray,Zs=Object.prototype.hasOwnProperty,_a={current:null},Js={key:!0,ref:!0,__self:!0,__source:!0};function el(e,n,t){var o,i={},a=null,r=null;if(n!=null)for(o in n.ref!==void 0&&(r=n.ref),n.key!==void 0&&(a=""+n.key),n)Zs.call(n,o)&&!Js.hasOwnProperty(o)&&(i[o]=n[o]);var s=arguments.length-2;if(s===1)i.children=t;else if(1<s){for(var l=Array(s),c=0;c<s;c++)l[c]=arguments[c+2];i.children=l}if(e&&e.defaultProps)for(o in s=e.defaultProps,s)i[o]===void 0&&(i[o]=s[o]);return{$$typeof:Wt,type:e,key:a,ref:r,props:i,_owner:_a.current}}function ru(e,n){return{$$typeof:Wt,type:e.type,key:n,ref:e.ref,props:e.props,_owner:e._owner}}function ba(e){return typeof e=="object"&&e!==null&&e.$$typeof===Wt}function su(e){var n={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(t){return n[t]})}var Qs=/\/+/g;function ga(e,n){return typeof e=="object"&&e!==null&&e.key!=null?su(""+e.key):n.toString(36)}function Fo(e,n,t,o,i){var a=typeof e;(a==="undefined"||a==="boolean")&&(e=null);var r=!1;if(e===null)r=!0;else switch(a){case"string":case"number":r=!0;break;case"object":switch(e.$$typeof){case Wt:case Yp:r=!0}}if(r)return r=e,i=i(r),e=o===""?"."+ga(r,0):o,$s(i)?(t="",e!=null&&(t=e.replace(Qs,"$&/")+"/"),Fo(i,n,t,"",function(c){return c})):i!=null&&(ba(i)&&(i=ru(i,t+(!i.key||r&&r.key===i.key?"":(""+i.key).replace(Qs,"$&/")+"/")+e)),n.push(i)),1;if(r=0,o=o===""?".":o+":",$s(e))for(var s=0;s<e.length;s++){a=e[s];var l=o+ga(a,s);r+=Fo(a,n,t,l,i)}else if(l=au(e),typeof l=="function")for(e=l.call(e),s=0;!(a=e.next()).done;)a=a.value,l=o+ga(a,s++),r+=Fo(a,n,t,l,i);else if(a==="object")throw n=String(e),Error("Objects are not valid as a React child (found: "+(n==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":n)+"). If you meant to render a collection of children, use an array instead.");return r}function Do(e,n,t){if(e==null)return e;var o=[],i=0;return Fo(e,o,"","",function(a){return n.call(t,a,i++)}),o}function lu(e){if(e._status===-1){var n=e._result;n=n(),n.then(function(t){(e._status===0||e._status===-1)&&(e._status=1,e._result=t)},function(t){(e._status===0||e._status===-1)&&(e._status=2,e._result=t)}),e._status===-1&&(e._status=0,e._result=n)}if(e._status===1)return e._result.default;throw e._result}var fe={current:null},Ho={transition:null},du={ReactCurrentDispatcher:fe,ReactCurrentBatchConfig:Ho,ReactCurrentOwner:_a};function nl(){throw Error("act(...) is not supported in production builds of React.")}T.Children={map:Do,forEach:function(e,n,t){Do(e,function(){n.apply(this,arguments)},t)},count:function(e){var n=0;return Do(e,function(){n++}),n},toArray:function(e){return Do(e,function(n){return n})||[]},only:function(e){if(!ba(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};T.Component=dt;T.Fragment=qp;T.Profiler=Zp;T.PureComponent=fa;T.StrictMode=Xp;T.Suspense=tu;T.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=du;T.act=nl;T.cloneElement=function(e,n,t){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var o=Ys({},e.props),i=e.key,a=e.ref,r=e._owner;if(n!=null){if(n.ref!==void 0&&(a=n.ref,r=_a.current),n.key!==void 0&&(i=""+n.key),e.type&&e.type.defaultProps)var s=e.type.defaultProps;for(l in n)Zs.call(n,l)&&!Js.hasOwnProperty(l)&&(o[l]=n[l]===void 0&&s!==void 0?s[l]:n[l])}var l=arguments.length-2;if(l===1)o.children=t;else if(1<l){s=Array(l);for(var c=0;c<l;c++)s[c]=arguments[c+2];o.children=s}return{$$typeof:Wt,type:e.type,key:i,ref:a,props:o,_owner:r}};T.createContext=function(e){return e={$$typeof:eu,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:Jp,_context:e},e.Consumer=e};T.createElement=el;T.createFactory=function(e){var n=el.bind(null,e);return n.type=e,n};T.createRef=function(){return{current:null}};T.forwardRef=function(e){return{$$typeof:nu,render:e}};T.isValidElement=ba;T.lazy=function(e){return{$$typeof:iu,_payload:{_status:-1,_result:e},_init:lu}};T.memo=function(e,n){return{$$typeof:ou,type:e,compare:n===void 0?null:n}};T.startTransition=function(e){var n=Ho.transition;Ho.transition={};try{e()}finally{Ho.transition=n}};T.unstable_act=nl;T.useCallback=function(e,n){return fe.current.useCallback(e,n)};T.useContext=function(e){return fe.current.useContext(e)};T.useDebugValue=function(){};T.useDeferredValue=function(e){return fe.current.useDeferredValue(e)};T.useEffect=function(e,n){return fe.current.useEffect(e,n)};T.useId=function(){return fe.current.useId()};T.useImperativeHandle=function(e,n,t){return fe.current.useImperativeHandle(e,n,t)};T.useInsertionEffect=function(e,n){return fe.current.useInsertionEffect(e,n)};T.useLayoutEffect=function(e,n){return fe.current.useLayoutEffect(e,n)};T.useMemo=function(e,n){return fe.current.useMemo(e,n)};T.useReducer=function(e,n,t){return fe.current.useReducer(e,n,t)};T.useRef=function(e){return fe.current.useRef(e)};T.useState=function(e){return fe.current.useState(e)};T.useSyncExternalStore=function(e,n,t){return fe.current.useSyncExternalStore(e,n,t)};T.useTransition=function(){return fe.current.useTransition()};T.version="18.3.1"});var Vn=Je((mf,ol)=>{"use strict";E();z();O();ol.exports=tl()});var hl=Je(j=>{"use strict";E();z();O();function ka(e,n){var t=e.length;e.push(n);e:for(;0<t;){var o=t-1>>>1,i=e[o];if(0<Bo(i,n))e[o]=n,e[t]=i,t=o;else break e}}function Ue(e){return e.length===0?null:e[0]}function Uo(e){if(e.length===0)return null;var n=e[0],t=e.pop();if(t!==n){e[0]=t;e:for(var o=0,i=e.length,a=i>>>1;o<a;){var r=2*(o+1)-1,s=e[r],l=r+1,c=e[l];if(0>Bo(s,t))l<i&&0>Bo(c,s)?(e[o]=c,e[l]=t,o=l):(e[o]=s,e[r]=t,o=r);else if(l<i&&0>Bo(c,t))e[o]=c,e[l]=t,o=l;else break e}}return n}function Bo(e,n){var t=e.sortIndex-n.sortIndex;return t!==0?t:e.id-n.id}typeof performance=="object"&&typeof performance.now=="function"?(il=performance,j.unstable_now=function(){return il.now()}):(xa=Date,al=xa.now(),j.unstable_now=function(){return xa.now()-al});var il,xa,al,en=[],xn=[],cu=1,Pe=null,de=3,Wo=!1,Un=!1,$t=!1,ll=typeof setTimeout=="function"?setTimeout:null,dl=typeof clearTimeout=="function"?clearTimeout:null,rl=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function Ca(e){for(var n=Ue(xn);n!==null;){if(n.callback===null)Uo(xn);else if(n.startTime<=e)Uo(xn),n.sortIndex=n.expirationTime,ka(en,n);else break;n=Ue(xn)}}function Sa(e){if($t=!1,Ca(e),!Un)if(Ue(en)!==null)Un=!0,Ia(Ra);else{var n=Ue(xn);n!==null&&Ea(Sa,n.startTime-e)}}function Ra(e,n){Un=!1,$t&&($t=!1,dl(Qt),Qt=-1),Wo=!0;var t=de;try{for(Ca(n),Pe=Ue(en);Pe!==null&&(!(Pe.expirationTime>n)||e&&!ul());){var o=Pe.callback;if(typeof o=="function"){Pe.callback=null,de=Pe.priorityLevel;var i=o(Pe.expirationTime<=n);n=j.unstable_now(),typeof i=="function"?Pe.callback=i:Pe===Ue(en)&&Uo(en),Ca(n)}else Uo(en);Pe=Ue(en)}if(Pe!==null)var a=!0;else{var r=Ue(xn);r!==null&&Ea(Sa,r.startTime-n),a=!1}return a}finally{Pe=null,de=t,Wo=!1}}var Go=!1,Vo=null,Qt=-1,cl=5,pl=-1;function ul(){return!(j.unstable_now()-pl<cl)}function wa(){if(Vo!==null){var e=j.unstable_now();pl=e;var n=!0;try{n=Vo(!0,e)}finally{n?Gt():(Go=!1,Vo=null)}}else Go=!1}var Gt;typeof rl=="function"?Gt=function(){rl(wa)}:typeof MessageChannel<"u"?(va=new MessageChannel,sl=va.port2,va.port1.onmessage=wa,Gt=function(){sl.postMessage(null)}):Gt=function(){ll(wa,0)};var va,sl;function Ia(e){Vo=e,Go||(Go=!0,Gt())}function Ea(e,n){Qt=ll(function(){e(j.unstable_now())},n)}j.unstable_IdlePriority=5;j.unstable_ImmediatePriority=1;j.unstable_LowPriority=4;j.unstable_NormalPriority=3;j.unstable_Profiling=null;j.unstable_UserBlockingPriority=2;j.unstable_cancelCallback=function(e){e.callback=null};j.unstable_continueExecution=function(){Un||Wo||(Un=!0,Ia(Ra))};j.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):cl=0<e?Math.floor(1e3/e):5};j.unstable_getCurrentPriorityLevel=function(){return de};j.unstable_getFirstCallbackNode=function(){return Ue(en)};j.unstable_next=function(e){switch(de){case 1:case 2:case 3:var n=3;break;default:n=de}var t=de;de=n;try{return e()}finally{de=t}};j.unstable_pauseExecution=function(){};j.unstable_requestPaint=function(){};j.unstable_runWithPriority=function(e,n){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var t=de;de=e;try{return n()}finally{de=t}};j.unstable_scheduleCallback=function(e,n,t){var o=j.unstable_now();switch(typeof t=="object"&&t!==null?(t=t.delay,t=typeof t=="number"&&0<t?o+t:o):t=o,e){case 1:var i=-1;break;case 2:i=250;break;case 5:i=1073741823;break;case 4:i=1e4;break;default:i=5e3}return i=t+i,e={id:cu++,callback:n,priorityLevel:e,startTime:t,expirationTime:i,sortIndex:-1},t>o?(e.sortIndex=t,ka(xn,e),Ue(en)===null&&e===Ue(xn)&&($t?(dl(Qt),Qt=-1):$t=!0,Ea(Sa,t-o))):(e.sortIndex=i,ka(en,e),Un||Wo||(Un=!0,Ia(Ra))),e};j.unstable_shouldYield=ul;j.unstable_wrapCallback=function(e){var n=de;return function(){var t=de;de=n;try{return e.apply(this,arguments)}finally{de=t}}}});var gl=Je((vf,ml)=>{"use strict";E();z();O();ml.exports=hl()});var bp=Je(Ae=>{"use strict";E();z();O();var pu=Vn(),Le=gl();function _(e){for(var n="https://reactjs.org/docs/error-decoder.html?invariant="+e,t=1;t<arguments.length;t++)n+="&args[]="+encodeURIComponent(arguments[t]);return"Minified React error #"+e+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var vd=new Set,fo={};function tt(e,n){Ot(e,n),Ot(e+"Capture",n)}function Ot(e,n){for(fo[e]=n,e=0;e<n.length;e++)vd.add(n[e])}var un=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Xa=Object.prototype.hasOwnProperty,uu=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,fl={},yl={};function hu(e){return Xa.call(yl,e)?!0:Xa.call(fl,e)?!1:uu.test(e)?yl[e]=!0:(fl[e]=!0,!1)}function mu(e,n,t,o){if(t!==null&&t.type===0)return!1;switch(typeof n){case"function":case"symbol":return!0;case"boolean":return o?!1:t!==null?!t.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function gu(e,n,t,o){if(n===null||typeof n>"u"||mu(e,n,t,o))return!0;if(o)return!1;if(t!==null)switch(t.type){case 3:return!n;case 4:return n===!1;case 5:return isNaN(n);case 6:return isNaN(n)||1>n}return!1}function be(e,n,t,o,i,a,r){this.acceptsBooleans=n===2||n===3||n===4,this.attributeName=o,this.attributeNamespace=i,this.mustUseProperty=t,this.propertyName=e,this.type=n,this.sanitizeURL=a,this.removeEmptyString=r}var le={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){le[e]=new be(e,0,!1,e,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var n=e[0];le[n]=new be(n,1,!1,e[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(e){le[e]=new be(e,2,!1,e.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){le[e]=new be(e,2,!1,e,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){le[e]=new be(e,3,!1,e.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(e){le[e]=new be(e,3,!0,e,null,!1,!1)});["capture","download"].forEach(function(e){le[e]=new be(e,4,!1,e,null,!1,!1)});["cols","rows","size","span"].forEach(function(e){le[e]=new be(e,6,!1,e,null,!1,!1)});["rowSpan","start"].forEach(function(e){le[e]=new be(e,5,!1,e.toLowerCase(),null,!1,!1)});var Ur=/[\-:]([a-z])/g;function Wr(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var n=e.replace(Ur,Wr);le[n]=new be(n,1,!1,e,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var n=e.replace(Ur,Wr);le[n]=new be(n,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(e){var n=e.replace(Ur,Wr);le[n]=new be(n,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(e){le[e]=new be(e,1,!1,e.toLowerCase(),null,!1,!1)});le.xlinkHref=new be("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(e){le[e]=new be(e,1,!1,e.toLowerCase(),null,!0,!0)});function Gr(e,n,t,o){var i=le.hasOwnProperty(n)?le[n]:null;(i!==null?i.type!==0:o||!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")&&(gu(n,t,i,o)&&(t=null),o||i===null?hu(n)&&(t===null?e.removeAttribute(n):e.setAttribute(n,""+t)):i.mustUseProperty?e[i.propertyName]=t===null?i.type===3?!1:"":t:(n=i.attributeName,o=i.attributeNamespace,t===null?e.removeAttribute(n):(i=i.type,t=i===3||i===4&&t===!0?"":""+t,o?e.setAttributeNS(o,n,t):e.setAttribute(n,t))))}var fn=pu.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,$o=Symbol.for("react.element"),ut=Symbol.for("react.portal"),ht=Symbol.for("react.fragment"),$r=Symbol.for("react.strict_mode"),Za=Symbol.for("react.profiler"),kd=Symbol.for("react.provider"),Cd=Symbol.for("react.context"),Qr=Symbol.for("react.forward_ref"),Ja=Symbol.for("react.suspense"),er=Symbol.for("react.suspense_list"),Kr=Symbol.for("react.memo"),vn=Symbol.for("react.lazy"),Sd=Symbol.for("react.offscreen"),_l=Symbol.iterator;function Kt(e){return e===null||typeof e!="object"?null:(e=_l&&e[_l]||e["@@iterator"],typeof e=="function"?e:null)}var K=Object.assign,za;function to(e){if(za===void 0)try{throw Error()}catch(t){var n=t.stack.trim().match(/\n( *(at )?)/);za=n&&n[1]||""}return`
`+za+e}var Oa=!1;function Ta(e,n){if(!e||Oa)return"";Oa=!0;var t=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(n)if(n=function(){throw Error()},Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(n,[])}catch(c){var o=c}Reflect.construct(e,[],n)}else{try{n.call()}catch(c){o=c}e.call(n.prototype)}else{try{throw Error()}catch(c){o=c}e()}}catch(c){if(c&&o&&typeof c.stack=="string"){for(var i=c.stack.split(`
`),a=o.stack.split(`
`),r=i.length-1,s=a.length-1;1<=r&&0<=s&&i[r]!==a[s];)s--;for(;1<=r&&0<=s;r--,s--)if(i[r]!==a[s]){if(r!==1||s!==1)do if(r--,s--,0>s||i[r]!==a[s]){var l=`
`+i[r].replace(" at new "," at ");return e.displayName&&l.includes("<anonymous>")&&(l=l.replace("<anonymous>",e.displayName)),l}while(1<=r&&0<=s);break}}}finally{Oa=!1,Error.prepareStackTrace=t}return(e=e?e.displayName||e.name:"")?to(e):""}function fu(e){switch(e.tag){case 5:return to(e.type);case 16:return to("Lazy");case 13:return to("Suspense");case 19:return to("SuspenseList");case 0:case 2:case 15:return e=Ta(e.type,!1),e;case 11:return e=Ta(e.type.render,!1),e;case 1:return e=Ta(e.type,!0),e;default:return""}}function nr(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case ht:return"Fragment";case ut:return"Portal";case Za:return"Profiler";case $r:return"StrictMode";case Ja:return"Suspense";case er:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case Cd:return(e.displayName||"Context")+".Consumer";case kd:return(e._context.displayName||"Context")+".Provider";case Qr:var n=e.render;return e=e.displayName,e||(e=n.displayName||n.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Kr:return n=e.displayName||null,n!==null?n:nr(e.type)||"Memo";case vn:n=e._payload,e=e._init;try{return nr(e(n))}catch{}}return null}function yu(e){var n=e.type;switch(e.tag){case 24:return"Cache";case 9:return(n.displayName||"Context")+".Consumer";case 10:return(n._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=n.render,e=e.displayName||e.name||"",n.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return n;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return nr(n);case 8:return n===$r?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n}return null}function Mn(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Rd(e){var n=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function _u(e){var n=Rd(e)?"checked":"value",t=Object.getOwnPropertyDescriptor(e.constructor.prototype,n),o=""+e[n];if(!e.hasOwnProperty(n)&&typeof t<"u"&&typeof t.get=="function"&&typeof t.set=="function"){var i=t.get,a=t.set;return Object.defineProperty(e,n,{configurable:!0,get:function(){return i.call(this)},set:function(r){o=""+r,a.call(this,r)}}),Object.defineProperty(e,n,{enumerable:t.enumerable}),{getValue:function(){return o},setValue:function(r){o=""+r},stopTracking:function(){e._valueTracker=null,delete e[n]}}}}function Qo(e){e._valueTracker||(e._valueTracker=_u(e))}function Id(e){if(!e)return!1;var n=e._valueTracker;if(!n)return!0;var t=n.getValue(),o="";return e&&(o=Rd(e)?e.checked?"true":"false":e.value),e=o,e!==t?(n.setValue(e),!0):!1}function wi(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function tr(e,n){var t=n.checked;return K({},n,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:t??e._wrapperState.initialChecked})}function bl(e,n){var t=n.defaultValue==null?"":n.defaultValue,o=n.checked!=null?n.checked:n.defaultChecked;t=Mn(n.value!=null?n.value:t),e._wrapperState={initialChecked:o,initialValue:t,controlled:n.type==="checkbox"||n.type==="radio"?n.checked!=null:n.value!=null}}function Ed(e,n){n=n.checked,n!=null&&Gr(e,"checked",n,!1)}function or(e,n){Ed(e,n);var t=Mn(n.value),o=n.type;if(t!=null)o==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+t):e.value!==""+t&&(e.value=""+t);else if(o==="submit"||o==="reset"){e.removeAttribute("value");return}n.hasOwnProperty("value")?ir(e,n.type,t):n.hasOwnProperty("defaultValue")&&ir(e,n.type,Mn(n.defaultValue)),n.checked==null&&n.defaultChecked!=null&&(e.defaultChecked=!!n.defaultChecked)}function xl(e,n,t){if(n.hasOwnProperty("value")||n.hasOwnProperty("defaultValue")){var o=n.type;if(!(o!=="submit"&&o!=="reset"||n.value!==void 0&&n.value!==null))return;n=""+e._wrapperState.initialValue,t||n===e.value||(e.value=n),e.defaultValue=n}t=e.name,t!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,t!==""&&(e.name=t)}function ir(e,n,t){(n!=="number"||wi(e.ownerDocument)!==e)&&(t==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+t&&(e.defaultValue=""+t))}var oo=Array.isArray;function Ct(e,n,t,o){if(e=e.options,n){n={};for(var i=0;i<t.length;i++)n["$"+t[i]]=!0;for(t=0;t<e.length;t++)i=n.hasOwnProperty("$"+e[t].value),e[t].selected!==i&&(e[t].selected=i),i&&o&&(e[t].defaultSelected=!0)}else{for(t=""+Mn(t),n=null,i=0;i<e.length;i++){if(e[i].value===t){e[i].selected=!0,o&&(e[i].defaultSelected=!0);return}n!==null||e[i].disabled||(n=e[i])}n!==null&&(n.selected=!0)}}function ar(e,n){if(n.dangerouslySetInnerHTML!=null)throw Error(_(91));return K({},n,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function wl(e,n){var t=n.value;if(t==null){if(t=n.children,n=n.defaultValue,t!=null){if(n!=null)throw Error(_(92));if(oo(t)){if(1<t.length)throw Error(_(93));t=t[0]}n=t}n==null&&(n=""),t=n}e._wrapperState={initialValue:Mn(t)}}function zd(e,n){var t=Mn(n.value),o=Mn(n.defaultValue);t!=null&&(t=""+t,t!==e.value&&(e.value=t),n.defaultValue==null&&e.defaultValue!==t&&(e.defaultValue=t)),o!=null&&(e.defaultValue=""+o)}function vl(e){var n=e.textContent;n===e._wrapperState.initialValue&&n!==""&&n!==null&&(e.value=n)}function Od(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function rr(e,n){return e==null||e==="http://www.w3.org/1999/xhtml"?Od(n):e==="http://www.w3.org/2000/svg"&&n==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var Ko,Td=(function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(n,t,o,i){MSApp.execUnsafeLocalFunction(function(){return e(n,t,o,i)})}:e})(function(e,n){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=n;else{for(Ko=Ko||document.createElement("div"),Ko.innerHTML="<svg>"+n.valueOf().toString()+"</svg>",n=Ko.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;n.firstChild;)e.appendChild(n.firstChild)}});function yo(e,n){if(n){var t=e.firstChild;if(t&&t===e.lastChild&&t.nodeType===3){t.nodeValue=n;return}}e.textContent=n}var ro={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},bu=["Webkit","ms","Moz","O"];Object.keys(ro).forEach(function(e){bu.forEach(function(n){n=n+e.charAt(0).toUpperCase()+e.substring(1),ro[n]=ro[e]})});function Ld(e,n,t){return n==null||typeof n=="boolean"||n===""?"":t||typeof n!="number"||n===0||ro.hasOwnProperty(e)&&ro[e]?(""+n).trim():n+"px"}function Nd(e,n){e=e.style;for(var t in n)if(n.hasOwnProperty(t)){var o=t.indexOf("--")===0,i=Ld(t,n[t],o);t==="float"&&(t="cssFloat"),o?e.setProperty(t,i):e[t]=i}}var xu=K({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function sr(e,n){if(n){if(xu[e]&&(n.children!=null||n.dangerouslySetInnerHTML!=null))throw Error(_(137,e));if(n.dangerouslySetInnerHTML!=null){if(n.children!=null)throw Error(_(60));if(typeof n.dangerouslySetInnerHTML!="object"||!("__html"in n.dangerouslySetInnerHTML))throw Error(_(61))}if(n.style!=null&&typeof n.style!="object")throw Error(_(62))}}function lr(e,n){if(e.indexOf("-")===-1)return typeof n.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var dr=null;function Yr(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var cr=null,St=null,Rt=null;function kl(e){if(e=Po(e)){if(typeof cr!="function")throw Error(_(280));var n=e.stateNode;n&&(n=Yi(n),cr(e.stateNode,e.type,n))}}function Ad(e){St?Rt?Rt.push(e):Rt=[e]:St=e}function Pd(){if(St){var e=St,n=Rt;if(Rt=St=null,kl(e),n)for(e=0;e<n.length;e++)kl(n[e])}}function Md(e,n){return e(n)}function jd(){}var La=!1;function Dd(e,n,t){if(La)return e(n,t);La=!0;try{return Md(e,n,t)}finally{La=!1,(St!==null||Rt!==null)&&(jd(),Pd())}}function _o(e,n){var t=e.stateNode;if(t===null)return null;var o=Yi(t);if(o===null)return null;t=o[n];e:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(t&&typeof t!="function")throw Error(_(231,n,typeof t));return t}var pr=!1;if(un)try{ct={},Object.defineProperty(ct,"passive",{get:function(){pr=!0}}),window.addEventListener("test",ct,ct),window.removeEventListener("test",ct,ct)}catch{pr=!1}var ct;function wu(e,n,t,o,i,a,r,s,l){var c=Array.prototype.slice.call(arguments,3);try{n.apply(t,c)}catch(f){this.onError(f)}}var so=!1,vi=null,ki=!1,ur=null,vu={onError:function(e){so=!0,vi=e}};function ku(e,n,t,o,i,a,r,s,l){so=!1,vi=null,wu.apply(vu,arguments)}function Cu(e,n,t,o,i,a,r,s,l){if(ku.apply(this,arguments),so){if(so){var c=vi;so=!1,vi=null}else throw Error(_(198));ki||(ki=!0,ur=c)}}function ot(e){var n=e,t=e;if(e.alternate)for(;n.return;)n=n.return;else{e=n;do n=e,(n.flags&4098)!==0&&(t=n.return),e=n.return;while(e)}return n.tag===3?t:null}function Fd(e){if(e.tag===13){var n=e.memoizedState;if(n===null&&(e=e.alternate,e!==null&&(n=e.memoizedState)),n!==null)return n.dehydrated}return null}function Cl(e){if(ot(e)!==e)throw Error(_(188))}function Su(e){var n=e.alternate;if(!n){if(n=ot(e),n===null)throw Error(_(188));return n!==e?null:e}for(var t=e,o=n;;){var i=t.return;if(i===null)break;var a=i.alternate;if(a===null){if(o=i.return,o!==null){t=o;continue}break}if(i.child===a.child){for(a=i.child;a;){if(a===t)return Cl(i),e;if(a===o)return Cl(i),n;a=a.sibling}throw Error(_(188))}if(t.return!==o.return)t=i,o=a;else{for(var r=!1,s=i.child;s;){if(s===t){r=!0,t=i,o=a;break}if(s===o){r=!0,o=i,t=a;break}s=s.sibling}if(!r){for(s=a.child;s;){if(s===t){r=!0,t=a,o=i;break}if(s===o){r=!0,o=a,t=i;break}s=s.sibling}if(!r)throw Error(_(189))}}if(t.alternate!==o)throw Error(_(190))}if(t.tag!==3)throw Error(_(188));return t.stateNode.current===t?e:n}function Hd(e){return e=Su(e),e!==null?Bd(e):null}function Bd(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var n=Bd(e);if(n!==null)return n;e=e.sibling}return null}var Vd=Le.unstable_scheduleCallback,Sl=Le.unstable_cancelCallback,Ru=Le.unstable_shouldYield,Iu=Le.unstable_requestPaint,q=Le.unstable_now,Eu=Le.unstable_getCurrentPriorityLevel,qr=Le.unstable_ImmediatePriority,Ud=Le.unstable_UserBlockingPriority,Ci=Le.unstable_NormalPriority,zu=Le.unstable_LowPriority,Wd=Le.unstable_IdlePriority,Gi=null,an=null;function Ou(e){if(an&&typeof an.onCommitFiberRoot=="function")try{an.onCommitFiberRoot(Gi,e,void 0,(e.current.flags&128)===128)}catch{}}var Ke=Math.clz32?Math.clz32:Nu,Tu=Math.log,Lu=Math.LN2;function Nu(e){return e>>>=0,e===0?32:31-(Tu(e)/Lu|0)|0}var Yo=64,qo=4194304;function io(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Si(e,n){var t=e.pendingLanes;if(t===0)return 0;var o=0,i=e.suspendedLanes,a=e.pingedLanes,r=t&268435455;if(r!==0){var s=r&~i;s!==0?o=io(s):(a&=r,a!==0&&(o=io(a)))}else r=t&~i,r!==0?o=io(r):a!==0&&(o=io(a));if(o===0)return 0;if(n!==0&&n!==o&&(n&i)===0&&(i=o&-o,a=n&-n,i>=a||i===16&&(a&4194240)!==0))return n;if((o&4)!==0&&(o|=t&16),n=e.entangledLanes,n!==0)for(e=e.entanglements,n&=o;0<n;)t=31-Ke(n),i=1<<t,o|=e[t],n&=~i;return o}function Au(e,n){switch(e){case 1:case 2:case 4:return n+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Pu(e,n){for(var t=e.suspendedLanes,o=e.pingedLanes,i=e.expirationTimes,a=e.pendingLanes;0<a;){var r=31-Ke(a),s=1<<r,l=i[r];l===-1?((s&t)===0||(s&o)!==0)&&(i[r]=Au(s,n)):l<=n&&(e.expiredLanes|=s),a&=~s}}function hr(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function Gd(){var e=Yo;return Yo<<=1,(Yo&4194240)===0&&(Yo=64),e}function Na(e){for(var n=[],t=0;31>t;t++)n.push(e);return n}function No(e,n,t){e.pendingLanes|=n,n!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,n=31-Ke(n),e[n]=t}function Mu(e,n){var t=e.pendingLanes&~n;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=n,e.mutableReadLanes&=n,e.entangledLanes&=n,n=e.entanglements;var o=e.eventTimes;for(e=e.expirationTimes;0<t;){var i=31-Ke(t),a=1<<i;n[i]=0,o[i]=-1,e[i]=-1,t&=~a}}function Xr(e,n){var t=e.entangledLanes|=n;for(e=e.entanglements;t;){var o=31-Ke(t),i=1<<o;i&n|e[o]&n&&(e[o]|=n),t&=~i}}var P=0;function $d(e){return e&=-e,1<e?4<e?(e&268435455)!==0?16:536870912:4:1}var Qd,Zr,Kd,Yd,qd,mr=!1,Xo=[],En=null,zn=null,On=null,bo=new Map,xo=new Map,Cn=[],ju="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Rl(e,n){switch(e){case"focusin":case"focusout":En=null;break;case"dragenter":case"dragleave":zn=null;break;case"mouseover":case"mouseout":On=null;break;case"pointerover":case"pointerout":bo.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":xo.delete(n.pointerId)}}function Yt(e,n,t,o,i,a){return e===null||e.nativeEvent!==a?(e={blockedOn:n,domEventName:t,eventSystemFlags:o,nativeEvent:a,targetContainers:[i]},n!==null&&(n=Po(n),n!==null&&Zr(n)),e):(e.eventSystemFlags|=o,n=e.targetContainers,i!==null&&n.indexOf(i)===-1&&n.push(i),e)}function Du(e,n,t,o,i){switch(n){case"focusin":return En=Yt(En,e,n,t,o,i),!0;case"dragenter":return zn=Yt(zn,e,n,t,o,i),!0;case"mouseover":return On=Yt(On,e,n,t,o,i),!0;case"pointerover":var a=i.pointerId;return bo.set(a,Yt(bo.get(a)||null,e,n,t,o,i)),!0;case"gotpointercapture":return a=i.pointerId,xo.set(a,Yt(xo.get(a)||null,e,n,t,o,i)),!0}return!1}function Xd(e){var n=$n(e.target);if(n!==null){var t=ot(n);if(t!==null){if(n=t.tag,n===13){if(n=Fd(t),n!==null){e.blockedOn=n,qd(e.priority,function(){Kd(t)});return}}else if(n===3&&t.stateNode.current.memoizedState.isDehydrated){e.blockedOn=t.tag===3?t.stateNode.containerInfo:null;return}}}e.blockedOn=null}function pi(e){if(e.blockedOn!==null)return!1;for(var n=e.targetContainers;0<n.length;){var t=gr(e.domEventName,e.eventSystemFlags,n[0],e.nativeEvent);if(t===null){t=e.nativeEvent;var o=new t.constructor(t.type,t);dr=o,t.target.dispatchEvent(o),dr=null}else return n=Po(t),n!==null&&Zr(n),e.blockedOn=t,!1;n.shift()}return!0}function Il(e,n,t){pi(e)&&t.delete(n)}function Fu(){mr=!1,En!==null&&pi(En)&&(En=null),zn!==null&&pi(zn)&&(zn=null),On!==null&&pi(On)&&(On=null),bo.forEach(Il),xo.forEach(Il)}function qt(e,n){e.blockedOn===n&&(e.blockedOn=null,mr||(mr=!0,Le.unstable_scheduleCallback(Le.unstable_NormalPriority,Fu)))}function wo(e){function n(i){return qt(i,e)}if(0<Xo.length){qt(Xo[0],e);for(var t=1;t<Xo.length;t++){var o=Xo[t];o.blockedOn===e&&(o.blockedOn=null)}}for(En!==null&&qt(En,e),zn!==null&&qt(zn,e),On!==null&&qt(On,e),bo.forEach(n),xo.forEach(n),t=0;t<Cn.length;t++)o=Cn[t],o.blockedOn===e&&(o.blockedOn=null);for(;0<Cn.length&&(t=Cn[0],t.blockedOn===null);)Xd(t),t.blockedOn===null&&Cn.shift()}var It=fn.ReactCurrentBatchConfig,Ri=!0;function Hu(e,n,t,o){var i=P,a=It.transition;It.transition=null;try{P=1,Jr(e,n,t,o)}finally{P=i,It.transition=a}}function Bu(e,n,t,o){var i=P,a=It.transition;It.transition=null;try{P=4,Jr(e,n,t,o)}finally{P=i,It.transition=a}}function Jr(e,n,t,o){if(Ri){var i=gr(e,n,t,o);if(i===null)Ha(e,n,o,Ii,t),Rl(e,o);else if(Du(i,e,n,t,o))o.stopPropagation();else if(Rl(e,o),n&4&&-1<ju.indexOf(e)){for(;i!==null;){var a=Po(i);if(a!==null&&Qd(a),a=gr(e,n,t,o),a===null&&Ha(e,n,o,Ii,t),a===i)break;i=a}i!==null&&o.stopPropagation()}else Ha(e,n,o,null,t)}}var Ii=null;function gr(e,n,t,o){if(Ii=null,e=Yr(o),e=$n(e),e!==null)if(n=ot(e),n===null)e=null;else if(t=n.tag,t===13){if(e=Fd(n),e!==null)return e;e=null}else if(t===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;e=null}else n!==e&&(e=null);return Ii=e,null}function Zd(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Eu()){case qr:return 1;case Ud:return 4;case Ci:case zu:return 16;case Wd:return 536870912;default:return 16}default:return 16}}var Rn=null,es=null,ui=null;function Jd(){if(ui)return ui;var e,n=es,t=n.length,o,i="value"in Rn?Rn.value:Rn.textContent,a=i.length;for(e=0;e<t&&n[e]===i[e];e++);var r=t-e;for(o=1;o<=r&&n[t-o]===i[a-o];o++);return ui=i.slice(e,1<o?1-o:void 0)}function hi(e){var n=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&n===13&&(e=13)):e=n,e===10&&(e=13),32<=e||e===13?e:0}function Zo(){return!0}function El(){return!1}function Ne(e){function n(t,o,i,a,r){this._reactName=t,this._targetInst=i,this.type=o,this.nativeEvent=a,this.target=r,this.currentTarget=null;for(var s in e)e.hasOwnProperty(s)&&(t=e[s],this[s]=t?t(a):a[s]);return this.isDefaultPrevented=(a.defaultPrevented!=null?a.defaultPrevented:a.returnValue===!1)?Zo:El,this.isPropagationStopped=El,this}return K(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var t=this.nativeEvent;t&&(t.preventDefault?t.preventDefault():typeof t.returnValue!="unknown"&&(t.returnValue=!1),this.isDefaultPrevented=Zo)},stopPropagation:function(){var t=this.nativeEvent;t&&(t.stopPropagation?t.stopPropagation():typeof t.cancelBubble!="unknown"&&(t.cancelBubble=!0),this.isPropagationStopped=Zo)},persist:function(){},isPersistent:Zo}),n}var jt={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},ns=Ne(jt),Ao=K({},jt,{view:0,detail:0}),Vu=Ne(Ao),Aa,Pa,Xt,$i=K({},Ao,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ts,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Xt&&(Xt&&e.type==="mousemove"?(Aa=e.screenX-Xt.screenX,Pa=e.screenY-Xt.screenY):Pa=Aa=0,Xt=e),Aa)},movementY:function(e){return"movementY"in e?e.movementY:Pa}}),zl=Ne($i),Uu=K({},$i,{dataTransfer:0}),Wu=Ne(Uu),Gu=K({},Ao,{relatedTarget:0}),Ma=Ne(Gu),$u=K({},jt,{animationName:0,elapsedTime:0,pseudoElement:0}),Qu=Ne($u),Ku=K({},jt,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Yu=Ne(Ku),qu=K({},jt,{data:0}),Ol=Ne(qu),Xu={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Zu={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Ju={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function eh(e){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(e):(e=Ju[e])?!!n[e]:!1}function ts(){return eh}var nh=K({},Ao,{key:function(e){if(e.key){var n=Xu[e.key]||e.key;if(n!=="Unidentified")return n}return e.type==="keypress"?(e=hi(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Zu[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ts,charCode:function(e){return e.type==="keypress"?hi(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?hi(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),th=Ne(nh),oh=K({},$i,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Tl=Ne(oh),ih=K({},Ao,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ts}),ah=Ne(ih),rh=K({},jt,{propertyName:0,elapsedTime:0,pseudoElement:0}),sh=Ne(rh),lh=K({},$i,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),dh=Ne(lh),ch=[9,13,27,32],os=un&&"CompositionEvent"in window,lo=null;un&&"documentMode"in document&&(lo=document.documentMode);var ph=un&&"TextEvent"in window&&!lo,ec=un&&(!os||lo&&8<lo&&11>=lo),Ll=" ",Nl=!1;function nc(e,n){switch(e){case"keyup":return ch.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function tc(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var mt=!1;function uh(e,n){switch(e){case"compositionend":return tc(n);case"keypress":return n.which!==32?null:(Nl=!0,Ll);case"textInput":return e=n.data,e===Ll&&Nl?null:e;default:return null}}function hh(e,n){if(mt)return e==="compositionend"||!os&&nc(e,n)?(e=Jd(),ui=es=Rn=null,mt=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return ec&&n.locale!=="ko"?null:n.data;default:return null}}var mh={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Al(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n==="input"?!!mh[e.type]:n==="textarea"}function oc(e,n,t,o){Ad(o),n=Ei(n,"onChange"),0<n.length&&(t=new ns("onChange","change",null,t,o),e.push({event:t,listeners:n}))}var co=null,vo=null;function gh(e){mc(e,0)}function Qi(e){var n=yt(e);if(Id(n))return e}function fh(e,n){if(e==="change")return n}var ic=!1;un&&(un?(ei="oninput"in document,ei||(ja=document.createElement("div"),ja.setAttribute("oninput","return;"),ei=typeof ja.oninput=="function"),Jo=ei):Jo=!1,ic=Jo&&(!document.documentMode||9<document.documentMode));var Jo,ei,ja;function Pl(){co&&(co.detachEvent("onpropertychange",ac),vo=co=null)}function ac(e){if(e.propertyName==="value"&&Qi(vo)){var n=[];oc(n,vo,e,Yr(e)),Dd(gh,n)}}function yh(e,n,t){e==="focusin"?(Pl(),co=n,vo=t,co.attachEvent("onpropertychange",ac)):e==="focusout"&&Pl()}function _h(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Qi(vo)}function bh(e,n){if(e==="click")return Qi(n)}function xh(e,n){if(e==="input"||e==="change")return Qi(n)}function wh(e,n){return e===n&&(e!==0||1/e===1/n)||e!==e&&n!==n}var qe=typeof Object.is=="function"?Object.is:wh;function ko(e,n){if(qe(e,n))return!0;if(typeof e!="object"||e===null||typeof n!="object"||n===null)return!1;var t=Object.keys(e),o=Object.keys(n);if(t.length!==o.length)return!1;for(o=0;o<t.length;o++){var i=t[o];if(!Xa.call(n,i)||!qe(e[i],n[i]))return!1}return!0}function Ml(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function jl(e,n){var t=Ml(e);e=0;for(var o;t;){if(t.nodeType===3){if(o=e+t.textContent.length,e<=n&&o>=n)return{node:t,offset:n-e};e=o}e:{for(;t;){if(t.nextSibling){t=t.nextSibling;break e}t=t.parentNode}t=void 0}t=Ml(t)}}function rc(e,n){return e&&n?e===n?!0:e&&e.nodeType===3?!1:n&&n.nodeType===3?rc(e,n.parentNode):"contains"in e?e.contains(n):e.compareDocumentPosition?!!(e.compareDocumentPosition(n)&16):!1:!1}function sc(){for(var e=window,n=wi();n instanceof e.HTMLIFrameElement;){try{var t=typeof n.contentWindow.location.href=="string"}catch{t=!1}if(t)e=n.contentWindow;else break;n=wi(e.document)}return n}function is(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n&&(n==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||n==="textarea"||e.contentEditable==="true")}function vh(e){var n=sc(),t=e.focusedElem,o=e.selectionRange;if(n!==t&&t&&t.ownerDocument&&rc(t.ownerDocument.documentElement,t)){if(o!==null&&is(t)){if(n=o.start,e=o.end,e===void 0&&(e=n),"selectionStart"in t)t.selectionStart=n,t.selectionEnd=Math.min(e,t.value.length);else if(e=(n=t.ownerDocument||document)&&n.defaultView||window,e.getSelection){e=e.getSelection();var i=t.textContent.length,a=Math.min(o.start,i);o=o.end===void 0?a:Math.min(o.end,i),!e.extend&&a>o&&(i=o,o=a,a=i),i=jl(t,a);var r=jl(t,o);i&&r&&(e.rangeCount!==1||e.anchorNode!==i.node||e.anchorOffset!==i.offset||e.focusNode!==r.node||e.focusOffset!==r.offset)&&(n=n.createRange(),n.setStart(i.node,i.offset),e.removeAllRanges(),a>o?(e.addRange(n),e.extend(r.node,r.offset)):(n.setEnd(r.node,r.offset),e.addRange(n)))}}for(n=[],e=t;e=e.parentNode;)e.nodeType===1&&n.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof t.focus=="function"&&t.focus(),t=0;t<n.length;t++)e=n[t],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var kh=un&&"documentMode"in document&&11>=document.documentMode,gt=null,fr=null,po=null,yr=!1;function Dl(e,n,t){var o=t.window===t?t.document:t.nodeType===9?t:t.ownerDocument;yr||gt==null||gt!==wi(o)||(o=gt,"selectionStart"in o&&is(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),po&&ko(po,o)||(po=o,o=Ei(fr,"onSelect"),0<o.length&&(n=new ns("onSelect","select",null,n,t),e.push({event:n,listeners:o}),n.target=gt)))}function ni(e,n){var t={};return t[e.toLowerCase()]=n.toLowerCase(),t["Webkit"+e]="webkit"+n,t["Moz"+e]="moz"+n,t}var ft={animationend:ni("Animation","AnimationEnd"),animationiteration:ni("Animation","AnimationIteration"),animationstart:ni("Animation","AnimationStart"),transitionend:ni("Transition","TransitionEnd")},Da={},lc={};un&&(lc=document.createElement("div").style,"AnimationEvent"in window||(delete ft.animationend.animation,delete ft.animationiteration.animation,delete ft.animationstart.animation),"TransitionEvent"in window||delete ft.transitionend.transition);function Ki(e){if(Da[e])return Da[e];if(!ft[e])return e;var n=ft[e],t;for(t in n)if(n.hasOwnProperty(t)&&t in lc)return Da[e]=n[t];return e}var dc=Ki("animationend"),cc=Ki("animationiteration"),pc=Ki("animationstart"),uc=Ki("transitionend"),hc=new Map,Fl="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Dn(e,n){hc.set(e,n),tt(n,[e])}for(ti=0;ti<Fl.length;ti++)oi=Fl[ti],Hl=oi.toLowerCase(),Bl=oi[0].toUpperCase()+oi.slice(1),Dn(Hl,"on"+Bl);var oi,Hl,Bl,ti;Dn(dc,"onAnimationEnd");Dn(cc,"onAnimationIteration");Dn(pc,"onAnimationStart");Dn("dblclick","onDoubleClick");Dn("focusin","onFocus");Dn("focusout","onBlur");Dn(uc,"onTransitionEnd");Ot("onMouseEnter",["mouseout","mouseover"]);Ot("onMouseLeave",["mouseout","mouseover"]);Ot("onPointerEnter",["pointerout","pointerover"]);Ot("onPointerLeave",["pointerout","pointerover"]);tt("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));tt("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));tt("onBeforeInput",["compositionend","keypress","textInput","paste"]);tt("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));tt("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));tt("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var ao="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ch=new Set("cancel close invalid load scroll toggle".split(" ").concat(ao));function Vl(e,n,t){var o=e.type||"unknown-event";e.currentTarget=t,Cu(o,n,void 0,e),e.currentTarget=null}function mc(e,n){n=(n&4)!==0;for(var t=0;t<e.length;t++){var o=e[t],i=o.event;o=o.listeners;e:{var a=void 0;if(n)for(var r=o.length-1;0<=r;r--){var s=o[r],l=s.instance,c=s.currentTarget;if(s=s.listener,l!==a&&i.isPropagationStopped())break e;Vl(i,s,c),a=l}else for(r=0;r<o.length;r++){if(s=o[r],l=s.instance,c=s.currentTarget,s=s.listener,l!==a&&i.isPropagationStopped())break e;Vl(i,s,c),a=l}}}if(ki)throw e=ur,ki=!1,ur=null,e}function V(e,n){var t=n[vr];t===void 0&&(t=n[vr]=new Set);var o=e+"__bubble";t.has(o)||(gc(n,e,2,!1),t.add(o))}function Fa(e,n,t){var o=0;n&&(o|=4),gc(t,e,o,n)}var ii="_reactListening"+Math.random().toString(36).slice(2);function Co(e){if(!e[ii]){e[ii]=!0,vd.forEach(function(t){t!=="selectionchange"&&(Ch.has(t)||Fa(t,!1,e),Fa(t,!0,e))});var n=e.nodeType===9?e:e.ownerDocument;n===null||n[ii]||(n[ii]=!0,Fa("selectionchange",!1,n))}}function gc(e,n,t,o){switch(Zd(n)){case 1:var i=Hu;break;case 4:i=Bu;break;default:i=Jr}t=i.bind(null,n,t,e),i=void 0,!pr||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(i=!0),o?i!==void 0?e.addEventListener(n,t,{capture:!0,passive:i}):e.addEventListener(n,t,!0):i!==void 0?e.addEventListener(n,t,{passive:i}):e.addEventListener(n,t,!1)}function Ha(e,n,t,o,i){var a=o;if((n&1)===0&&(n&2)===0&&o!==null)e:for(;;){if(o===null)return;var r=o.tag;if(r===3||r===4){var s=o.stateNode.containerInfo;if(s===i||s.nodeType===8&&s.parentNode===i)break;if(r===4)for(r=o.return;r!==null;){var l=r.tag;if((l===3||l===4)&&(l=r.stateNode.containerInfo,l===i||l.nodeType===8&&l.parentNode===i))return;r=r.return}for(;s!==null;){if(r=$n(s),r===null)return;if(l=r.tag,l===5||l===6){o=a=r;continue e}s=s.parentNode}}o=o.return}Dd(function(){var c=a,f=Yr(t),h=[];e:{var g=hc.get(e);if(g!==void 0){var x=ns,w=e;switch(e){case"keypress":if(hi(t)===0)break e;case"keydown":case"keyup":x=th;break;case"focusin":w="focus",x=Ma;break;case"focusout":w="blur",x=Ma;break;case"beforeblur":case"afterblur":x=Ma;break;case"click":if(t.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":x=zl;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":x=Wu;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":x=ah;break;case dc:case cc:case pc:x=Qu;break;case uc:x=sh;break;case"scroll":x=Vu;break;case"wheel":x=dh;break;case"copy":case"cut":case"paste":x=Yu;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":x=Tl}var b=(n&4)!==0,M=!b&&e==="scroll",p=b?g!==null?g+"Capture":null:g;b=[];for(var d=c,u;d!==null;){u=d;var y=u.stateNode;if(u.tag===5&&y!==null&&(u=y,p!==null&&(y=_o(d,p),y!=null&&b.push(So(d,y,u)))),M)break;d=d.return}0<b.length&&(g=new x(g,w,null,t,f),h.push({event:g,listeners:b}))}}if((n&7)===0){e:{if(g=e==="mouseover"||e==="pointerover",x=e==="mouseout"||e==="pointerout",g&&t!==dr&&(w=t.relatedTarget||t.fromElement)&&($n(w)||w[hn]))break e;if((x||g)&&(g=f.window===f?f:(g=f.ownerDocument)?g.defaultView||g.parentWindow:window,x?(w=t.relatedTarget||t.toElement,x=c,w=w?$n(w):null,w!==null&&(M=ot(w),w!==M||w.tag!==5&&w.tag!==6)&&(w=null)):(x=null,w=c),x!==w)){if(b=zl,y="onMouseLeave",p="onMouseEnter",d="mouse",(e==="pointerout"||e==="pointerover")&&(b=Tl,y="onPointerLeave",p="onPointerEnter",d="pointer"),M=x==null?g:yt(x),u=w==null?g:yt(w),g=new b(y,d+"leave",x,t,f),g.target=M,g.relatedTarget=u,y=null,$n(f)===c&&(b=new b(p,d+"enter",w,t,f),b.target=u,b.relatedTarget=M,y=b),M=y,x&&w)n:{for(b=x,p=w,d=0,u=b;u;u=pt(u))d++;for(u=0,y=p;y;y=pt(y))u++;for(;0<d-u;)b=pt(b),d--;for(;0<u-d;)p=pt(p),u--;for(;d--;){if(b===p||p!==null&&b===p.alternate)break n;b=pt(b),p=pt(p)}b=null}else b=null;x!==null&&Ul(h,g,x,b,!1),w!==null&&M!==null&&Ul(h,M,w,b,!0)}}e:{if(g=c?yt(c):window,x=g.nodeName&&g.nodeName.toLowerCase(),x==="select"||x==="input"&&g.type==="file")var k=fh;else if(Al(g))if(ic)k=xh;else{k=_h;var C=yh}else(x=g.nodeName)&&x.toLowerCase()==="input"&&(g.type==="checkbox"||g.type==="radio")&&(k=bh);if(k&&(k=k(e,c))){oc(h,k,t,f);break e}C&&C(e,g,c),e==="focusout"&&(C=g._wrapperState)&&C.controlled&&g.type==="number"&&ir(g,"number",g.value)}switch(C=c?yt(c):window,e){case"focusin":(Al(C)||C.contentEditable==="true")&&(gt=C,fr=c,po=null);break;case"focusout":po=fr=gt=null;break;case"mousedown":yr=!0;break;case"contextmenu":case"mouseup":case"dragend":yr=!1,Dl(h,t,f);break;case"selectionchange":if(kh)break;case"keydown":case"keyup":Dl(h,t,f)}var S;if(os)e:{switch(e){case"compositionstart":var R="onCompositionStart";break e;case"compositionend":R="onCompositionEnd";break e;case"compositionupdate":R="onCompositionUpdate";break e}R=void 0}else mt?nc(e,t)&&(R="onCompositionEnd"):e==="keydown"&&t.keyCode===229&&(R="onCompositionStart");R&&(ec&&t.locale!=="ko"&&(mt||R!=="onCompositionStart"?R==="onCompositionEnd"&&mt&&(S=Jd()):(Rn=f,es="value"in Rn?Rn.value:Rn.textContent,mt=!0)),C=Ei(c,R),0<C.length&&(R=new Ol(R,e,null,t,f),h.push({event:R,listeners:C}),S?R.data=S:(S=tc(t),S!==null&&(R.data=S)))),(S=ph?uh(e,t):hh(e,t))&&(c=Ei(c,"onBeforeInput"),0<c.length&&(f=new Ol("onBeforeInput","beforeinput",null,t,f),h.push({event:f,listeners:c}),f.data=S))}mc(h,n)})}function So(e,n,t){return{instance:e,listener:n,currentTarget:t}}function Ei(e,n){for(var t=n+"Capture",o=[];e!==null;){var i=e,a=i.stateNode;i.tag===5&&a!==null&&(i=a,a=_o(e,t),a!=null&&o.unshift(So(e,a,i)),a=_o(e,n),a!=null&&o.push(So(e,a,i))),e=e.return}return o}function pt(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function Ul(e,n,t,o,i){for(var a=n._reactName,r=[];t!==null&&t!==o;){var s=t,l=s.alternate,c=s.stateNode;if(l!==null&&l===o)break;s.tag===5&&c!==null&&(s=c,i?(l=_o(t,a),l!=null&&r.unshift(So(t,l,s))):i||(l=_o(t,a),l!=null&&r.push(So(t,l,s)))),t=t.return}r.length!==0&&e.push({event:n,listeners:r})}var Sh=/\r\n?/g,Rh=/\u0000|\uFFFD/g;function Wl(e){return(typeof e=="string"?e:""+e).replace(Sh,`
`).replace(Rh,"")}function ai(e,n,t){if(n=Wl(n),Wl(e)!==n&&t)throw Error(_(425))}function zi(){}var _r=null,br=null;function xr(e,n){return e==="textarea"||e==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var wr=typeof setTimeout=="function"?setTimeout:void 0,Ih=typeof clearTimeout=="function"?clearTimeout:void 0,Gl=typeof Promise=="function"?Promise:void 0,Eh=typeof queueMicrotask=="function"?queueMicrotask:typeof Gl<"u"?function(e){return Gl.resolve(null).then(e).catch(zh)}:wr;function zh(e){setTimeout(function(){throw e})}function Ba(e,n){var t=n,o=0;do{var i=t.nextSibling;if(e.removeChild(t),i&&i.nodeType===8)if(t=i.data,t==="/$"){if(o===0){e.removeChild(i),wo(n);return}o--}else t!=="$"&&t!=="$?"&&t!=="$!"||o++;t=i}while(t);wo(n)}function Tn(e){for(;e!=null;e=e.nextSibling){var n=e.nodeType;if(n===1||n===3)break;if(n===8){if(n=e.data,n==="$"||n==="$!"||n==="$?")break;if(n==="/$")return null}}return e}function $l(e){e=e.previousSibling;for(var n=0;e;){if(e.nodeType===8){var t=e.data;if(t==="$"||t==="$!"||t==="$?"){if(n===0)return e;n--}else t==="/$"&&n++}e=e.previousSibling}return null}var Dt=Math.random().toString(36).slice(2),on="__reactFiber$"+Dt,Ro="__reactProps$"+Dt,hn="__reactContainer$"+Dt,vr="__reactEvents$"+Dt,Oh="__reactListeners$"+Dt,Th="__reactHandles$"+Dt;function $n(e){var n=e[on];if(n)return n;for(var t=e.parentNode;t;){if(n=t[hn]||t[on]){if(t=n.alternate,n.child!==null||t!==null&&t.child!==null)for(e=$l(e);e!==null;){if(t=e[on])return t;e=$l(e)}return n}e=t,t=e.parentNode}return null}function Po(e){return e=e[on]||e[hn],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function yt(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(_(33))}function Yi(e){return e[Ro]||null}var kr=[],_t=-1;function Fn(e){return{current:e}}function U(e){0>_t||(e.current=kr[_t],kr[_t]=null,_t--)}function D(e,n){_t++,kr[_t]=e.current,e.current=n}var jn={},he=Fn(jn),Re=Fn(!1),Xn=jn;function Tt(e,n){var t=e.type.contextTypes;if(!t)return jn;var o=e.stateNode;if(o&&o.__reactInternalMemoizedUnmaskedChildContext===n)return o.__reactInternalMemoizedMaskedChildContext;var i={},a;for(a in t)i[a]=n[a];return o&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=n,e.__reactInternalMemoizedMaskedChildContext=i),i}function Ie(e){return e=e.childContextTypes,e!=null}function Oi(){U(Re),U(he)}function Ql(e,n,t){if(he.current!==jn)throw Error(_(168));D(he,n),D(Re,t)}function fc(e,n,t){var o=e.stateNode;if(n=n.childContextTypes,typeof o.getChildContext!="function")return t;o=o.getChildContext();for(var i in o)if(!(i in n))throw Error(_(108,yu(e)||"Unknown",i));return K({},t,o)}function Ti(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||jn,Xn=he.current,D(he,e),D(Re,Re.current),!0}function Kl(e,n,t){var o=e.stateNode;if(!o)throw Error(_(169));t?(e=fc(e,n,Xn),o.__reactInternalMemoizedMergedChildContext=e,U(Re),U(he),D(he,e)):U(Re),D(Re,t)}var ln=null,qi=!1,Va=!1;function yc(e){ln===null?ln=[e]:ln.push(e)}function Lh(e){qi=!0,yc(e)}function Hn(){if(!Va&&ln!==null){Va=!0;var e=0,n=P;try{var t=ln;for(P=1;e<t.length;e++){var o=t[e];do o=o(!0);while(o!==null)}ln=null,qi=!1}catch(i){throw ln!==null&&(ln=ln.slice(e+1)),Vd(qr,Hn),i}finally{P=n,Va=!1}}return null}var bt=[],xt=0,Li=null,Ni=0,Me=[],je=0,Zn=null,dn=1,cn="";function Wn(e,n){bt[xt++]=Ni,bt[xt++]=Li,Li=e,Ni=n}function _c(e,n,t){Me[je++]=dn,Me[je++]=cn,Me[je++]=Zn,Zn=e;var o=dn;e=cn;var i=32-Ke(o)-1;o&=~(1<<i),t+=1;var a=32-Ke(n)+i;if(30<a){var r=i-i%5;a=(o&(1<<r)-1).toString(32),o>>=r,i-=r,dn=1<<32-Ke(n)+i|t<<i|o,cn=a+e}else dn=1<<a|t<<i|o,cn=e}function as(e){e.return!==null&&(Wn(e,1),_c(e,1,0))}function rs(e){for(;e===Li;)Li=bt[--xt],bt[xt]=null,Ni=bt[--xt],bt[xt]=null;for(;e===Zn;)Zn=Me[--je],Me[je]=null,cn=Me[--je],Me[je]=null,dn=Me[--je],Me[je]=null}var Te=null,Oe=null,W=!1,Qe=null;function bc(e,n){var t=De(5,null,null,0);t.elementType="DELETED",t.stateNode=n,t.return=e,n=e.deletions,n===null?(e.deletions=[t],e.flags|=16):n.push(t)}function Yl(e,n){switch(e.tag){case 5:var t=e.type;return n=n.nodeType!==1||t.toLowerCase()!==n.nodeName.toLowerCase()?null:n,n!==null?(e.stateNode=n,Te=e,Oe=Tn(n.firstChild),!0):!1;case 6:return n=e.pendingProps===""||n.nodeType!==3?null:n,n!==null?(e.stateNode=n,Te=e,Oe=null,!0):!1;case 13:return n=n.nodeType!==8?null:n,n!==null?(t=Zn!==null?{id:dn,overflow:cn}:null,e.memoizedState={dehydrated:n,treeContext:t,retryLane:1073741824},t=De(18,null,null,0),t.stateNode=n,t.return=e,e.child=t,Te=e,Oe=null,!0):!1;default:return!1}}function Cr(e){return(e.mode&1)!==0&&(e.flags&128)===0}function Sr(e){if(W){var n=Oe;if(n){var t=n;if(!Yl(e,n)){if(Cr(e))throw Error(_(418));n=Tn(t.nextSibling);var o=Te;n&&Yl(e,n)?bc(o,t):(e.flags=e.flags&-4097|2,W=!1,Te=e)}}else{if(Cr(e))throw Error(_(418));e.flags=e.flags&-4097|2,W=!1,Te=e}}}function ql(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;Te=e}function ri(e){if(e!==Te)return!1;if(!W)return ql(e),W=!0,!1;var n;if((n=e.tag!==3)&&!(n=e.tag!==5)&&(n=e.type,n=n!=="head"&&n!=="body"&&!xr(e.type,e.memoizedProps)),n&&(n=Oe)){if(Cr(e))throw xc(),Error(_(418));for(;n;)bc(e,n),n=Tn(n.nextSibling)}if(ql(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(_(317));e:{for(e=e.nextSibling,n=0;e;){if(e.nodeType===8){var t=e.data;if(t==="/$"){if(n===0){Oe=Tn(e.nextSibling);break e}n--}else t!=="$"&&t!=="$!"&&t!=="$?"||n++}e=e.nextSibling}Oe=null}}else Oe=Te?Tn(e.stateNode.nextSibling):null;return!0}function xc(){for(var e=Oe;e;)e=Tn(e.nextSibling)}function Lt(){Oe=Te=null,W=!1}function ss(e){Qe===null?Qe=[e]:Qe.push(e)}var Nh=fn.ReactCurrentBatchConfig;function Zt(e,n,t){if(e=t.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(t._owner){if(t=t._owner,t){if(t.tag!==1)throw Error(_(309));var o=t.stateNode}if(!o)throw Error(_(147,e));var i=o,a=""+e;return n!==null&&n.ref!==null&&typeof n.ref=="function"&&n.ref._stringRef===a?n.ref:(n=function(r){var s=i.refs;r===null?delete s[a]:s[a]=r},n._stringRef=a,n)}if(typeof e!="string")throw Error(_(284));if(!t._owner)throw Error(_(290,e))}return e}function si(e,n){throw e=Object.prototype.toString.call(n),Error(_(31,e==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":e))}function Xl(e){var n=e._init;return n(e._payload)}function wc(e){function n(p,d){if(e){var u=p.deletions;u===null?(p.deletions=[d],p.flags|=16):u.push(d)}}function t(p,d){if(!e)return null;for(;d!==null;)n(p,d),d=d.sibling;return null}function o(p,d){for(p=new Map;d!==null;)d.key!==null?p.set(d.key,d):p.set(d.index,d),d=d.sibling;return p}function i(p,d){return p=Pn(p,d),p.index=0,p.sibling=null,p}function a(p,d,u){return p.index=u,e?(u=p.alternate,u!==null?(u=u.index,u<d?(p.flags|=2,d):u):(p.flags|=2,d)):(p.flags|=1048576,d)}function r(p){return e&&p.alternate===null&&(p.flags|=2),p}function s(p,d,u,y){return d===null||d.tag!==6?(d=Ya(u,p.mode,y),d.return=p,d):(d=i(d,u),d.return=p,d)}function l(p,d,u,y){var k=u.type;return k===ht?f(p,d,u.props.children,y,u.key):d!==null&&(d.elementType===k||typeof k=="object"&&k!==null&&k.$$typeof===vn&&Xl(k)===d.type)?(y=i(d,u.props),y.ref=Zt(p,d,u),y.return=p,y):(y=xi(u.type,u.key,u.props,null,p.mode,y),y.ref=Zt(p,d,u),y.return=p,y)}function c(p,d,u,y){return d===null||d.tag!==4||d.stateNode.containerInfo!==u.containerInfo||d.stateNode.implementation!==u.implementation?(d=qa(u,p.mode,y),d.return=p,d):(d=i(d,u.children||[]),d.return=p,d)}function f(p,d,u,y,k){return d===null||d.tag!==7?(d=qn(u,p.mode,y,k),d.return=p,d):(d=i(d,u),d.return=p,d)}function h(p,d,u){if(typeof d=="string"&&d!==""||typeof d=="number")return d=Ya(""+d,p.mode,u),d.return=p,d;if(typeof d=="object"&&d!==null){switch(d.$$typeof){case $o:return u=xi(d.type,d.key,d.props,null,p.mode,u),u.ref=Zt(p,null,d),u.return=p,u;case ut:return d=qa(d,p.mode,u),d.return=p,d;case vn:var y=d._init;return h(p,y(d._payload),u)}if(oo(d)||Kt(d))return d=qn(d,p.mode,u,null),d.return=p,d;si(p,d)}return null}function g(p,d,u,y){var k=d!==null?d.key:null;if(typeof u=="string"&&u!==""||typeof u=="number")return k!==null?null:s(p,d,""+u,y);if(typeof u=="object"&&u!==null){switch(u.$$typeof){case $o:return u.key===k?l(p,d,u,y):null;case ut:return u.key===k?c(p,d,u,y):null;case vn:return k=u._init,g(p,d,k(u._payload),y)}if(oo(u)||Kt(u))return k!==null?null:f(p,d,u,y,null);si(p,u)}return null}function x(p,d,u,y,k){if(typeof y=="string"&&y!==""||typeof y=="number")return p=p.get(u)||null,s(d,p,""+y,k);if(typeof y=="object"&&y!==null){switch(y.$$typeof){case $o:return p=p.get(y.key===null?u:y.key)||null,l(d,p,y,k);case ut:return p=p.get(y.key===null?u:y.key)||null,c(d,p,y,k);case vn:var C=y._init;return x(p,d,u,C(y._payload),k)}if(oo(y)||Kt(y))return p=p.get(u)||null,f(d,p,y,k,null);si(d,y)}return null}function w(p,d,u,y){for(var k=null,C=null,S=d,R=d=0,X=null;S!==null&&R<u.length;R++){S.index>R?(X=S,S=null):X=S.sibling;var L=g(p,S,u[R],y);if(L===null){S===null&&(S=X);break}e&&S&&L.alternate===null&&n(p,S),d=a(L,d,R),C===null?k=L:C.sibling=L,C=L,S=X}if(R===u.length)return t(p,S),W&&Wn(p,R),k;if(S===null){for(;R<u.length;R++)S=h(p,u[R],y),S!==null&&(d=a(S,d,R),C===null?k=S:C.sibling=S,C=S);return W&&Wn(p,R),k}for(S=o(p,S);R<u.length;R++)X=x(S,p,R,u[R],y),X!==null&&(e&&X.alternate!==null&&S.delete(X.key===null?R:X.key),d=a(X,d,R),C===null?k=X:C.sibling=X,C=X);return e&&S.forEach(function(ve){return n(p,ve)}),W&&Wn(p,R),k}function b(p,d,u,y){var k=Kt(u);if(typeof k!="function")throw Error(_(150));if(u=k.call(u),u==null)throw Error(_(151));for(var C=k=null,S=d,R=d=0,X=null,L=u.next();S!==null&&!L.done;R++,L=u.next()){S.index>R?(X=S,S=null):X=S.sibling;var ve=g(p,S,L.value,y);if(ve===null){S===null&&(S=X);break}e&&S&&ve.alternate===null&&n(p,S),d=a(ve,d,R),C===null?k=ve:C.sibling=ve,C=ve,S=X}if(L.done)return t(p,S),W&&Wn(p,R),k;if(S===null){for(;!L.done;R++,L=u.next())L=h(p,L.value,y),L!==null&&(d=a(L,d,R),C===null?k=L:C.sibling=L,C=L);return W&&Wn(p,R),k}for(S=o(p,S);!L.done;R++,L=u.next())L=x(S,p,R,L.value,y),L!==null&&(e&&L.alternate!==null&&S.delete(L.key===null?R:L.key),d=a(L,d,R),C===null?k=L:C.sibling=L,C=L);return e&&S.forEach(function(Ht){return n(p,Ht)}),W&&Wn(p,R),k}function M(p,d,u,y){if(typeof u=="object"&&u!==null&&u.type===ht&&u.key===null&&(u=u.props.children),typeof u=="object"&&u!==null){switch(u.$$typeof){case $o:e:{for(var k=u.key,C=d;C!==null;){if(C.key===k){if(k=u.type,k===ht){if(C.tag===7){t(p,C.sibling),d=i(C,u.props.children),d.return=p,p=d;break e}}else if(C.elementType===k||typeof k=="object"&&k!==null&&k.$$typeof===vn&&Xl(k)===C.type){t(p,C.sibling),d=i(C,u.props),d.ref=Zt(p,C,u),d.return=p,p=d;break e}t(p,C);break}else n(p,C);C=C.sibling}u.type===ht?(d=qn(u.props.children,p.mode,y,u.key),d.return=p,p=d):(y=xi(u.type,u.key,u.props,null,p.mode,y),y.ref=Zt(p,d,u),y.return=p,p=y)}return r(p);case ut:e:{for(C=u.key;d!==null;){if(d.key===C)if(d.tag===4&&d.stateNode.containerInfo===u.containerInfo&&d.stateNode.implementation===u.implementation){t(p,d.sibling),d=i(d,u.children||[]),d.return=p,p=d;break e}else{t(p,d);break}else n(p,d);d=d.sibling}d=qa(u,p.mode,y),d.return=p,p=d}return r(p);case vn:return C=u._init,M(p,d,C(u._payload),y)}if(oo(u))return w(p,d,u,y);if(Kt(u))return b(p,d,u,y);si(p,u)}return typeof u=="string"&&u!==""||typeof u=="number"?(u=""+u,d!==null&&d.tag===6?(t(p,d.sibling),d=i(d,u),d.return=p,p=d):(t(p,d),d=Ya(u,p.mode,y),d.return=p,p=d),r(p)):t(p,d)}return M}var Nt=wc(!0),vc=wc(!1),Ai=Fn(null),Pi=null,wt=null,ls=null;function ds(){ls=wt=Pi=null}function cs(e){var n=Ai.current;U(Ai),e._currentValue=n}function Rr(e,n,t){for(;e!==null;){var o=e.alternate;if((e.childLanes&n)!==n?(e.childLanes|=n,o!==null&&(o.childLanes|=n)):o!==null&&(o.childLanes&n)!==n&&(o.childLanes|=n),e===t)break;e=e.return}}function Et(e,n){Pi=e,ls=wt=null,e=e.dependencies,e!==null&&e.firstContext!==null&&((e.lanes&n)!==0&&(Se=!0),e.firstContext=null)}function He(e){var n=e._currentValue;if(ls!==e)if(e={context:e,memoizedValue:n,next:null},wt===null){if(Pi===null)throw Error(_(308));wt=e,Pi.dependencies={lanes:0,firstContext:e}}else wt=wt.next=e;return n}var Qn=null;function ps(e){Qn===null?Qn=[e]:Qn.push(e)}function kc(e,n,t,o){var i=n.interleaved;return i===null?(t.next=t,ps(n)):(t.next=i.next,i.next=t),n.interleaved=t,mn(e,o)}function mn(e,n){e.lanes|=n;var t=e.alternate;for(t!==null&&(t.lanes|=n),t=e,e=e.return;e!==null;)e.childLanes|=n,t=e.alternate,t!==null&&(t.childLanes|=n),t=e,e=e.return;return t.tag===3?t.stateNode:null}var kn=!1;function us(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Cc(e,n){e=e.updateQueue,n.updateQueue===e&&(n.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function pn(e,n){return{eventTime:e,lane:n,tag:0,payload:null,callback:null,next:null}}function Ln(e,n,t){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(A&2)!==0){var i=o.pending;return i===null?n.next=n:(n.next=i.next,i.next=n),o.pending=n,mn(e,t)}return i=o.interleaved,i===null?(n.next=n,ps(o)):(n.next=i.next,i.next=n),o.interleaved=n,mn(e,t)}function mi(e,n,t){if(n=n.updateQueue,n!==null&&(n=n.shared,(t&4194240)!==0)){var o=n.lanes;o&=e.pendingLanes,t|=o,n.lanes=t,Xr(e,t)}}function Zl(e,n){var t=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,t===o)){var i=null,a=null;if(t=t.firstBaseUpdate,t!==null){do{var r={eventTime:t.eventTime,lane:t.lane,tag:t.tag,payload:t.payload,callback:t.callback,next:null};a===null?i=a=r:a=a.next=r,t=t.next}while(t!==null);a===null?i=a=n:a=a.next=n}else i=a=n;t={baseState:o.baseState,firstBaseUpdate:i,lastBaseUpdate:a,shared:o.shared,effects:o.effects},e.updateQueue=t;return}e=t.lastBaseUpdate,e===null?t.firstBaseUpdate=n:e.next=n,t.lastBaseUpdate=n}function Mi(e,n,t,o){var i=e.updateQueue;kn=!1;var a=i.firstBaseUpdate,r=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var l=s,c=l.next;l.next=null,r===null?a=c:r.next=c,r=l;var f=e.alternate;f!==null&&(f=f.updateQueue,s=f.lastBaseUpdate,s!==r&&(s===null?f.firstBaseUpdate=c:s.next=c,f.lastBaseUpdate=l))}if(a!==null){var h=i.baseState;r=0,f=c=l=null,s=a;do{var g=s.lane,x=s.eventTime;if((o&g)===g){f!==null&&(f=f.next={eventTime:x,lane:0,tag:s.tag,payload:s.payload,callback:s.callback,next:null});e:{var w=e,b=s;switch(g=n,x=t,b.tag){case 1:if(w=b.payload,typeof w=="function"){h=w.call(x,h,g);break e}h=w;break e;case 3:w.flags=w.flags&-65537|128;case 0:if(w=b.payload,g=typeof w=="function"?w.call(x,h,g):w,g==null)break e;h=K({},h,g);break e;case 2:kn=!0}}s.callback!==null&&s.lane!==0&&(e.flags|=64,g=i.effects,g===null?i.effects=[s]:g.push(s))}else x={eventTime:x,lane:g,tag:s.tag,payload:s.payload,callback:s.callback,next:null},f===null?(c=f=x,l=h):f=f.next=x,r|=g;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;g=s,s=g.next,g.next=null,i.lastBaseUpdate=g,i.shared.pending=null}}while(!0);if(f===null&&(l=h),i.baseState=l,i.firstBaseUpdate=c,i.lastBaseUpdate=f,n=i.shared.interleaved,n!==null){i=n;do r|=i.lane,i=i.next;while(i!==n)}else a===null&&(i.shared.lanes=0);et|=r,e.lanes=r,e.memoizedState=h}}function Jl(e,n,t){if(e=n.effects,n.effects=null,e!==null)for(n=0;n<e.length;n++){var o=e[n],i=o.callback;if(i!==null){if(o.callback=null,o=t,typeof i!="function")throw Error(_(191,i));i.call(o)}}}var Mo={},rn=Fn(Mo),Io=Fn(Mo),Eo=Fn(Mo);function Kn(e){if(e===Mo)throw Error(_(174));return e}function hs(e,n){switch(D(Eo,n),D(Io,e),D(rn,Mo),e=n.nodeType,e){case 9:case 11:n=(n=n.documentElement)?n.namespaceURI:rr(null,"");break;default:e=e===8?n.parentNode:n,n=e.namespaceURI||null,e=e.tagName,n=rr(n,e)}U(rn),D(rn,n)}function At(){U(rn),U(Io),U(Eo)}function Sc(e){Kn(Eo.current);var n=Kn(rn.current),t=rr(n,e.type);n!==t&&(D(Io,e),D(rn,t))}function ms(e){Io.current===e&&(U(rn),U(Io))}var $=Fn(0);function ji(e){for(var n=e;n!==null;){if(n.tag===13){var t=n.memoizedState;if(t!==null&&(t=t.dehydrated,t===null||t.data==="$?"||t.data==="$!"))return n}else if(n.tag===19&&n.memoizedProps.revealOrder!==void 0){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var Ua=[];function gs(){for(var e=0;e<Ua.length;e++)Ua[e]._workInProgressVersionPrimary=null;Ua.length=0}var gi=fn.ReactCurrentDispatcher,Wa=fn.ReactCurrentBatchConfig,Jn=0,Q=null,ee=null,ie=null,Di=!1,uo=!1,zo=0,Ah=0;function ce(){throw Error(_(321))}function fs(e,n){if(n===null)return!1;for(var t=0;t<n.length&&t<e.length;t++)if(!qe(e[t],n[t]))return!1;return!0}function ys(e,n,t,o,i,a){if(Jn=a,Q=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,gi.current=e===null||e.memoizedState===null?Dh:Fh,e=t(o,i),uo){a=0;do{if(uo=!1,zo=0,25<=a)throw Error(_(301));a+=1,ie=ee=null,n.updateQueue=null,gi.current=Hh,e=t(o,i)}while(uo)}if(gi.current=Fi,n=ee!==null&&ee.next!==null,Jn=0,ie=ee=Q=null,Di=!1,n)throw Error(_(300));return e}function _s(){var e=zo!==0;return zo=0,e}function tn(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return ie===null?Q.memoizedState=ie=e:ie=ie.next=e,ie}function Be(){if(ee===null){var e=Q.alternate;e=e!==null?e.memoizedState:null}else e=ee.next;var n=ie===null?Q.memoizedState:ie.next;if(n!==null)ie=n,ee=e;else{if(e===null)throw Error(_(310));ee=e,e={memoizedState:ee.memoizedState,baseState:ee.baseState,baseQueue:ee.baseQueue,queue:ee.queue,next:null},ie===null?Q.memoizedState=ie=e:ie=ie.next=e}return ie}function Oo(e,n){return typeof n=="function"?n(e):n}function Ga(e){var n=Be(),t=n.queue;if(t===null)throw Error(_(311));t.lastRenderedReducer=e;var o=ee,i=o.baseQueue,a=t.pending;if(a!==null){if(i!==null){var r=i.next;i.next=a.next,a.next=r}o.baseQueue=i=a,t.pending=null}if(i!==null){a=i.next,o=o.baseState;var s=r=null,l=null,c=a;do{var f=c.lane;if((Jn&f)===f)l!==null&&(l=l.next={lane:0,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null}),o=c.hasEagerState?c.eagerState:e(o,c.action);else{var h={lane:f,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null};l===null?(s=l=h,r=o):l=l.next=h,Q.lanes|=f,et|=f}c=c.next}while(c!==null&&c!==a);l===null?r=o:l.next=s,qe(o,n.memoizedState)||(Se=!0),n.memoizedState=o,n.baseState=r,n.baseQueue=l,t.lastRenderedState=o}if(e=t.interleaved,e!==null){i=e;do a=i.lane,Q.lanes|=a,et|=a,i=i.next;while(i!==e)}else i===null&&(t.lanes=0);return[n.memoizedState,t.dispatch]}function $a(e){var n=Be(),t=n.queue;if(t===null)throw Error(_(311));t.lastRenderedReducer=e;var o=t.dispatch,i=t.pending,a=n.memoizedState;if(i!==null){t.pending=null;var r=i=i.next;do a=e(a,r.action),r=r.next;while(r!==i);qe(a,n.memoizedState)||(Se=!0),n.memoizedState=a,n.baseQueue===null&&(n.baseState=a),t.lastRenderedState=a}return[a,o]}function Rc(){}function Ic(e,n){var t=Q,o=Be(),i=n(),a=!qe(o.memoizedState,i);if(a&&(o.memoizedState=i,Se=!0),o=o.queue,bs(Oc.bind(null,t,o,e),[e]),o.getSnapshot!==n||a||ie!==null&&ie.memoizedState.tag&1){if(t.flags|=2048,To(9,zc.bind(null,t,o,i,n),void 0,null),ae===null)throw Error(_(349));(Jn&30)!==0||Ec(t,n,i)}return i}function Ec(e,n,t){e.flags|=16384,e={getSnapshot:n,value:t},n=Q.updateQueue,n===null?(n={lastEffect:null,stores:null},Q.updateQueue=n,n.stores=[e]):(t=n.stores,t===null?n.stores=[e]:t.push(e))}function zc(e,n,t,o){n.value=t,n.getSnapshot=o,Tc(n)&&Lc(e)}function Oc(e,n,t){return t(function(){Tc(n)&&Lc(e)})}function Tc(e){var n=e.getSnapshot;e=e.value;try{var t=n();return!qe(e,t)}catch{return!0}}function Lc(e){var n=mn(e,1);n!==null&&Ye(n,e,1,-1)}function ed(e){var n=tn();return typeof e=="function"&&(e=e()),n.memoizedState=n.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Oo,lastRenderedState:e},n.queue=e,e=e.dispatch=jh.bind(null,Q,e),[n.memoizedState,e]}function To(e,n,t,o){return e={tag:e,create:n,destroy:t,deps:o,next:null},n=Q.updateQueue,n===null?(n={lastEffect:null,stores:null},Q.updateQueue=n,n.lastEffect=e.next=e):(t=n.lastEffect,t===null?n.lastEffect=e.next=e:(o=t.next,t.next=e,e.next=o,n.lastEffect=e)),e}function Nc(){return Be().memoizedState}function fi(e,n,t,o){var i=tn();Q.flags|=e,i.memoizedState=To(1|n,t,void 0,o===void 0?null:o)}function Xi(e,n,t,o){var i=Be();o=o===void 0?null:o;var a=void 0;if(ee!==null){var r=ee.memoizedState;if(a=r.destroy,o!==null&&fs(o,r.deps)){i.memoizedState=To(n,t,a,o);return}}Q.flags|=e,i.memoizedState=To(1|n,t,a,o)}function nd(e,n){return fi(8390656,8,e,n)}function bs(e,n){return Xi(2048,8,e,n)}function Ac(e,n){return Xi(4,2,e,n)}function Pc(e,n){return Xi(4,4,e,n)}function Mc(e,n){if(typeof n=="function")return e=e(),n(e),function(){n(null)};if(n!=null)return e=e(),n.current=e,function(){n.current=null}}function jc(e,n,t){return t=t!=null?t.concat([e]):null,Xi(4,4,Mc.bind(null,n,e),t)}function xs(){}function Dc(e,n){var t=Be();n=n===void 0?null:n;var o=t.memoizedState;return o!==null&&n!==null&&fs(n,o[1])?o[0]:(t.memoizedState=[e,n],e)}function Fc(e,n){var t=Be();n=n===void 0?null:n;var o=t.memoizedState;return o!==null&&n!==null&&fs(n,o[1])?o[0]:(e=e(),t.memoizedState=[e,n],e)}function Hc(e,n,t){return(Jn&21)===0?(e.baseState&&(e.baseState=!1,Se=!0),e.memoizedState=t):(qe(t,n)||(t=Gd(),Q.lanes|=t,et|=t,e.baseState=!0),n)}function Ph(e,n){var t=P;P=t!==0&&4>t?t:4,e(!0);var o=Wa.transition;Wa.transition={};try{e(!1),n()}finally{P=t,Wa.transition=o}}function Bc(){return Be().memoizedState}function Mh(e,n,t){var o=An(e);if(t={lane:o,action:t,hasEagerState:!1,eagerState:null,next:null},Vc(e))Uc(n,t);else if(t=kc(e,n,t,o),t!==null){var i=_e();Ye(t,e,o,i),Wc(t,n,o)}}function jh(e,n,t){var o=An(e),i={lane:o,action:t,hasEagerState:!1,eagerState:null,next:null};if(Vc(e))Uc(n,i);else{var a=e.alternate;if(e.lanes===0&&(a===null||a.lanes===0)&&(a=n.lastRenderedReducer,a!==null))try{var r=n.lastRenderedState,s=a(r,t);if(i.hasEagerState=!0,i.eagerState=s,qe(s,r)){var l=n.interleaved;l===null?(i.next=i,ps(n)):(i.next=l.next,l.next=i),n.interleaved=i;return}}catch{}t=kc(e,n,i,o),t!==null&&(i=_e(),Ye(t,e,o,i),Wc(t,n,o))}}function Vc(e){var n=e.alternate;return e===Q||n!==null&&n===Q}function Uc(e,n){uo=Di=!0;var t=e.pending;t===null?n.next=n:(n.next=t.next,t.next=n),e.pending=n}function Wc(e,n,t){if((t&4194240)!==0){var o=n.lanes;o&=e.pendingLanes,t|=o,n.lanes=t,Xr(e,t)}}var Fi={readContext:He,useCallback:ce,useContext:ce,useEffect:ce,useImperativeHandle:ce,useInsertionEffect:ce,useLayoutEffect:ce,useMemo:ce,useReducer:ce,useRef:ce,useState:ce,useDebugValue:ce,useDeferredValue:ce,useTransition:ce,useMutableSource:ce,useSyncExternalStore:ce,useId:ce,unstable_isNewReconciler:!1},Dh={readContext:He,useCallback:function(e,n){return tn().memoizedState=[e,n===void 0?null:n],e},useContext:He,useEffect:nd,useImperativeHandle:function(e,n,t){return t=t!=null?t.concat([e]):null,fi(4194308,4,Mc.bind(null,n,e),t)},useLayoutEffect:function(e,n){return fi(4194308,4,e,n)},useInsertionEffect:function(e,n){return fi(4,2,e,n)},useMemo:function(e,n){var t=tn();return n=n===void 0?null:n,e=e(),t.memoizedState=[e,n],e},useReducer:function(e,n,t){var o=tn();return n=t!==void 0?t(n):n,o.memoizedState=o.baseState=n,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:n},o.queue=e,e=e.dispatch=Mh.bind(null,Q,e),[o.memoizedState,e]},useRef:function(e){var n=tn();return e={current:e},n.memoizedState=e},useState:ed,useDebugValue:xs,useDeferredValue:function(e){return tn().memoizedState=e},useTransition:function(){var e=ed(!1),n=e[0];return e=Ph.bind(null,e[1]),tn().memoizedState=e,[n,e]},useMutableSource:function(){},useSyncExternalStore:function(e,n,t){var o=Q,i=tn();if(W){if(t===void 0)throw Error(_(407));t=t()}else{if(t=n(),ae===null)throw Error(_(349));(Jn&30)!==0||Ec(o,n,t)}i.memoizedState=t;var a={value:t,getSnapshot:n};return i.queue=a,nd(Oc.bind(null,o,a,e),[e]),o.flags|=2048,To(9,zc.bind(null,o,a,t,n),void 0,null),t},useId:function(){var e=tn(),n=ae.identifierPrefix;if(W){var t=cn,o=dn;t=(o&~(1<<32-Ke(o)-1)).toString(32)+t,n=":"+n+"R"+t,t=zo++,0<t&&(n+="H"+t.toString(32)),n+=":"}else t=Ah++,n=":"+n+"r"+t.toString(32)+":";return e.memoizedState=n},unstable_isNewReconciler:!1},Fh={readContext:He,useCallback:Dc,useContext:He,useEffect:bs,useImperativeHandle:jc,useInsertionEffect:Ac,useLayoutEffect:Pc,useMemo:Fc,useReducer:Ga,useRef:Nc,useState:function(){return Ga(Oo)},useDebugValue:xs,useDeferredValue:function(e){var n=Be();return Hc(n,ee.memoizedState,e)},useTransition:function(){var e=Ga(Oo)[0],n=Be().memoizedState;return[e,n]},useMutableSource:Rc,useSyncExternalStore:Ic,useId:Bc,unstable_isNewReconciler:!1},Hh={readContext:He,useCallback:Dc,useContext:He,useEffect:bs,useImperativeHandle:jc,useInsertionEffect:Ac,useLayoutEffect:Pc,useMemo:Fc,useReducer:$a,useRef:Nc,useState:function(){return $a(Oo)},useDebugValue:xs,useDeferredValue:function(e){var n=Be();return ee===null?n.memoizedState=e:Hc(n,ee.memoizedState,e)},useTransition:function(){var e=$a(Oo)[0],n=Be().memoizedState;return[e,n]},useMutableSource:Rc,useSyncExternalStore:Ic,useId:Bc,unstable_isNewReconciler:!1};function Ge(e,n){if(e&&e.defaultProps){n=K({},n),e=e.defaultProps;for(var t in e)n[t]===void 0&&(n[t]=e[t]);return n}return n}function Ir(e,n,t,o){n=e.memoizedState,t=t(o,n),t=t==null?n:K({},n,t),e.memoizedState=t,e.lanes===0&&(e.updateQueue.baseState=t)}var Zi={isMounted:function(e){return(e=e._reactInternals)?ot(e)===e:!1},enqueueSetState:function(e,n,t){e=e._reactInternals;var o=_e(),i=An(e),a=pn(o,i);a.payload=n,t!=null&&(a.callback=t),n=Ln(e,a,i),n!==null&&(Ye(n,e,i,o),mi(n,e,i))},enqueueReplaceState:function(e,n,t){e=e._reactInternals;var o=_e(),i=An(e),a=pn(o,i);a.tag=1,a.payload=n,t!=null&&(a.callback=t),n=Ln(e,a,i),n!==null&&(Ye(n,e,i,o),mi(n,e,i))},enqueueForceUpdate:function(e,n){e=e._reactInternals;var t=_e(),o=An(e),i=pn(t,o);i.tag=2,n!=null&&(i.callback=n),n=Ln(e,i,o),n!==null&&(Ye(n,e,o,t),mi(n,e,o))}};function td(e,n,t,o,i,a,r){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,a,r):n.prototype&&n.prototype.isPureReactComponent?!ko(t,o)||!ko(i,a):!0}function Gc(e,n,t){var o=!1,i=jn,a=n.contextType;return typeof a=="object"&&a!==null?a=He(a):(i=Ie(n)?Xn:he.current,o=n.contextTypes,a=(o=o!=null)?Tt(e,i):jn),n=new n(t,a),e.memoizedState=n.state!==null&&n.state!==void 0?n.state:null,n.updater=Zi,e.stateNode=n,n._reactInternals=e,o&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=i,e.__reactInternalMemoizedMaskedChildContext=a),n}function od(e,n,t,o){e=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(t,o),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(t,o),n.state!==e&&Zi.enqueueReplaceState(n,n.state,null)}function Er(e,n,t,o){var i=e.stateNode;i.props=t,i.state=e.memoizedState,i.refs={},us(e);var a=n.contextType;typeof a=="object"&&a!==null?i.context=He(a):(a=Ie(n)?Xn:he.current,i.context=Tt(e,a)),i.state=e.memoizedState,a=n.getDerivedStateFromProps,typeof a=="function"&&(Ir(e,n,a,t),i.state=e.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(n=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),n!==i.state&&Zi.enqueueReplaceState(i,i.state,null),Mi(e,t,i,o),i.state=e.memoizedState),typeof i.componentDidMount=="function"&&(e.flags|=4194308)}function Pt(e,n){try{var t="",o=n;do t+=fu(o),o=o.return;while(o);var i=t}catch(a){i=`
Error generating stack: `+a.message+`
`+a.stack}return{value:e,source:n,stack:i,digest:null}}function Qa(e,n,t){return{value:e,source:null,stack:t??null,digest:n??null}}function zr(e,n){try{console.error(n.value)}catch(t){setTimeout(function(){throw t})}}var Bh=typeof WeakMap=="function"?WeakMap:Map;function $c(e,n,t){t=pn(-1,t),t.tag=3,t.payload={element:null};var o=n.value;return t.callback=function(){Bi||(Bi=!0,Fr=o),zr(e,n)},t}function Qc(e,n,t){t=pn(-1,t),t.tag=3;var o=e.type.getDerivedStateFromError;if(typeof o=="function"){var i=n.value;t.payload=function(){return o(i)},t.callback=function(){zr(e,n)}}var a=e.stateNode;return a!==null&&typeof a.componentDidCatch=="function"&&(t.callback=function(){zr(e,n),typeof o!="function"&&(Nn===null?Nn=new Set([this]):Nn.add(this));var r=n.stack;this.componentDidCatch(n.value,{componentStack:r!==null?r:""})}),t}function id(e,n,t){var o=e.pingCache;if(o===null){o=e.pingCache=new Bh;var i=new Set;o.set(n,i)}else i=o.get(n),i===void 0&&(i=new Set,o.set(n,i));i.has(t)||(i.add(t),e=nm.bind(null,e,n,t),n.then(e,e))}function ad(e){do{var n;if((n=e.tag===13)&&(n=e.memoizedState,n=n!==null?n.dehydrated!==null:!0),n)return e;e=e.return}while(e!==null);return null}function rd(e,n,t,o,i){return(e.mode&1)===0?(e===n?e.flags|=65536:(e.flags|=128,t.flags|=131072,t.flags&=-52805,t.tag===1&&(t.alternate===null?t.tag=17:(n=pn(-1,1),n.tag=2,Ln(t,n,1))),t.lanes|=1),e):(e.flags|=65536,e.lanes=i,e)}var Vh=fn.ReactCurrentOwner,Se=!1;function ye(e,n,t,o){n.child=e===null?vc(n,null,t,o):Nt(n,e.child,t,o)}function sd(e,n,t,o,i){t=t.render;var a=n.ref;return Et(n,i),o=ys(e,n,t,o,a,i),t=_s(),e!==null&&!Se?(n.updateQueue=e.updateQueue,n.flags&=-2053,e.lanes&=~i,gn(e,n,i)):(W&&t&&as(n),n.flags|=1,ye(e,n,o,i),n.child)}function ld(e,n,t,o,i){if(e===null){var a=t.type;return typeof a=="function"&&!Es(a)&&a.defaultProps===void 0&&t.compare===null&&t.defaultProps===void 0?(n.tag=15,n.type=a,Kc(e,n,a,o,i)):(e=xi(t.type,null,o,n,n.mode,i),e.ref=n.ref,e.return=n,n.child=e)}if(a=e.child,(e.lanes&i)===0){var r=a.memoizedProps;if(t=t.compare,t=t!==null?t:ko,t(r,o)&&e.ref===n.ref)return gn(e,n,i)}return n.flags|=1,e=Pn(a,o),e.ref=n.ref,e.return=n,n.child=e}function Kc(e,n,t,o,i){if(e!==null){var a=e.memoizedProps;if(ko(a,o)&&e.ref===n.ref)if(Se=!1,n.pendingProps=o=a,(e.lanes&i)!==0)(e.flags&131072)!==0&&(Se=!0);else return n.lanes=e.lanes,gn(e,n,i)}return Or(e,n,t,o,i)}function Yc(e,n,t){var o=n.pendingProps,i=o.children,a=e!==null?e.memoizedState:null;if(o.mode==="hidden")if((n.mode&1)===0)n.memoizedState={baseLanes:0,cachePool:null,transitions:null},D(kt,ze),ze|=t;else{if((t&1073741824)===0)return e=a!==null?a.baseLanes|t:t,n.lanes=n.childLanes=1073741824,n.memoizedState={baseLanes:e,cachePool:null,transitions:null},n.updateQueue=null,D(kt,ze),ze|=e,null;n.memoizedState={baseLanes:0,cachePool:null,transitions:null},o=a!==null?a.baseLanes:t,D(kt,ze),ze|=o}else a!==null?(o=a.baseLanes|t,n.memoizedState=null):o=t,D(kt,ze),ze|=o;return ye(e,n,i,t),n.child}function qc(e,n){var t=n.ref;(e===null&&t!==null||e!==null&&e.ref!==t)&&(n.flags|=512,n.flags|=2097152)}function Or(e,n,t,o,i){var a=Ie(t)?Xn:he.current;return a=Tt(n,a),Et(n,i),t=ys(e,n,t,o,a,i),o=_s(),e!==null&&!Se?(n.updateQueue=e.updateQueue,n.flags&=-2053,e.lanes&=~i,gn(e,n,i)):(W&&o&&as(n),n.flags|=1,ye(e,n,t,i),n.child)}function dd(e,n,t,o,i){if(Ie(t)){var a=!0;Ti(n)}else a=!1;if(Et(n,i),n.stateNode===null)yi(e,n),Gc(n,t,o),Er(n,t,o,i),o=!0;else if(e===null){var r=n.stateNode,s=n.memoizedProps;r.props=s;var l=r.context,c=t.contextType;typeof c=="object"&&c!==null?c=He(c):(c=Ie(t)?Xn:he.current,c=Tt(n,c));var f=t.getDerivedStateFromProps,h=typeof f=="function"||typeof r.getSnapshotBeforeUpdate=="function";h||typeof r.UNSAFE_componentWillReceiveProps!="function"&&typeof r.componentWillReceiveProps!="function"||(s!==o||l!==c)&&od(n,r,o,c),kn=!1;var g=n.memoizedState;r.state=g,Mi(n,o,r,i),l=n.memoizedState,s!==o||g!==l||Re.current||kn?(typeof f=="function"&&(Ir(n,t,f,o),l=n.memoizedState),(s=kn||td(n,t,s,o,g,l,c))?(h||typeof r.UNSAFE_componentWillMount!="function"&&typeof r.componentWillMount!="function"||(typeof r.componentWillMount=="function"&&r.componentWillMount(),typeof r.UNSAFE_componentWillMount=="function"&&r.UNSAFE_componentWillMount()),typeof r.componentDidMount=="function"&&(n.flags|=4194308)):(typeof r.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=o,n.memoizedState=l),r.props=o,r.state=l,r.context=c,o=s):(typeof r.componentDidMount=="function"&&(n.flags|=4194308),o=!1)}else{r=n.stateNode,Cc(e,n),s=n.memoizedProps,c=n.type===n.elementType?s:Ge(n.type,s),r.props=c,h=n.pendingProps,g=r.context,l=t.contextType,typeof l=="object"&&l!==null?l=He(l):(l=Ie(t)?Xn:he.current,l=Tt(n,l));var x=t.getDerivedStateFromProps;(f=typeof x=="function"||typeof r.getSnapshotBeforeUpdate=="function")||typeof r.UNSAFE_componentWillReceiveProps!="function"&&typeof r.componentWillReceiveProps!="function"||(s!==h||g!==l)&&od(n,r,o,l),kn=!1,g=n.memoizedState,r.state=g,Mi(n,o,r,i);var w=n.memoizedState;s!==h||g!==w||Re.current||kn?(typeof x=="function"&&(Ir(n,t,x,o),w=n.memoizedState),(c=kn||td(n,t,c,o,g,w,l)||!1)?(f||typeof r.UNSAFE_componentWillUpdate!="function"&&typeof r.componentWillUpdate!="function"||(typeof r.componentWillUpdate=="function"&&r.componentWillUpdate(o,w,l),typeof r.UNSAFE_componentWillUpdate=="function"&&r.UNSAFE_componentWillUpdate(o,w,l)),typeof r.componentDidUpdate=="function"&&(n.flags|=4),typeof r.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof r.componentDidUpdate!="function"||s===e.memoizedProps&&g===e.memoizedState||(n.flags|=4),typeof r.getSnapshotBeforeUpdate!="function"||s===e.memoizedProps&&g===e.memoizedState||(n.flags|=1024),n.memoizedProps=o,n.memoizedState=w),r.props=o,r.state=w,r.context=l,o=c):(typeof r.componentDidUpdate!="function"||s===e.memoizedProps&&g===e.memoizedState||(n.flags|=4),typeof r.getSnapshotBeforeUpdate!="function"||s===e.memoizedProps&&g===e.memoizedState||(n.flags|=1024),o=!1)}return Tr(e,n,t,o,a,i)}function Tr(e,n,t,o,i,a){qc(e,n);var r=(n.flags&128)!==0;if(!o&&!r)return i&&Kl(n,t,!1),gn(e,n,a);o=n.stateNode,Vh.current=n;var s=r&&typeof t.getDerivedStateFromError!="function"?null:o.render();return n.flags|=1,e!==null&&r?(n.child=Nt(n,e.child,null,a),n.child=Nt(n,null,s,a)):ye(e,n,s,a),n.memoizedState=o.state,i&&Kl(n,t,!0),n.child}function Xc(e){var n=e.stateNode;n.pendingContext?Ql(e,n.pendingContext,n.pendingContext!==n.context):n.context&&Ql(e,n.context,!1),hs(e,n.containerInfo)}function cd(e,n,t,o,i){return Lt(),ss(i),n.flags|=256,ye(e,n,t,o),n.child}var Lr={dehydrated:null,treeContext:null,retryLane:0};function Nr(e){return{baseLanes:e,cachePool:null,transitions:null}}function Zc(e,n,t){var o=n.pendingProps,i=$.current,a=!1,r=(n.flags&128)!==0,s;if((s=r)||(s=e!==null&&e.memoizedState===null?!1:(i&2)!==0),s?(a=!0,n.flags&=-129):(e===null||e.memoizedState!==null)&&(i|=1),D($,i&1),e===null)return Sr(n),e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?((n.mode&1)===0?n.lanes=1:e.data==="$!"?n.lanes=8:n.lanes=1073741824,null):(r=o.children,e=o.fallback,a?(o=n.mode,a=n.child,r={mode:"hidden",children:r},(o&1)===0&&a!==null?(a.childLanes=0,a.pendingProps=r):a=na(r,o,0,null),e=qn(e,o,t,null),a.return=n,e.return=n,a.sibling=e,n.child=a,n.child.memoizedState=Nr(t),n.memoizedState=Lr,e):ws(n,r));if(i=e.memoizedState,i!==null&&(s=i.dehydrated,s!==null))return Uh(e,n,r,o,s,i,t);if(a){a=o.fallback,r=n.mode,i=e.child,s=i.sibling;var l={mode:"hidden",children:o.children};return(r&1)===0&&n.child!==i?(o=n.child,o.childLanes=0,o.pendingProps=l,n.deletions=null):(o=Pn(i,l),o.subtreeFlags=i.subtreeFlags&14680064),s!==null?a=Pn(s,a):(a=qn(a,r,t,null),a.flags|=2),a.return=n,o.return=n,o.sibling=a,n.child=o,o=a,a=n.child,r=e.child.memoizedState,r=r===null?Nr(t):{baseLanes:r.baseLanes|t,cachePool:null,transitions:r.transitions},a.memoizedState=r,a.childLanes=e.childLanes&~t,n.memoizedState=Lr,o}return a=e.child,e=a.sibling,o=Pn(a,{mode:"visible",children:o.children}),(n.mode&1)===0&&(o.lanes=t),o.return=n,o.sibling=null,e!==null&&(t=n.deletions,t===null?(n.deletions=[e],n.flags|=16):t.push(e)),n.child=o,n.memoizedState=null,o}function ws(e,n){return n=na({mode:"visible",children:n},e.mode,0,null),n.return=e,e.child=n}function li(e,n,t,o){return o!==null&&ss(o),Nt(n,e.child,null,t),e=ws(n,n.pendingProps.children),e.flags|=2,n.memoizedState=null,e}function Uh(e,n,t,o,i,a,r){if(t)return n.flags&256?(n.flags&=-257,o=Qa(Error(_(422))),li(e,n,r,o)):n.memoizedState!==null?(n.child=e.child,n.flags|=128,null):(a=o.fallback,i=n.mode,o=na({mode:"visible",children:o.children},i,0,null),a=qn(a,i,r,null),a.flags|=2,o.return=n,a.return=n,o.sibling=a,n.child=o,(n.mode&1)!==0&&Nt(n,e.child,null,r),n.child.memoizedState=Nr(r),n.memoizedState=Lr,a);if((n.mode&1)===0)return li(e,n,r,null);if(i.data==="$!"){if(o=i.nextSibling&&i.nextSibling.dataset,o)var s=o.dgst;return o=s,a=Error(_(419)),o=Qa(a,o,void 0),li(e,n,r,o)}if(s=(r&e.childLanes)!==0,Se||s){if(o=ae,o!==null){switch(r&-r){case 4:i=2;break;case 16:i=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:i=32;break;case 536870912:i=268435456;break;default:i=0}i=(i&(o.suspendedLanes|r))!==0?0:i,i!==0&&i!==a.retryLane&&(a.retryLane=i,mn(e,i),Ye(o,e,i,-1))}return Is(),o=Qa(Error(_(421))),li(e,n,r,o)}return i.data==="$?"?(n.flags|=128,n.child=e.child,n=tm.bind(null,e),i._reactRetry=n,null):(e=a.treeContext,Oe=Tn(i.nextSibling),Te=n,W=!0,Qe=null,e!==null&&(Me[je++]=dn,Me[je++]=cn,Me[je++]=Zn,dn=e.id,cn=e.overflow,Zn=n),n=ws(n,o.children),n.flags|=4096,n)}function pd(e,n,t){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n),Rr(e.return,n,t)}function Ka(e,n,t,o,i){var a=e.memoizedState;a===null?e.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:o,tail:t,tailMode:i}:(a.isBackwards=n,a.rendering=null,a.renderingStartTime=0,a.last=o,a.tail=t,a.tailMode=i)}function Jc(e,n,t){var o=n.pendingProps,i=o.revealOrder,a=o.tail;if(ye(e,n,o.children,t),o=$.current,(o&2)!==0)o=o&1|2,n.flags|=128;else{if(e!==null&&(e.flags&128)!==0)e:for(e=n.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&pd(e,t,n);else if(e.tag===19)pd(e,t,n);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===n)break e;for(;e.sibling===null;){if(e.return===null||e.return===n)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}o&=1}if(D($,o),(n.mode&1)===0)n.memoizedState=null;else switch(i){case"forwards":for(t=n.child,i=null;t!==null;)e=t.alternate,e!==null&&ji(e)===null&&(i=t),t=t.sibling;t=i,t===null?(i=n.child,n.child=null):(i=t.sibling,t.sibling=null),Ka(n,!1,i,t,a);break;case"backwards":for(t=null,i=n.child,n.child=null;i!==null;){if(e=i.alternate,e!==null&&ji(e)===null){n.child=i;break}e=i.sibling,i.sibling=t,t=i,i=e}Ka(n,!0,t,null,a);break;case"together":Ka(n,!1,null,null,void 0);break;default:n.memoizedState=null}return n.child}function yi(e,n){(n.mode&1)===0&&e!==null&&(e.alternate=null,n.alternate=null,n.flags|=2)}function gn(e,n,t){if(e!==null&&(n.dependencies=e.dependencies),et|=n.lanes,(t&n.childLanes)===0)return null;if(e!==null&&n.child!==e.child)throw Error(_(153));if(n.child!==null){for(e=n.child,t=Pn(e,e.pendingProps),n.child=t,t.return=n;e.sibling!==null;)e=e.sibling,t=t.sibling=Pn(e,e.pendingProps),t.return=n;t.sibling=null}return n.child}function Wh(e,n,t){switch(n.tag){case 3:Xc(n),Lt();break;case 5:Sc(n);break;case 1:Ie(n.type)&&Ti(n);break;case 4:hs(n,n.stateNode.containerInfo);break;case 10:var o=n.type._context,i=n.memoizedProps.value;D(Ai,o._currentValue),o._currentValue=i;break;case 13:if(o=n.memoizedState,o!==null)return o.dehydrated!==null?(D($,$.current&1),n.flags|=128,null):(t&n.child.childLanes)!==0?Zc(e,n,t):(D($,$.current&1),e=gn(e,n,t),e!==null?e.sibling:null);D($,$.current&1);break;case 19:if(o=(t&n.childLanes)!==0,(e.flags&128)!==0){if(o)return Jc(e,n,t);n.flags|=128}if(i=n.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),D($,$.current),o)break;return null;case 22:case 23:return n.lanes=0,Yc(e,n,t)}return gn(e,n,t)}var ep,Ar,np,tp;ep=function(e,n){for(var t=n.child;t!==null;){if(t.tag===5||t.tag===6)e.appendChild(t.stateNode);else if(t.tag!==4&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===n)break;for(;t.sibling===null;){if(t.return===null||t.return===n)return;t=t.return}t.sibling.return=t.return,t=t.sibling}};Ar=function(){};np=function(e,n,t,o){var i=e.memoizedProps;if(i!==o){e=n.stateNode,Kn(rn.current);var a=null;switch(t){case"input":i=tr(e,i),o=tr(e,o),a=[];break;case"select":i=K({},i,{value:void 0}),o=K({},o,{value:void 0}),a=[];break;case"textarea":i=ar(e,i),o=ar(e,o),a=[];break;default:typeof i.onClick!="function"&&typeof o.onClick=="function"&&(e.onclick=zi)}sr(t,o);var r;t=null;for(c in i)if(!o.hasOwnProperty(c)&&i.hasOwnProperty(c)&&i[c]!=null)if(c==="style"){var s=i[c];for(r in s)s.hasOwnProperty(r)&&(t||(t={}),t[r]="")}else c!=="dangerouslySetInnerHTML"&&c!=="children"&&c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&c!=="autoFocus"&&(fo.hasOwnProperty(c)?a||(a=[]):(a=a||[]).push(c,null));for(c in o){var l=o[c];if(s=i?.[c],o.hasOwnProperty(c)&&l!==s&&(l!=null||s!=null))if(c==="style")if(s){for(r in s)!s.hasOwnProperty(r)||l&&l.hasOwnProperty(r)||(t||(t={}),t[r]="");for(r in l)l.hasOwnProperty(r)&&s[r]!==l[r]&&(t||(t={}),t[r]=l[r])}else t||(a||(a=[]),a.push(c,t)),t=l;else c==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,s=s?s.__html:void 0,l!=null&&s!==l&&(a=a||[]).push(c,l)):c==="children"?typeof l!="string"&&typeof l!="number"||(a=a||[]).push(c,""+l):c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&(fo.hasOwnProperty(c)?(l!=null&&c==="onScroll"&&V("scroll",e),a||s===l||(a=[])):(a=a||[]).push(c,l))}t&&(a=a||[]).push("style",t);var c=a;(n.updateQueue=c)&&(n.flags|=4)}};tp=function(e,n,t,o){t!==o&&(n.flags|=4)};function Jt(e,n){if(!W)switch(e.tailMode){case"hidden":n=e.tail;for(var t=null;n!==null;)n.alternate!==null&&(t=n),n=n.sibling;t===null?e.tail=null:t.sibling=null;break;case"collapsed":t=e.tail;for(var o=null;t!==null;)t.alternate!==null&&(o=t),t=t.sibling;o===null?n||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null}}function pe(e){var n=e.alternate!==null&&e.alternate.child===e.child,t=0,o=0;if(n)for(var i=e.child;i!==null;)t|=i.lanes|i.childLanes,o|=i.subtreeFlags&14680064,o|=i.flags&14680064,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)t|=i.lanes|i.childLanes,o|=i.subtreeFlags,o|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=o,e.childLanes=t,n}function Gh(e,n,t){var o=n.pendingProps;switch(rs(n),n.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return pe(n),null;case 1:return Ie(n.type)&&Oi(),pe(n),null;case 3:return o=n.stateNode,At(),U(Re),U(he),gs(),o.pendingContext&&(o.context=o.pendingContext,o.pendingContext=null),(e===null||e.child===null)&&(ri(n)?n.flags|=4:e===null||e.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Qe!==null&&(Vr(Qe),Qe=null))),Ar(e,n),pe(n),null;case 5:ms(n);var i=Kn(Eo.current);if(t=n.type,e!==null&&n.stateNode!=null)np(e,n,t,o,i),e.ref!==n.ref&&(n.flags|=512,n.flags|=2097152);else{if(!o){if(n.stateNode===null)throw Error(_(166));return pe(n),null}if(e=Kn(rn.current),ri(n)){o=n.stateNode,t=n.type;var a=n.memoizedProps;switch(o[on]=n,o[Ro]=a,e=(n.mode&1)!==0,t){case"dialog":V("cancel",o),V("close",o);break;case"iframe":case"object":case"embed":V("load",o);break;case"video":case"audio":for(i=0;i<ao.length;i++)V(ao[i],o);break;case"source":V("error",o);break;case"img":case"image":case"link":V("error",o),V("load",o);break;case"details":V("toggle",o);break;case"input":bl(o,a),V("invalid",o);break;case"select":o._wrapperState={wasMultiple:!!a.multiple},V("invalid",o);break;case"textarea":wl(o,a),V("invalid",o)}sr(t,a),i=null;for(var r in a)if(a.hasOwnProperty(r)){var s=a[r];r==="children"?typeof s=="string"?o.textContent!==s&&(a.suppressHydrationWarning!==!0&&ai(o.textContent,s,e),i=["children",s]):typeof s=="number"&&o.textContent!==""+s&&(a.suppressHydrationWarning!==!0&&ai(o.textContent,s,e),i=["children",""+s]):fo.hasOwnProperty(r)&&s!=null&&r==="onScroll"&&V("scroll",o)}switch(t){case"input":Qo(o),xl(o,a,!0);break;case"textarea":Qo(o),vl(o);break;case"select":case"option":break;default:typeof a.onClick=="function"&&(o.onclick=zi)}o=i,n.updateQueue=o,o!==null&&(n.flags|=4)}else{r=i.nodeType===9?i:i.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=Od(t)),e==="http://www.w3.org/1999/xhtml"?t==="script"?(e=r.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof o.is=="string"?e=r.createElement(t,{is:o.is}):(e=r.createElement(t),t==="select"&&(r=e,o.multiple?r.multiple=!0:o.size&&(r.size=o.size))):e=r.createElementNS(e,t),e[on]=n,e[Ro]=o,ep(e,n,!1,!1),n.stateNode=e;e:{switch(r=lr(t,o),t){case"dialog":V("cancel",e),V("close",e),i=o;break;case"iframe":case"object":case"embed":V("load",e),i=o;break;case"video":case"audio":for(i=0;i<ao.length;i++)V(ao[i],e);i=o;break;case"source":V("error",e),i=o;break;case"img":case"image":case"link":V("error",e),V("load",e),i=o;break;case"details":V("toggle",e),i=o;break;case"input":bl(e,o),i=tr(e,o),V("invalid",e);break;case"option":i=o;break;case"select":e._wrapperState={wasMultiple:!!o.multiple},i=K({},o,{value:void 0}),V("invalid",e);break;case"textarea":wl(e,o),i=ar(e,o),V("invalid",e);break;default:i=o}sr(t,i),s=i;for(a in s)if(s.hasOwnProperty(a)){var l=s[a];a==="style"?Nd(e,l):a==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,l!=null&&Td(e,l)):a==="children"?typeof l=="string"?(t!=="textarea"||l!=="")&&yo(e,l):typeof l=="number"&&yo(e,""+l):a!=="suppressContentEditableWarning"&&a!=="suppressHydrationWarning"&&a!=="autoFocus"&&(fo.hasOwnProperty(a)?l!=null&&a==="onScroll"&&V("scroll",e):l!=null&&Gr(e,a,l,r))}switch(t){case"input":Qo(e),xl(e,o,!1);break;case"textarea":Qo(e),vl(e);break;case"option":o.value!=null&&e.setAttribute("value",""+Mn(o.value));break;case"select":e.multiple=!!o.multiple,a=o.value,a!=null?Ct(e,!!o.multiple,a,!1):o.defaultValue!=null&&Ct(e,!!o.multiple,o.defaultValue,!0);break;default:typeof i.onClick=="function"&&(e.onclick=zi)}switch(t){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}}o&&(n.flags|=4)}n.ref!==null&&(n.flags|=512,n.flags|=2097152)}return pe(n),null;case 6:if(e&&n.stateNode!=null)tp(e,n,e.memoizedProps,o);else{if(typeof o!="string"&&n.stateNode===null)throw Error(_(166));if(t=Kn(Eo.current),Kn(rn.current),ri(n)){if(o=n.stateNode,t=n.memoizedProps,o[on]=n,(a=o.nodeValue!==t)&&(e=Te,e!==null))switch(e.tag){case 3:ai(o.nodeValue,t,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&ai(o.nodeValue,t,(e.mode&1)!==0)}a&&(n.flags|=4)}else o=(t.nodeType===9?t:t.ownerDocument).createTextNode(o),o[on]=n,n.stateNode=o}return pe(n),null;case 13:if(U($),o=n.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(W&&Oe!==null&&(n.mode&1)!==0&&(n.flags&128)===0)xc(),Lt(),n.flags|=98560,a=!1;else if(a=ri(n),o!==null&&o.dehydrated!==null){if(e===null){if(!a)throw Error(_(318));if(a=n.memoizedState,a=a!==null?a.dehydrated:null,!a)throw Error(_(317));a[on]=n}else Lt(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;pe(n),a=!1}else Qe!==null&&(Vr(Qe),Qe=null),a=!0;if(!a)return n.flags&65536?n:null}return(n.flags&128)!==0?(n.lanes=t,n):(o=o!==null,o!==(e!==null&&e.memoizedState!==null)&&o&&(n.child.flags|=8192,(n.mode&1)!==0&&(e===null||($.current&1)!==0?ne===0&&(ne=3):Is())),n.updateQueue!==null&&(n.flags|=4),pe(n),null);case 4:return At(),Ar(e,n),e===null&&Co(n.stateNode.containerInfo),pe(n),null;case 10:return cs(n.type._context),pe(n),null;case 17:return Ie(n.type)&&Oi(),pe(n),null;case 19:if(U($),a=n.memoizedState,a===null)return pe(n),null;if(o=(n.flags&128)!==0,r=a.rendering,r===null)if(o)Jt(a,!1);else{if(ne!==0||e!==null&&(e.flags&128)!==0)for(e=n.child;e!==null;){if(r=ji(e),r!==null){for(n.flags|=128,Jt(a,!1),o=r.updateQueue,o!==null&&(n.updateQueue=o,n.flags|=4),n.subtreeFlags=0,o=t,t=n.child;t!==null;)a=t,e=o,a.flags&=14680066,r=a.alternate,r===null?(a.childLanes=0,a.lanes=e,a.child=null,a.subtreeFlags=0,a.memoizedProps=null,a.memoizedState=null,a.updateQueue=null,a.dependencies=null,a.stateNode=null):(a.childLanes=r.childLanes,a.lanes=r.lanes,a.child=r.child,a.subtreeFlags=0,a.deletions=null,a.memoizedProps=r.memoizedProps,a.memoizedState=r.memoizedState,a.updateQueue=r.updateQueue,a.type=r.type,e=r.dependencies,a.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),t=t.sibling;return D($,$.current&1|2),n.child}e=e.sibling}a.tail!==null&&q()>Mt&&(n.flags|=128,o=!0,Jt(a,!1),n.lanes=4194304)}else{if(!o)if(e=ji(r),e!==null){if(n.flags|=128,o=!0,t=e.updateQueue,t!==null&&(n.updateQueue=t,n.flags|=4),Jt(a,!0),a.tail===null&&a.tailMode==="hidden"&&!r.alternate&&!W)return pe(n),null}else 2*q()-a.renderingStartTime>Mt&&t!==1073741824&&(n.flags|=128,o=!0,Jt(a,!1),n.lanes=4194304);a.isBackwards?(r.sibling=n.child,n.child=r):(t=a.last,t!==null?t.sibling=r:n.child=r,a.last=r)}return a.tail!==null?(n=a.tail,a.rendering=n,a.tail=n.sibling,a.renderingStartTime=q(),n.sibling=null,t=$.current,D($,o?t&1|2:t&1),n):(pe(n),null);case 22:case 23:return Rs(),o=n.memoizedState!==null,e!==null&&e.memoizedState!==null!==o&&(n.flags|=8192),o&&(n.mode&1)!==0?(ze&1073741824)!==0&&(pe(n),n.subtreeFlags&6&&(n.flags|=8192)):pe(n),null;case 24:return null;case 25:return null}throw Error(_(156,n.tag))}function $h(e,n){switch(rs(n),n.tag){case 1:return Ie(n.type)&&Oi(),e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 3:return At(),U(Re),U(he),gs(),e=n.flags,(e&65536)!==0&&(e&128)===0?(n.flags=e&-65537|128,n):null;case 5:return ms(n),null;case 13:if(U($),e=n.memoizedState,e!==null&&e.dehydrated!==null){if(n.alternate===null)throw Error(_(340));Lt()}return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 19:return U($),null;case 4:return At(),null;case 10:return cs(n.type._context),null;case 22:case 23:return Rs(),null;case 24:return null;default:return null}}var di=!1,ue=!1,Qh=typeof WeakSet=="function"?WeakSet:Set,v=null;function vt(e,n){var t=e.ref;if(t!==null)if(typeof t=="function")try{t(null)}catch(o){Y(e,n,o)}else t.current=null}function Pr(e,n,t){try{t()}catch(o){Y(e,n,o)}}var ud=!1;function Kh(e,n){if(_r=Ri,e=sc(),is(e)){if("selectionStart"in e)var t={start:e.selectionStart,end:e.selectionEnd};else e:{t=(t=e.ownerDocument)&&t.defaultView||window;var o=t.getSelection&&t.getSelection();if(o&&o.rangeCount!==0){t=o.anchorNode;var i=o.anchorOffset,a=o.focusNode;o=o.focusOffset;try{t.nodeType,a.nodeType}catch{t=null;break e}var r=0,s=-1,l=-1,c=0,f=0,h=e,g=null;n:for(;;){for(var x;h!==t||i!==0&&h.nodeType!==3||(s=r+i),h!==a||o!==0&&h.nodeType!==3||(l=r+o),h.nodeType===3&&(r+=h.nodeValue.length),(x=h.firstChild)!==null;)g=h,h=x;for(;;){if(h===e)break n;if(g===t&&++c===i&&(s=r),g===a&&++f===o&&(l=r),(x=h.nextSibling)!==null)break;h=g,g=h.parentNode}h=x}t=s===-1||l===-1?null:{start:s,end:l}}else t=null}t=t||{start:0,end:0}}else t=null;for(br={focusedElem:e,selectionRange:t},Ri=!1,v=n;v!==null;)if(n=v,e=n.child,(n.subtreeFlags&1028)!==0&&e!==null)e.return=n,v=e;else for(;v!==null;){n=v;try{var w=n.alternate;if((n.flags&1024)!==0)switch(n.tag){case 0:case 11:case 15:break;case 1:if(w!==null){var b=w.memoizedProps,M=w.memoizedState,p=n.stateNode,d=p.getSnapshotBeforeUpdate(n.elementType===n.type?b:Ge(n.type,b),M);p.__reactInternalSnapshotBeforeUpdate=d}break;case 3:var u=n.stateNode.containerInfo;u.nodeType===1?u.textContent="":u.nodeType===9&&u.documentElement&&u.removeChild(u.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(_(163))}}catch(y){Y(n,n.return,y)}if(e=n.sibling,e!==null){e.return=n.return,v=e;break}v=n.return}return w=ud,ud=!1,w}function ho(e,n,t){var o=n.updateQueue;if(o=o!==null?o.lastEffect:null,o!==null){var i=o=o.next;do{if((i.tag&e)===e){var a=i.destroy;i.destroy=void 0,a!==void 0&&Pr(n,t,a)}i=i.next}while(i!==o)}}function Ji(e,n){if(n=n.updateQueue,n=n!==null?n.lastEffect:null,n!==null){var t=n=n.next;do{if((t.tag&e)===e){var o=t.create;t.destroy=o()}t=t.next}while(t!==n)}}function Mr(e){var n=e.ref;if(n!==null){var t=e.stateNode;e.tag,e=t,typeof n=="function"?n(e):n.current=e}}function op(e){var n=e.alternate;n!==null&&(e.alternate=null,op(n)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(n=e.stateNode,n!==null&&(delete n[on],delete n[Ro],delete n[vr],delete n[Oh],delete n[Th])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function ip(e){return e.tag===5||e.tag===3||e.tag===4}function hd(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||ip(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function jr(e,n,t){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?t.nodeType===8?t.parentNode.insertBefore(e,n):t.insertBefore(e,n):(t.nodeType===8?(n=t.parentNode,n.insertBefore(e,t)):(n=t,n.appendChild(e)),t=t._reactRootContainer,t!=null||n.onclick!==null||(n.onclick=zi));else if(o!==4&&(e=e.child,e!==null))for(jr(e,n,t),e=e.sibling;e!==null;)jr(e,n,t),e=e.sibling}function Dr(e,n,t){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?t.insertBefore(e,n):t.appendChild(e);else if(o!==4&&(e=e.child,e!==null))for(Dr(e,n,t),e=e.sibling;e!==null;)Dr(e,n,t),e=e.sibling}var re=null,$e=!1;function wn(e,n,t){for(t=t.child;t!==null;)ap(e,n,t),t=t.sibling}function ap(e,n,t){if(an&&typeof an.onCommitFiberUnmount=="function")try{an.onCommitFiberUnmount(Gi,t)}catch{}switch(t.tag){case 5:ue||vt(t,n);case 6:var o=re,i=$e;re=null,wn(e,n,t),re=o,$e=i,re!==null&&($e?(e=re,t=t.stateNode,e.nodeType===8?e.parentNode.removeChild(t):e.removeChild(t)):re.removeChild(t.stateNode));break;case 18:re!==null&&($e?(e=re,t=t.stateNode,e.nodeType===8?Ba(e.parentNode,t):e.nodeType===1&&Ba(e,t),wo(e)):Ba(re,t.stateNode));break;case 4:o=re,i=$e,re=t.stateNode.containerInfo,$e=!0,wn(e,n,t),re=o,$e=i;break;case 0:case 11:case 14:case 15:if(!ue&&(o=t.updateQueue,o!==null&&(o=o.lastEffect,o!==null))){i=o=o.next;do{var a=i,r=a.destroy;a=a.tag,r!==void 0&&((a&2)!==0||(a&4)!==0)&&Pr(t,n,r),i=i.next}while(i!==o)}wn(e,n,t);break;case 1:if(!ue&&(vt(t,n),o=t.stateNode,typeof o.componentWillUnmount=="function"))try{o.props=t.memoizedProps,o.state=t.memoizedState,o.componentWillUnmount()}catch(s){Y(t,n,s)}wn(e,n,t);break;case 21:wn(e,n,t);break;case 22:t.mode&1?(ue=(o=ue)||t.memoizedState!==null,wn(e,n,t),ue=o):wn(e,n,t);break;default:wn(e,n,t)}}function md(e){var n=e.updateQueue;if(n!==null){e.updateQueue=null;var t=e.stateNode;t===null&&(t=e.stateNode=new Qh),n.forEach(function(o){var i=om.bind(null,e,o);t.has(o)||(t.add(o),o.then(i,i))})}}function We(e,n){var t=n.deletions;if(t!==null)for(var o=0;o<t.length;o++){var i=t[o];try{var a=e,r=n,s=r;e:for(;s!==null;){switch(s.tag){case 5:re=s.stateNode,$e=!1;break e;case 3:re=s.stateNode.containerInfo,$e=!0;break e;case 4:re=s.stateNode.containerInfo,$e=!0;break e}s=s.return}if(re===null)throw Error(_(160));ap(a,r,i),re=null,$e=!1;var l=i.alternate;l!==null&&(l.return=null),i.return=null}catch(c){Y(i,n,c)}}if(n.subtreeFlags&12854)for(n=n.child;n!==null;)rp(n,e),n=n.sibling}function rp(e,n){var t=e.alternate,o=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(We(n,e),nn(e),o&4){try{ho(3,e,e.return),Ji(3,e)}catch(b){Y(e,e.return,b)}try{ho(5,e,e.return)}catch(b){Y(e,e.return,b)}}break;case 1:We(n,e),nn(e),o&512&&t!==null&&vt(t,t.return);break;case 5:if(We(n,e),nn(e),o&512&&t!==null&&vt(t,t.return),e.flags&32){var i=e.stateNode;try{yo(i,"")}catch(b){Y(e,e.return,b)}}if(o&4&&(i=e.stateNode,i!=null)){var a=e.memoizedProps,r=t!==null?t.memoizedProps:a,s=e.type,l=e.updateQueue;if(e.updateQueue=null,l!==null)try{s==="input"&&a.type==="radio"&&a.name!=null&&Ed(i,a),lr(s,r);var c=lr(s,a);for(r=0;r<l.length;r+=2){var f=l[r],h=l[r+1];f==="style"?Nd(i,h):f==="dangerouslySetInnerHTML"?Td(i,h):f==="children"?yo(i,h):Gr(i,f,h,c)}switch(s){case"input":or(i,a);break;case"textarea":zd(i,a);break;case"select":var g=i._wrapperState.wasMultiple;i._wrapperState.wasMultiple=!!a.multiple;var x=a.value;x!=null?Ct(i,!!a.multiple,x,!1):g!==!!a.multiple&&(a.defaultValue!=null?Ct(i,!!a.multiple,a.defaultValue,!0):Ct(i,!!a.multiple,a.multiple?[]:"",!1))}i[Ro]=a}catch(b){Y(e,e.return,b)}}break;case 6:if(We(n,e),nn(e),o&4){if(e.stateNode===null)throw Error(_(162));i=e.stateNode,a=e.memoizedProps;try{i.nodeValue=a}catch(b){Y(e,e.return,b)}}break;case 3:if(We(n,e),nn(e),o&4&&t!==null&&t.memoizedState.isDehydrated)try{wo(n.containerInfo)}catch(b){Y(e,e.return,b)}break;case 4:We(n,e),nn(e);break;case 13:We(n,e),nn(e),i=e.child,i.flags&8192&&(a=i.memoizedState!==null,i.stateNode.isHidden=a,!a||i.alternate!==null&&i.alternate.memoizedState!==null||(Cs=q())),o&4&&md(e);break;case 22:if(f=t!==null&&t.memoizedState!==null,e.mode&1?(ue=(c=ue)||f,We(n,e),ue=c):We(n,e),nn(e),o&8192){if(c=e.memoizedState!==null,(e.stateNode.isHidden=c)&&!f&&(e.mode&1)!==0)for(v=e,f=e.child;f!==null;){for(h=v=f;v!==null;){switch(g=v,x=g.child,g.tag){case 0:case 11:case 14:case 15:ho(4,g,g.return);break;case 1:vt(g,g.return);var w=g.stateNode;if(typeof w.componentWillUnmount=="function"){o=g,t=g.return;try{n=o,w.props=n.memoizedProps,w.state=n.memoizedState,w.componentWillUnmount()}catch(b){Y(o,t,b)}}break;case 5:vt(g,g.return);break;case 22:if(g.memoizedState!==null){fd(h);continue}}x!==null?(x.return=g,v=x):fd(h)}f=f.sibling}e:for(f=null,h=e;;){if(h.tag===5){if(f===null){f=h;try{i=h.stateNode,c?(a=i.style,typeof a.setProperty=="function"?a.setProperty("display","none","important"):a.display="none"):(s=h.stateNode,l=h.memoizedProps.style,r=l!=null&&l.hasOwnProperty("display")?l.display:null,s.style.display=Ld("display",r))}catch(b){Y(e,e.return,b)}}}else if(h.tag===6){if(f===null)try{h.stateNode.nodeValue=c?"":h.memoizedProps}catch(b){Y(e,e.return,b)}}else if((h.tag!==22&&h.tag!==23||h.memoizedState===null||h===e)&&h.child!==null){h.child.return=h,h=h.child;continue}if(h===e)break e;for(;h.sibling===null;){if(h.return===null||h.return===e)break e;f===h&&(f=null),h=h.return}f===h&&(f=null),h.sibling.return=h.return,h=h.sibling}}break;case 19:We(n,e),nn(e),o&4&&md(e);break;case 21:break;default:We(n,e),nn(e)}}function nn(e){var n=e.flags;if(n&2){try{e:{for(var t=e.return;t!==null;){if(ip(t)){var o=t;break e}t=t.return}throw Error(_(160))}switch(o.tag){case 5:var i=o.stateNode;o.flags&32&&(yo(i,""),o.flags&=-33);var a=hd(e);Dr(e,a,i);break;case 3:case 4:var r=o.stateNode.containerInfo,s=hd(e);jr(e,s,r);break;default:throw Error(_(161))}}catch(l){Y(e,e.return,l)}e.flags&=-3}n&4096&&(e.flags&=-4097)}function Yh(e,n,t){v=e,sp(e,n,t)}function sp(e,n,t){for(var o=(e.mode&1)!==0;v!==null;){var i=v,a=i.child;if(i.tag===22&&o){var r=i.memoizedState!==null||di;if(!r){var s=i.alternate,l=s!==null&&s.memoizedState!==null||ue;s=di;var c=ue;if(di=r,(ue=l)&&!c)for(v=i;v!==null;)r=v,l=r.child,r.tag===22&&r.memoizedState!==null?yd(i):l!==null?(l.return=r,v=l):yd(i);for(;a!==null;)v=a,sp(a,n,t),a=a.sibling;v=i,di=s,ue=c}gd(e,n,t)}else(i.subtreeFlags&8772)!==0&&a!==null?(a.return=i,v=a):gd(e,n,t)}}function gd(e){for(;v!==null;){var n=v;if((n.flags&8772)!==0){var t=n.alternate;try{if((n.flags&8772)!==0)switch(n.tag){case 0:case 11:case 15:ue||Ji(5,n);break;case 1:var o=n.stateNode;if(n.flags&4&&!ue)if(t===null)o.componentDidMount();else{var i=n.elementType===n.type?t.memoizedProps:Ge(n.type,t.memoizedProps);o.componentDidUpdate(i,t.memoizedState,o.__reactInternalSnapshotBeforeUpdate)}var a=n.updateQueue;a!==null&&Jl(n,a,o);break;case 3:var r=n.updateQueue;if(r!==null){if(t=null,n.child!==null)switch(n.child.tag){case 5:t=n.child.stateNode;break;case 1:t=n.child.stateNode}Jl(n,r,t)}break;case 5:var s=n.stateNode;if(t===null&&n.flags&4){t=s;var l=n.memoizedProps;switch(n.type){case"button":case"input":case"select":case"textarea":l.autoFocus&&t.focus();break;case"img":l.src&&(t.src=l.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(n.memoizedState===null){var c=n.alternate;if(c!==null){var f=c.memoizedState;if(f!==null){var h=f.dehydrated;h!==null&&wo(h)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(_(163))}ue||n.flags&512&&Mr(n)}catch(g){Y(n,n.return,g)}}if(n===e){v=null;break}if(t=n.sibling,t!==null){t.return=n.return,v=t;break}v=n.return}}function fd(e){for(;v!==null;){var n=v;if(n===e){v=null;break}var t=n.sibling;if(t!==null){t.return=n.return,v=t;break}v=n.return}}function yd(e){for(;v!==null;){var n=v;try{switch(n.tag){case 0:case 11:case 15:var t=n.return;try{Ji(4,n)}catch(l){Y(n,t,l)}break;case 1:var o=n.stateNode;if(typeof o.componentDidMount=="function"){var i=n.return;try{o.componentDidMount()}catch(l){Y(n,i,l)}}var a=n.return;try{Mr(n)}catch(l){Y(n,a,l)}break;case 5:var r=n.return;try{Mr(n)}catch(l){Y(n,r,l)}}}catch(l){Y(n,n.return,l)}if(n===e){v=null;break}var s=n.sibling;if(s!==null){s.return=n.return,v=s;break}v=n.return}}var qh=Math.ceil,Hi=fn.ReactCurrentDispatcher,vs=fn.ReactCurrentOwner,Fe=fn.ReactCurrentBatchConfig,A=0,ae=null,Z=null,se=0,ze=0,kt=Fn(0),ne=0,Lo=null,et=0,ea=0,ks=0,mo=null,Ce=null,Cs=0,Mt=1/0,sn=null,Bi=!1,Fr=null,Nn=null,ci=!1,In=null,Vi=0,go=0,Hr=null,_i=-1,bi=0;function _e(){return(A&6)!==0?q():_i!==-1?_i:_i=q()}function An(e){return(e.mode&1)===0?1:(A&2)!==0&&se!==0?se&-se:Nh.transition!==null?(bi===0&&(bi=Gd()),bi):(e=P,e!==0||(e=window.event,e=e===void 0?16:Zd(e.type)),e)}function Ye(e,n,t,o){if(50<go)throw go=0,Hr=null,Error(_(185));No(e,t,o),((A&2)===0||e!==ae)&&(e===ae&&((A&2)===0&&(ea|=t),ne===4&&Sn(e,se)),Ee(e,o),t===1&&A===0&&(n.mode&1)===0&&(Mt=q()+500,qi&&Hn()))}function Ee(e,n){var t=e.callbackNode;Pu(e,n);var o=Si(e,e===ae?se:0);if(o===0)t!==null&&Sl(t),e.callbackNode=null,e.callbackPriority=0;else if(n=o&-o,e.callbackPriority!==n){if(t!=null&&Sl(t),n===1)e.tag===0?Lh(_d.bind(null,e)):yc(_d.bind(null,e)),Eh(function(){(A&6)===0&&Hn()}),t=null;else{switch($d(o)){case 1:t=qr;break;case 4:t=Ud;break;case 16:t=Ci;break;case 536870912:t=Wd;break;default:t=Ci}t=gp(t,lp.bind(null,e))}e.callbackPriority=n,e.callbackNode=t}}function lp(e,n){if(_i=-1,bi=0,(A&6)!==0)throw Error(_(327));var t=e.callbackNode;if(zt()&&e.callbackNode!==t)return null;var o=Si(e,e===ae?se:0);if(o===0)return null;if((o&30)!==0||(o&e.expiredLanes)!==0||n)n=Ui(e,o);else{n=o;var i=A;A|=2;var a=cp();(ae!==e||se!==n)&&(sn=null,Mt=q()+500,Yn(e,n));do try{Jh();break}catch(s){dp(e,s)}while(!0);ds(),Hi.current=a,A=i,Z!==null?n=0:(ae=null,se=0,n=ne)}if(n!==0){if(n===2&&(i=hr(e),i!==0&&(o=i,n=Br(e,i))),n===1)throw t=Lo,Yn(e,0),Sn(e,o),Ee(e,q()),t;if(n===6)Sn(e,o);else{if(i=e.current.alternate,(o&30)===0&&!Xh(i)&&(n=Ui(e,o),n===2&&(a=hr(e),a!==0&&(o=a,n=Br(e,a))),n===1))throw t=Lo,Yn(e,0),Sn(e,o),Ee(e,q()),t;switch(e.finishedWork=i,e.finishedLanes=o,n){case 0:case 1:throw Error(_(345));case 2:Gn(e,Ce,sn);break;case 3:if(Sn(e,o),(o&130023424)===o&&(n=Cs+500-q(),10<n)){if(Si(e,0)!==0)break;if(i=e.suspendedLanes,(i&o)!==o){_e(),e.pingedLanes|=e.suspendedLanes&i;break}e.timeoutHandle=wr(Gn.bind(null,e,Ce,sn),n);break}Gn(e,Ce,sn);break;case 4:if(Sn(e,o),(o&4194240)===o)break;for(n=e.eventTimes,i=-1;0<o;){var r=31-Ke(o);a=1<<r,r=n[r],r>i&&(i=r),o&=~a}if(o=i,o=q()-o,o=(120>o?120:480>o?480:1080>o?1080:1920>o?1920:3e3>o?3e3:4320>o?4320:1960*qh(o/1960))-o,10<o){e.timeoutHandle=wr(Gn.bind(null,e,Ce,sn),o);break}Gn(e,Ce,sn);break;case 5:Gn(e,Ce,sn);break;default:throw Error(_(329))}}}return Ee(e,q()),e.callbackNode===t?lp.bind(null,e):null}function Br(e,n){var t=mo;return e.current.memoizedState.isDehydrated&&(Yn(e,n).flags|=256),e=Ui(e,n),e!==2&&(n=Ce,Ce=t,n!==null&&Vr(n)),e}function Vr(e){Ce===null?Ce=e:Ce.push.apply(Ce,e)}function Xh(e){for(var n=e;;){if(n.flags&16384){var t=n.updateQueue;if(t!==null&&(t=t.stores,t!==null))for(var o=0;o<t.length;o++){var i=t[o],a=i.getSnapshot;i=i.value;try{if(!qe(a(),i))return!1}catch{return!1}}}if(t=n.child,n.subtreeFlags&16384&&t!==null)t.return=n,n=t;else{if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function Sn(e,n){for(n&=~ks,n&=~ea,e.suspendedLanes|=n,e.pingedLanes&=~n,e=e.expirationTimes;0<n;){var t=31-Ke(n),o=1<<t;e[t]=-1,n&=~o}}function _d(e){if((A&6)!==0)throw Error(_(327));zt();var n=Si(e,0);if((n&1)===0)return Ee(e,q()),null;var t=Ui(e,n);if(e.tag!==0&&t===2){var o=hr(e);o!==0&&(n=o,t=Br(e,o))}if(t===1)throw t=Lo,Yn(e,0),Sn(e,n),Ee(e,q()),t;if(t===6)throw Error(_(345));return e.finishedWork=e.current.alternate,e.finishedLanes=n,Gn(e,Ce,sn),Ee(e,q()),null}function Ss(e,n){var t=A;A|=1;try{return e(n)}finally{A=t,A===0&&(Mt=q()+500,qi&&Hn())}}function nt(e){In!==null&&In.tag===0&&(A&6)===0&&zt();var n=A;A|=1;var t=Fe.transition,o=P;try{if(Fe.transition=null,P=1,e)return e()}finally{P=o,Fe.transition=t,A=n,(A&6)===0&&Hn()}}function Rs(){ze=kt.current,U(kt)}function Yn(e,n){e.finishedWork=null,e.finishedLanes=0;var t=e.timeoutHandle;if(t!==-1&&(e.timeoutHandle=-1,Ih(t)),Z!==null)for(t=Z.return;t!==null;){var o=t;switch(rs(o),o.tag){case 1:o=o.type.childContextTypes,o!=null&&Oi();break;case 3:At(),U(Re),U(he),gs();break;case 5:ms(o);break;case 4:At();break;case 13:U($);break;case 19:U($);break;case 10:cs(o.type._context);break;case 22:case 23:Rs()}t=t.return}if(ae=e,Z=e=Pn(e.current,null),se=ze=n,ne=0,Lo=null,ks=ea=et=0,Ce=mo=null,Qn!==null){for(n=0;n<Qn.length;n++)if(t=Qn[n],o=t.interleaved,o!==null){t.interleaved=null;var i=o.next,a=t.pending;if(a!==null){var r=a.next;a.next=i,o.next=r}t.pending=o}Qn=null}return e}function dp(e,n){do{var t=Z;try{if(ds(),gi.current=Fi,Di){for(var o=Q.memoizedState;o!==null;){var i=o.queue;i!==null&&(i.pending=null),o=o.next}Di=!1}if(Jn=0,ie=ee=Q=null,uo=!1,zo=0,vs.current=null,t===null||t.return===null){ne=1,Lo=n,Z=null;break}e:{var a=e,r=t.return,s=t,l=n;if(n=se,s.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){var c=l,f=s,h=f.tag;if((f.mode&1)===0&&(h===0||h===11||h===15)){var g=f.alternate;g?(f.updateQueue=g.updateQueue,f.memoizedState=g.memoizedState,f.lanes=g.lanes):(f.updateQueue=null,f.memoizedState=null)}var x=ad(r);if(x!==null){x.flags&=-257,rd(x,r,s,a,n),x.mode&1&&id(a,c,n),n=x,l=c;var w=n.updateQueue;if(w===null){var b=new Set;b.add(l),n.updateQueue=b}else w.add(l);break e}else{if((n&1)===0){id(a,c,n),Is();break e}l=Error(_(426))}}else if(W&&s.mode&1){var M=ad(r);if(M!==null){(M.flags&65536)===0&&(M.flags|=256),rd(M,r,s,a,n),ss(Pt(l,s));break e}}a=l=Pt(l,s),ne!==4&&(ne=2),mo===null?mo=[a]:mo.push(a),a=r;do{switch(a.tag){case 3:a.flags|=65536,n&=-n,a.lanes|=n;var p=$c(a,l,n);Zl(a,p);break e;case 1:s=l;var d=a.type,u=a.stateNode;if((a.flags&128)===0&&(typeof d.getDerivedStateFromError=="function"||u!==null&&typeof u.componentDidCatch=="function"&&(Nn===null||!Nn.has(u)))){a.flags|=65536,n&=-n,a.lanes|=n;var y=Qc(a,s,n);Zl(a,y);break e}}a=a.return}while(a!==null)}up(t)}catch(k){n=k,Z===t&&t!==null&&(Z=t=t.return);continue}break}while(!0)}function cp(){var e=Hi.current;return Hi.current=Fi,e===null?Fi:e}function Is(){(ne===0||ne===3||ne===2)&&(ne=4),ae===null||(et&268435455)===0&&(ea&268435455)===0||Sn(ae,se)}function Ui(e,n){var t=A;A|=2;var o=cp();(ae!==e||se!==n)&&(sn=null,Yn(e,n));do try{Zh();break}catch(i){dp(e,i)}while(!0);if(ds(),A=t,Hi.current=o,Z!==null)throw Error(_(261));return ae=null,se=0,ne}function Zh(){for(;Z!==null;)pp(Z)}function Jh(){for(;Z!==null&&!Ru();)pp(Z)}function pp(e){var n=mp(e.alternate,e,ze);e.memoizedProps=e.pendingProps,n===null?up(e):Z=n,vs.current=null}function up(e){var n=e;do{var t=n.alternate;if(e=n.return,(n.flags&32768)===0){if(t=Gh(t,n,ze),t!==null){Z=t;return}}else{if(t=$h(t,n),t!==null){t.flags&=32767,Z=t;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{ne=6,Z=null;return}}if(n=n.sibling,n!==null){Z=n;return}Z=n=e}while(n!==null);ne===0&&(ne=5)}function Gn(e,n,t){var o=P,i=Fe.transition;try{Fe.transition=null,P=1,em(e,n,t,o)}finally{Fe.transition=i,P=o}return null}function em(e,n,t,o){do zt();while(In!==null);if((A&6)!==0)throw Error(_(327));t=e.finishedWork;var i=e.finishedLanes;if(t===null)return null;if(e.finishedWork=null,e.finishedLanes=0,t===e.current)throw Error(_(177));e.callbackNode=null,e.callbackPriority=0;var a=t.lanes|t.childLanes;if(Mu(e,a),e===ae&&(Z=ae=null,se=0),(t.subtreeFlags&2064)===0&&(t.flags&2064)===0||ci||(ci=!0,gp(Ci,function(){return zt(),null})),a=(t.flags&15990)!==0,(t.subtreeFlags&15990)!==0||a){a=Fe.transition,Fe.transition=null;var r=P;P=1;var s=A;A|=4,vs.current=null,Kh(e,t),rp(t,e),vh(br),Ri=!!_r,br=_r=null,e.current=t,Yh(t,e,i),Iu(),A=s,P=r,Fe.transition=a}else e.current=t;if(ci&&(ci=!1,In=e,Vi=i),a=e.pendingLanes,a===0&&(Nn=null),Ou(t.stateNode,o),Ee(e,q()),n!==null)for(o=e.onRecoverableError,t=0;t<n.length;t++)i=n[t],o(i.value,{componentStack:i.stack,digest:i.digest});if(Bi)throw Bi=!1,e=Fr,Fr=null,e;return(Vi&1)!==0&&e.tag!==0&&zt(),a=e.pendingLanes,(a&1)!==0?e===Hr?go++:(go=0,Hr=e):go=0,Hn(),null}function zt(){if(In!==null){var e=$d(Vi),n=Fe.transition,t=P;try{if(Fe.transition=null,P=16>e?16:e,In===null)var o=!1;else{if(e=In,In=null,Vi=0,(A&6)!==0)throw Error(_(331));var i=A;for(A|=4,v=e.current;v!==null;){var a=v,r=a.child;if((v.flags&16)!==0){var s=a.deletions;if(s!==null){for(var l=0;l<s.length;l++){var c=s[l];for(v=c;v!==null;){var f=v;switch(f.tag){case 0:case 11:case 15:ho(8,f,a)}var h=f.child;if(h!==null)h.return=f,v=h;else for(;v!==null;){f=v;var g=f.sibling,x=f.return;if(op(f),f===c){v=null;break}if(g!==null){g.return=x,v=g;break}v=x}}}var w=a.alternate;if(w!==null){var b=w.child;if(b!==null){w.child=null;do{var M=b.sibling;b.sibling=null,b=M}while(b!==null)}}v=a}}if((a.subtreeFlags&2064)!==0&&r!==null)r.return=a,v=r;else e:for(;v!==null;){if(a=v,(a.flags&2048)!==0)switch(a.tag){case 0:case 11:case 15:ho(9,a,a.return)}var p=a.sibling;if(p!==null){p.return=a.return,v=p;break e}v=a.return}}var d=e.current;for(v=d;v!==null;){r=v;var u=r.child;if((r.subtreeFlags&2064)!==0&&u!==null)u.return=r,v=u;else e:for(r=d;v!==null;){if(s=v,(s.flags&2048)!==0)try{switch(s.tag){case 0:case 11:case 15:Ji(9,s)}}catch(k){Y(s,s.return,k)}if(s===r){v=null;break e}var y=s.sibling;if(y!==null){y.return=s.return,v=y;break e}v=s.return}}if(A=i,Hn(),an&&typeof an.onPostCommitFiberRoot=="function")try{an.onPostCommitFiberRoot(Gi,e)}catch{}o=!0}return o}finally{P=t,Fe.transition=n}}return!1}function bd(e,n,t){n=Pt(t,n),n=$c(e,n,1),e=Ln(e,n,1),n=_e(),e!==null&&(No(e,1,n),Ee(e,n))}function Y(e,n,t){if(e.tag===3)bd(e,e,t);else for(;n!==null;){if(n.tag===3){bd(n,e,t);break}else if(n.tag===1){var o=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(Nn===null||!Nn.has(o))){e=Pt(t,e),e=Qc(n,e,1),n=Ln(n,e,1),e=_e(),n!==null&&(No(n,1,e),Ee(n,e));break}}n=n.return}}function nm(e,n,t){var o=e.pingCache;o!==null&&o.delete(n),n=_e(),e.pingedLanes|=e.suspendedLanes&t,ae===e&&(se&t)===t&&(ne===4||ne===3&&(se&130023424)===se&&500>q()-Cs?Yn(e,0):ks|=t),Ee(e,n)}function hp(e,n){n===0&&((e.mode&1)===0?n=1:(n=qo,qo<<=1,(qo&130023424)===0&&(qo=4194304)));var t=_e();e=mn(e,n),e!==null&&(No(e,n,t),Ee(e,t))}function tm(e){var n=e.memoizedState,t=0;n!==null&&(t=n.retryLane),hp(e,t)}function om(e,n){var t=0;switch(e.tag){case 13:var o=e.stateNode,i=e.memoizedState;i!==null&&(t=i.retryLane);break;case 19:o=e.stateNode;break;default:throw Error(_(314))}o!==null&&o.delete(n),hp(e,t)}var mp;mp=function(e,n,t){if(e!==null)if(e.memoizedProps!==n.pendingProps||Re.current)Se=!0;else{if((e.lanes&t)===0&&(n.flags&128)===0)return Se=!1,Wh(e,n,t);Se=(e.flags&131072)!==0}else Se=!1,W&&(n.flags&1048576)!==0&&_c(n,Ni,n.index);switch(n.lanes=0,n.tag){case 2:var o=n.type;yi(e,n),e=n.pendingProps;var i=Tt(n,he.current);Et(n,t),i=ys(null,n,o,e,i,t);var a=_s();return n.flags|=1,typeof i=="object"&&i!==null&&typeof i.render=="function"&&i.$$typeof===void 0?(n.tag=1,n.memoizedState=null,n.updateQueue=null,Ie(o)?(a=!0,Ti(n)):a=!1,n.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,us(n),i.updater=Zi,n.stateNode=i,i._reactInternals=n,Er(n,o,e,t),n=Tr(null,n,o,!0,a,t)):(n.tag=0,W&&a&&as(n),ye(null,n,i,t),n=n.child),n;case 16:o=n.elementType;e:{switch(yi(e,n),e=n.pendingProps,i=o._init,o=i(o._payload),n.type=o,i=n.tag=am(o),e=Ge(o,e),i){case 0:n=Or(null,n,o,e,t);break e;case 1:n=dd(null,n,o,e,t);break e;case 11:n=sd(null,n,o,e,t);break e;case 14:n=ld(null,n,o,Ge(o.type,e),t);break e}throw Error(_(306,o,""))}return n;case 0:return o=n.type,i=n.pendingProps,i=n.elementType===o?i:Ge(o,i),Or(e,n,o,i,t);case 1:return o=n.type,i=n.pendingProps,i=n.elementType===o?i:Ge(o,i),dd(e,n,o,i,t);case 3:e:{if(Xc(n),e===null)throw Error(_(387));o=n.pendingProps,a=n.memoizedState,i=a.element,Cc(e,n),Mi(n,o,null,t);var r=n.memoizedState;if(o=r.element,a.isDehydrated)if(a={element:o,isDehydrated:!1,cache:r.cache,pendingSuspenseBoundaries:r.pendingSuspenseBoundaries,transitions:r.transitions},n.updateQueue.baseState=a,n.memoizedState=a,n.flags&256){i=Pt(Error(_(423)),n),n=cd(e,n,o,t,i);break e}else if(o!==i){i=Pt(Error(_(424)),n),n=cd(e,n,o,t,i);break e}else for(Oe=Tn(n.stateNode.containerInfo.firstChild),Te=n,W=!0,Qe=null,t=vc(n,null,o,t),n.child=t;t;)t.flags=t.flags&-3|4096,t=t.sibling;else{if(Lt(),o===i){n=gn(e,n,t);break e}ye(e,n,o,t)}n=n.child}return n;case 5:return Sc(n),e===null&&Sr(n),o=n.type,i=n.pendingProps,a=e!==null?e.memoizedProps:null,r=i.children,xr(o,i)?r=null:a!==null&&xr(o,a)&&(n.flags|=32),qc(e,n),ye(e,n,r,t),n.child;case 6:return e===null&&Sr(n),null;case 13:return Zc(e,n,t);case 4:return hs(n,n.stateNode.containerInfo),o=n.pendingProps,e===null?n.child=Nt(n,null,o,t):ye(e,n,o,t),n.child;case 11:return o=n.type,i=n.pendingProps,i=n.elementType===o?i:Ge(o,i),sd(e,n,o,i,t);case 7:return ye(e,n,n.pendingProps,t),n.child;case 8:return ye(e,n,n.pendingProps.children,t),n.child;case 12:return ye(e,n,n.pendingProps.children,t),n.child;case 10:e:{if(o=n.type._context,i=n.pendingProps,a=n.memoizedProps,r=i.value,D(Ai,o._currentValue),o._currentValue=r,a!==null)if(qe(a.value,r)){if(a.children===i.children&&!Re.current){n=gn(e,n,t);break e}}else for(a=n.child,a!==null&&(a.return=n);a!==null;){var s=a.dependencies;if(s!==null){r=a.child;for(var l=s.firstContext;l!==null;){if(l.context===o){if(a.tag===1){l=pn(-1,t&-t),l.tag=2;var c=a.updateQueue;if(c!==null){c=c.shared;var f=c.pending;f===null?l.next=l:(l.next=f.next,f.next=l),c.pending=l}}a.lanes|=t,l=a.alternate,l!==null&&(l.lanes|=t),Rr(a.return,t,n),s.lanes|=t;break}l=l.next}}else if(a.tag===10)r=a.type===n.type?null:a.child;else if(a.tag===18){if(r=a.return,r===null)throw Error(_(341));r.lanes|=t,s=r.alternate,s!==null&&(s.lanes|=t),Rr(r,t,n),r=a.sibling}else r=a.child;if(r!==null)r.return=a;else for(r=a;r!==null;){if(r===n){r=null;break}if(a=r.sibling,a!==null){a.return=r.return,r=a;break}r=r.return}a=r}ye(e,n,i.children,t),n=n.child}return n;case 9:return i=n.type,o=n.pendingProps.children,Et(n,t),i=He(i),o=o(i),n.flags|=1,ye(e,n,o,t),n.child;case 14:return o=n.type,i=Ge(o,n.pendingProps),i=Ge(o.type,i),ld(e,n,o,i,t);case 15:return Kc(e,n,n.type,n.pendingProps,t);case 17:return o=n.type,i=n.pendingProps,i=n.elementType===o?i:Ge(o,i),yi(e,n),n.tag=1,Ie(o)?(e=!0,Ti(n)):e=!1,Et(n,t),Gc(n,o,i),Er(n,o,i,t),Tr(null,n,o,!0,e,t);case 19:return Jc(e,n,t);case 22:return Yc(e,n,t)}throw Error(_(156,n.tag))};function gp(e,n){return Vd(e,n)}function im(e,n,t,o){this.tag=e,this.key=t,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function De(e,n,t,o){return new im(e,n,t,o)}function Es(e){return e=e.prototype,!(!e||!e.isReactComponent)}function am(e){if(typeof e=="function")return Es(e)?1:0;if(e!=null){if(e=e.$$typeof,e===Qr)return 11;if(e===Kr)return 14}return 2}function Pn(e,n){var t=e.alternate;return t===null?(t=De(e.tag,n,e.key,e.mode),t.elementType=e.elementType,t.type=e.type,t.stateNode=e.stateNode,t.alternate=e,e.alternate=t):(t.pendingProps=n,t.type=e.type,t.flags=0,t.subtreeFlags=0,t.deletions=null),t.flags=e.flags&14680064,t.childLanes=e.childLanes,t.lanes=e.lanes,t.child=e.child,t.memoizedProps=e.memoizedProps,t.memoizedState=e.memoizedState,t.updateQueue=e.updateQueue,n=e.dependencies,t.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},t.sibling=e.sibling,t.index=e.index,t.ref=e.ref,t}function xi(e,n,t,o,i,a){var r=2;if(o=e,typeof e=="function")Es(e)&&(r=1);else if(typeof e=="string")r=5;else e:switch(e){case ht:return qn(t.children,i,a,n);case $r:r=8,i|=8;break;case Za:return e=De(12,t,n,i|2),e.elementType=Za,e.lanes=a,e;case Ja:return e=De(13,t,n,i),e.elementType=Ja,e.lanes=a,e;case er:return e=De(19,t,n,i),e.elementType=er,e.lanes=a,e;case Sd:return na(t,i,a,n);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case kd:r=10;break e;case Cd:r=9;break e;case Qr:r=11;break e;case Kr:r=14;break e;case vn:r=16,o=null;break e}throw Error(_(130,e==null?e:typeof e,""))}return n=De(r,t,n,i),n.elementType=e,n.type=o,n.lanes=a,n}function qn(e,n,t,o){return e=De(7,e,o,n),e.lanes=t,e}function na(e,n,t,o){return e=De(22,e,o,n),e.elementType=Sd,e.lanes=t,e.stateNode={isHidden:!1},e}function Ya(e,n,t){return e=De(6,e,null,n),e.lanes=t,e}function qa(e,n,t){return n=De(4,e.children!==null?e.children:[],e.key,n),n.lanes=t,n.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},n}function rm(e,n,t,o,i){this.tag=n,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Na(0),this.expirationTimes=Na(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Na(0),this.identifierPrefix=o,this.onRecoverableError=i,this.mutableSourceEagerHydrationData=null}function zs(e,n,t,o,i,a,r,s,l){return e=new rm(e,n,t,s,l),n===1?(n=1,a===!0&&(n|=8)):n=0,a=De(3,null,null,n),e.current=a,a.stateNode=e,a.memoizedState={element:o,isDehydrated:t,cache:null,transitions:null,pendingSuspenseBoundaries:null},us(a),e}function sm(e,n,t){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:ut,key:o==null?null:""+o,children:e,containerInfo:n,implementation:t}}function fp(e){if(!e)return jn;e=e._reactInternals;e:{if(ot(e)!==e||e.tag!==1)throw Error(_(170));var n=e;do{switch(n.tag){case 3:n=n.stateNode.context;break e;case 1:if(Ie(n.type)){n=n.stateNode.__reactInternalMemoizedMergedChildContext;break e}}n=n.return}while(n!==null);throw Error(_(171))}if(e.tag===1){var t=e.type;if(Ie(t))return fc(e,t,n)}return n}function yp(e,n,t,o,i,a,r,s,l){return e=zs(t,o,!0,e,i,a,r,s,l),e.context=fp(null),t=e.current,o=_e(),i=An(t),a=pn(o,i),a.callback=n??null,Ln(t,a,i),e.current.lanes=i,No(e,i,o),Ee(e,o),e}function ta(e,n,t,o){var i=n.current,a=_e(),r=An(i);return t=fp(t),n.context===null?n.context=t:n.pendingContext=t,n=pn(a,r),n.payload={element:e},o=o===void 0?null:o,o!==null&&(n.callback=o),e=Ln(i,n,r),e!==null&&(Ye(e,i,r,a),mi(e,i,r)),r}function Wi(e){return e=e.current,e.child?(e.child.tag===5,e.child.stateNode):null}function xd(e,n){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var t=e.retryLane;e.retryLane=t!==0&&t<n?t:n}}function Os(e,n){xd(e,n),(e=e.alternate)&&xd(e,n)}function lm(){return null}var _p=typeof reportError=="function"?reportError:function(e){console.error(e)};function Ts(e){this._internalRoot=e}oa.prototype.render=Ts.prototype.render=function(e){var n=this._internalRoot;if(n===null)throw Error(_(409));ta(e,n,null,null)};oa.prototype.unmount=Ts.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var n=e.containerInfo;nt(function(){ta(null,e,null,null)}),n[hn]=null}};function oa(e){this._internalRoot=e}oa.prototype.unstable_scheduleHydration=function(e){if(e){var n=Yd();e={blockedOn:null,target:e,priority:n};for(var t=0;t<Cn.length&&n!==0&&n<Cn[t].priority;t++);Cn.splice(t,0,e),t===0&&Xd(e)}};function Ls(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function ia(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function wd(){}function dm(e,n,t,o,i){if(i){if(typeof o=="function"){var a=o;o=function(){var c=Wi(r);a.call(c)}}var r=yp(n,o,e,0,null,!1,!1,"",wd);return e._reactRootContainer=r,e[hn]=r.current,Co(e.nodeType===8?e.parentNode:e),nt(),r}for(;i=e.lastChild;)e.removeChild(i);if(typeof o=="function"){var s=o;o=function(){var c=Wi(l);s.call(c)}}var l=zs(e,0,!1,null,null,!1,!1,"",wd);return e._reactRootContainer=l,e[hn]=l.current,Co(e.nodeType===8?e.parentNode:e),nt(function(){ta(n,l,t,o)}),l}function aa(e,n,t,o,i){var a=t._reactRootContainer;if(a){var r=a;if(typeof i=="function"){var s=i;i=function(){var l=Wi(r);s.call(l)}}ta(n,r,e,i)}else r=dm(t,n,e,i,o);return Wi(r)}Qd=function(e){switch(e.tag){case 3:var n=e.stateNode;if(n.current.memoizedState.isDehydrated){var t=io(n.pendingLanes);t!==0&&(Xr(n,t|1),Ee(n,q()),(A&6)===0&&(Mt=q()+500,Hn()))}break;case 13:nt(function(){var o=mn(e,1);if(o!==null){var i=_e();Ye(o,e,1,i)}}),Os(e,1)}};Zr=function(e){if(e.tag===13){var n=mn(e,134217728);if(n!==null){var t=_e();Ye(n,e,134217728,t)}Os(e,134217728)}};Kd=function(e){if(e.tag===13){var n=An(e),t=mn(e,n);if(t!==null){var o=_e();Ye(t,e,n,o)}Os(e,n)}};Yd=function(){return P};qd=function(e,n){var t=P;try{return P=e,n()}finally{P=t}};cr=function(e,n,t){switch(n){case"input":if(or(e,t),n=t.name,t.type==="radio"&&n!=null){for(t=e;t.parentNode;)t=t.parentNode;for(t=t.querySelectorAll("input[name="+JSON.stringify(""+n)+'][type="radio"]'),n=0;n<t.length;n++){var o=t[n];if(o!==e&&o.form===e.form){var i=Yi(o);if(!i)throw Error(_(90));Id(o),or(o,i)}}}break;case"textarea":zd(e,t);break;case"select":n=t.value,n!=null&&Ct(e,!!t.multiple,n,!1)}};Md=Ss;jd=nt;var cm={usingClientEntryPoint:!1,Events:[Po,yt,Yi,Ad,Pd,Ss]},eo={findFiberByHostInstance:$n,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},pm={bundleType:eo.bundleType,version:eo.version,rendererPackageName:eo.rendererPackageName,rendererConfig:eo.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:fn.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=Hd(e),e===null?null:e.stateNode},findFiberByHostInstance:eo.findFiberByHostInstance||lm,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"&&(no=__REACT_DEVTOOLS_GLOBAL_HOOK__,!no.isDisabled&&no.supportsFiber))try{Gi=no.inject(pm),an=no}catch{}var no;Ae.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=cm;Ae.createPortal=function(e,n){var t=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!Ls(n))throw Error(_(200));return sm(e,n,null,t)};Ae.createRoot=function(e,n){if(!Ls(e))throw Error(_(299));var t=!1,o="",i=_p;return n!=null&&(n.unstable_strictMode===!0&&(t=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onRecoverableError!==void 0&&(i=n.onRecoverableError)),n=zs(e,1,!1,null,null,t,!1,o,i),e[hn]=n.current,Co(e.nodeType===8?e.parentNode:e),new Ts(n)};Ae.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var n=e._reactInternals;if(n===void 0)throw typeof e.render=="function"?Error(_(188)):(e=Object.keys(e).join(","),Error(_(268,e)));return e=Hd(n),e=e===null?null:e.stateNode,e};Ae.flushSync=function(e){return nt(e)};Ae.hydrate=function(e,n,t){if(!ia(n))throw Error(_(200));return aa(null,e,n,!0,t)};Ae.hydrateRoot=function(e,n,t){if(!Ls(e))throw Error(_(405));var o=t!=null&&t.hydratedSources||null,i=!1,a="",r=_p;if(t!=null&&(t.unstable_strictMode===!0&&(i=!0),t.identifierPrefix!==void 0&&(a=t.identifierPrefix),t.onRecoverableError!==void 0&&(r=t.onRecoverableError)),n=yp(n,null,e,1,t??null,i,!1,a,r),e[hn]=n.current,Co(e),o)for(e=0;e<o.length;e++)t=o[e],i=t._getVersion,i=i(t._source),n.mutableSourceEagerHydrationData==null?n.mutableSourceEagerHydrationData=[t,i]:n.mutableSourceEagerHydrationData.push(t,i);return new oa(n)};Ae.render=function(e,n,t){if(!ia(n))throw Error(_(200));return aa(null,e,n,!1,t)};Ae.unmountComponentAtNode=function(e){if(!ia(e))throw Error(_(40));return e._reactRootContainer?(nt(function(){aa(null,null,e,!1,function(){e._reactRootContainer=null,e[hn]=null})}),!0):!1};Ae.unstable_batchedUpdates=Ss;Ae.unstable_renderSubtreeIntoContainer=function(e,n,t,o){if(!ia(t))throw Error(_(200));if(e==null||e._reactInternals===void 0)throw Error(_(38));return aa(e,n,t,!1,o)};Ae.version="18.3.1-next-f1338f8080-20240426"});var vp=Je((Of,wp)=>{"use strict";E();z();O();function xp(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(xp)}catch(e){console.error(e)}}xp(),wp.exports=bp()});var Cp=Je(Ns=>{"use strict";E();z();O();var kp=vp();Ns.createRoot=kp.createRoot,Ns.hydrateRoot=kp.hydrateRoot;var Af});var Rp=Je(ra=>{"use strict";E();z();O();var um=Vn(),hm=Symbol.for("react.element"),mm=Symbol.for("react.fragment"),gm=Object.prototype.hasOwnProperty,fm=um.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,ym={key:!0,ref:!0,__self:!0,__source:!0};function Sp(e,n,t){var o,i={},a=null,r=null;t!==void 0&&(a=""+t),n.key!==void 0&&(a=""+n.key),n.ref!==void 0&&(r=n.ref);for(o in n)gm.call(n,o)&&!ym.hasOwnProperty(o)&&(i[o]=n[o]);if(e&&e.defaultProps)for(o in n=e.defaultProps,n)i[o]===void 0&&(i[o]=n[o]);return{$$typeof:hm,type:e,key:a,ref:r,props:i,_owner:fm.current}}ra.Fragment=mm;ra.jsx=Sp;ra.jsxs=Sp});var yn=Je((Uf,Ip)=>{"use strict";E();z();O();Ip.exports=Rp()});var Ep=Je((Qf,sa)=>{E();z();O();(function(){"use strict";var e={}.hasOwnProperty;function n(){for(var i="",a=0;a<arguments.length;a++){var r=arguments[a];r&&(i=o(i,t(r)))}return i}function t(i){if(typeof i=="string"||typeof i=="number")return i;if(typeof i!="object")return"";if(Array.isArray(i))return n.apply(null,i);if(i.toString!==Object.prototype.toString&&!i.toString.toString().includes("[native code]"))return i.toString();var a="";for(var r in i)e.call(i,r)&&i[r]&&(a=o(a,r));return a}function o(i,a){return a?i?i+" "+a:i+a:i}typeof sa<"u"&&sa.exports?(n.default=n,sa.exports=n):typeof define=="function"&&typeof define.amd=="object"&&define.amd?define("classnames",[],function(){return n}):window.classNames=n})()});E();z();O();var st=ke(Vn(),1),Mp=ke(Cp(),1);E();z();O();E();z();O();var zp=3.5;function Op(e){let n=typeof e=="string"?e.trim():e,t=typeof n=="string"?Number(n||NaN):n;return typeof t=="number"&&Number.isFinite(t)&&t>=0?t:zp}function la(e){let n=Op(e)/zp;return t=>Math.round(t*n*100)/100}function As(e,n){return e==null?n:typeof e=="number"?Number.isFinite(e)&&e>=0?e:n:e.trim()===""?n:e}function da(e){let{color:n="#2A2A2A",strokeWidth:t=3.5,fill:o="none",title:i,size:a,width:r,height:s,...l}=e,c={...l},f=As(a,24);return c.width=As(r,f),c.height=As(s,f),c.fill=o,c.stroke=n,c.strokeWidth=Op(t),c}E();z();O();var it=ke(yn(),1);E();z();O();var _m="animal-btn-QoKe1",bm="animal-btn-small-6Srsd",xm="animal-btn-middle-zEXqv",wm="animal-btn-large-k9IvA",vm="animal-btn-default-L7yE6",km="animal-btn-primary-9tMG9",Cm="animal-btn-dashed-wzZ-i",Sm="animal-btn-text-Tope4",Rm="animal-btn-link-pURnf",Im="animal-btn-danger-zQ4kF",Em="animal-btn-ghost-Ykty4",zm="animal-btn-block-MC4pp",Om="animal-btn-loading-PfXLM",Tm="animal-btn-loading-icon--9ayl",Lm="animal-animal-btn-spin-Wj1X-",Nm="animal-btn-icon-P5CS9",Xe={btn:_m,"btn-small":"animal-btn-small-6Srsd",btnSmall:bm,"btn-middle":"animal-btn-middle-zEXqv",btnMiddle:xm,"btn-large":"animal-btn-large-k9IvA",btnLarge:wm,"btn-default":"animal-btn-default-L7yE6",btnDefault:vm,"btn-primary":"animal-btn-primary-9tMG9",btnPrimary:km,"btn-dashed":"animal-btn-dashed-wzZ-i",btnDashed:Cm,"btn-text":"animal-btn-text-Tope4",btnText:Sm,"btn-link":"animal-btn-link-pURnf",btnLink:Rm,"btn-danger":"animal-btn-danger-zQ4kF",btnDanger:Im,"btn-ghost":"animal-btn-ghost-Ykty4",btnGhost:Em,"btn-block":"animal-btn-block-MC4pp",btnBlock:zm,"btn-loading":"animal-btn-loading-PfXLM",btnLoading:Om,"btn-loading-icon":"animal-btn-loading-icon--9ayl",btnLoadingIcon:Tm,"animal-btn-spin":"animal-animal-btn-spin-Wj1X-",animalBtnSpin:Lm,"btn-icon":"animal-btn-icon-P5CS9",btnIcon:Nm};E();z();O();var Tp=ke(Vn(),1),Ve=ke(yn(),1),Ps=(0,Tp.forwardRef)((e,n)=>{let t=!!(e.title||e["aria-label"]||e.role);return la(e.strokeWidth),(0,Ve.jsxs)("svg",{ref:n,viewBox:"0 0 48 48",xmlns:"http://www.w3.org/2000/svg",fill:"none",strokeLinecap:"round",strokeLinejoin:"round",role:e.title?"img":void 0,"aria-hidden":t?void 0:!0,...da(e),children:[e.title?(0,Ve.jsx)("title",{children:e.title}):null,(0,Ve.jsx)("circle",{cx:"24",cy:"24",r:"15",fill:"#F4A6A4"}),(0,Ve.jsx)("circle",{cx:"24",cy:"24",r:"6",fill:"#FFFFFF"}),(0,Ve.jsx)("rect",{x:"17",y:"13",width:"4.5",height:"1.8",rx:"0.9",transform:"rotate(25 19 14)",fill:"#E9C46A"}),(0,Ve.jsx)("rect",{x:"27",y:"12",width:"4.5",height:"1.8",rx:"0.9",transform:"rotate(-20 29 13)",fill:"#2A9D8F"}),(0,Ve.jsx)("rect",{x:"32",y:"19",width:"4.5",height:"1.8",rx:"0.9",transform:"rotate(45 34 20)",fill:"#264653"}),(0,Ve.jsx)("rect",{x:"13",y:"22",width:"4.5",height:"1.8",rx:"0.9",transform:"rotate(-35 15 23)",fill:"#E9C46A"}),(0,Ve.jsx)("rect",{x:"30",y:"30",width:"4.5",height:"1.8",rx:"0.9",transform:"rotate(15 32 31)",fill:"#2A9D8F"}),(0,Ve.jsx)("rect",{x:"17",y:"31",width:"4.5",height:"1.8",rx:"0.9",transform:"rotate(60 19 32)",fill:"#264653"})]})});Ps.displayName="DonutIcon";var ca=({type:e="default",size:n="middle",danger:t=!1,ghost:o=!1,block:i=!1,loading:a=!1,disabled:r=!1,icon:s,htmlType:l="button",children:c,className:f,...h})=>{let g=[Xe.btn,Xe[`btn-${e}`],Xe[`btn-${n}`],t&&Xe["btn-danger"],o&&Xe["btn-ghost"],i&&Xe["btn-block"],a&&Xe["btn-loading"],f].filter(Boolean).join(" ");return(0,it.jsxs)("button",{type:l,className:g,disabled:r,...h,children:[a?(0,it.jsx)("span",{className:Xe["btn-icon"],"aria-hidden":!0,children:(0,it.jsx)(Ps,{size:28,color:"currentColor",className:Xe["btn-loading-icon"]})}):s&&(0,it.jsx)("span",{className:Xe["btn-icon"],children:s}),c&&(0,it.jsx)("span",{children:c})]})};ca.displayName="Button";E();z();O();var Lp=ke(yn(),1);E();z();O();var Am="animal-card-DJ515",Pm="animal-card-dashed-fqnm1",Mm="animal-card-hoverable-RF-YV",jm="animal-card-app-pink-3Eo8d",Dm="animal-card-purple-Gq7sR",Fm="animal-card-app-blue-GHH1a",Hm="animal-card-app-yellow-DWB-L",Bm="animal-card-app-orange-V5yD7",Vm="animal-card-app-teal-R5kFG",Um="animal-card-app-green-xlNUs",Wm="animal-card-app-red-DzE0l",Gm="animal-card-lime-green-KiJbe",$m="animal-card-yellow-green-4c-lF",Qm="animal-card-brown-hLCrx",Km="animal-card-warm-peach-pink-RlSVo",Ym="animal-pattern-default-w-ord",qm="animal-pattern-app-pink--UNSj",Xm="animal-pattern-purple-uTyc6",Zm="animal-pattern-app-blue-KIXQM",Jm="animal-pattern-app-yellow-K9MwO",eg="animal-pattern-app-orange-QdKbc",ng="animal-pattern-app-teal-bRRLd",tg="animal-pattern-app-green-FKDYa",og="animal-pattern-app-red--c4q5",ig="animal-pattern-lime-green-z13TC",ag="animal-pattern-yellow-green-Cgkp8",rg="animal-pattern-brown-2fhlx",sg="animal-pattern-warm-peach-pink-EXPaC",Ft={card:Am,"card-dashed":"animal-card-dashed-fqnm1",cardDashed:Pm,"card-hoverable":"animal-card-hoverable-RF-YV",cardHoverable:Mm,"card-app-pink":"animal-card-app-pink-3Eo8d",cardAppPink:jm,"card-purple":"animal-card-purple-Gq7sR",cardPurple:Dm,"card-app-blue":"animal-card-app-blue-GHH1a",cardAppBlue:Fm,"card-app-yellow":"animal-card-app-yellow-DWB-L",cardAppYellow:Hm,"card-app-orange":"animal-card-app-orange-V5yD7",cardAppOrange:Bm,"card-app-teal":"animal-card-app-teal-R5kFG",cardAppTeal:Vm,"card-app-green":"animal-card-app-green-xlNUs",cardAppGreen:Um,"card-app-red":"animal-card-app-red-DzE0l",cardAppRed:Wm,"card-lime-green":"animal-card-lime-green-KiJbe",cardLimeGreen:Gm,"card-yellow-green":"animal-card-yellow-green-4c-lF",cardYellowGreen:$m,"card-brown":"animal-card-brown-hLCrx",cardBrown:Qm,"card-warm-peach-pink":"animal-card-warm-peach-pink-RlSVo",cardWarmPeachPink:Km,"pattern-default":"animal-pattern-default-w-ord",patternDefault:Ym,"pattern-app-pink":"animal-pattern-app-pink--UNSj",patternAppPink:qm,"pattern-purple":"animal-pattern-purple-uTyc6",patternPurple:Xm,"pattern-app-blue":"animal-pattern-app-blue-KIXQM",patternAppBlue:Zm,"pattern-app-yellow":"animal-pattern-app-yellow-K9MwO",patternAppYellow:Jm,"pattern-app-orange":"animal-pattern-app-orange-QdKbc",patternAppOrange:eg,"pattern-app-teal":"animal-pattern-app-teal-bRRLd",patternAppTeal:ng,"pattern-app-green":"animal-pattern-app-green-FKDYa",patternAppGreen:tg,"pattern-app-red":"animal-pattern-app-red--c4q5",patternAppRed:og,"pattern-lime-green":"animal-pattern-lime-green-z13TC",patternLimeGreen:ig,"pattern-yellow-green":"animal-pattern-yellow-green-Cgkp8",patternYellowGreen:ag,"pattern-brown":"animal-pattern-brown-2fhlx",patternBrown:rg,"pattern-warm-peach-pink":"animal-pattern-warm-peach-pink-EXPaC",patternWarmPeachPink:sg};var _n=({type:e="default",color:n="default",pattern:t="none",hoverable:o=!1,children:i,className:a,style:r,...s})=>{let l=[Ft.card,e==="dashed"&&Ft["card-dashed"],n!=="default"&&Ft[`card-${n}`],t!=="none"&&Ft[`pattern-${t}`],o&&Ft["card-hoverable"],a].filter(Boolean).join(" ");return(0,Lp.jsx)("div",{className:l,style:r,...s,children:i})};_n.displayName="Card";E();z();O();var Np=ke(Vn(),1),at=ke(yn(),1),Ms=(0,Np.forwardRef)((e,n)=>{let t=!!(e.title||e["aria-label"]||e.role),o=la(e.strokeWidth);return(0,at.jsxs)("svg",{ref:n,viewBox:"0 0 48 48",xmlns:"http://www.w3.org/2000/svg",fill:"none",strokeLinecap:"round",strokeLinejoin:"round",role:e.title?"img":void 0,"aria-hidden":t?void 0:!0,...da(e),children:[e.title?(0,at.jsx)("title",{children:e.title}):null,(0,at.jsx)("circle",{cx:"24",cy:"24",r:"17",fill:"#FAEDCD"}),(0,at.jsx)("path",{d:"M17 17 L 31 31",stroke:"#E76F51",strokeWidth:o(4.5)}),(0,at.jsx)("path",{d:"M31 17 L 17 31",stroke:"#E76F51",strokeWidth:o(4.5)})]})});Ms.displayName="CloseIcon";E();z();O();var ge=ke(yn(),1),G=ke(Vn(),1);E();z();O();var lg="animal-wrapper-pbOTq",dg="animal-trigger-2-Ahh",cg="animal-open-867xo",pg="animal-value-623RB",ug="animal-placeholder-vpC8E",hg="animal-searchInput-Lw92p",mg="animal-clear-vjtPx",gg="animal-notFound-2i9uo",fg="animal-arrow-xNbxA",yg="animal-dropdown-0l6jF",_g="animal-option-GEkLI",bg="animal-active-jtSpt",xg="animal-pillBar-O9cTb",wg="animal-optionDot-FQtyw",vg="animal-disabled-Oy12C",me={wrapper:lg,trigger:dg,open:cg,value:pg,placeholder:ug,searchInput:hg,clear:mg,notFound:gg,arrow:fg,dropdown:yg,option:_g,active:bg,pillBar:xg,optionDot:wg,disabled:vg};var rt=({options:e,value:n,onChange:t,placeholder:o="\u8BF7\u9009\u62E9",disabled:i=!1,allowClear:a=!1,onClear:r,clearAriaLabel:s="\u6E05\u9664",showSearch:l=!1,filterOption:c=!0,optionFilterProp:f="label",onSearch:h,notFoundContent:g="\u6682\u65E0\u6570\u636E","aria-label":x,"aria-labelledby":w})=>{let[b,M]=(0,G.useState)(!1),[p,d]=(0,G.useState)(null),[u,y]=(0,G.useState)(null),[k,C]=(0,G.useState)({}),[S,R]=(0,G.useState)(!1),[X,L]=(0,G.useState)(!1),ve=(0,G.useRef)(null),Ht=(0,G.useRef)(null),Bt=(0,G.useRef)(null),js=e.find(I=>I.key===n)?.label||o,Vt=n?js:"",Ds=`animal-select-${(0,G.useId)().replace(/:/g,"")}`,Fs=`${Ds}-listbox`,Hs=I=>`${Ds}-option-${I}`,te=(0,G.useMemo)(()=>{if(!l||!c||!u)return e;let I=typeof c=="function"?c:(N,Ze)=>Ze[f].toLowerCase().includes(N.toLowerCase());return e.filter(N=>I(u,N))},[e,l,c,f,u]),lt=(0,G.useCallback)(()=>{M(!1),R(!1),u&&h?.(""),y(null)},[u,h]),jo=(0,G.useCallback)(()=>{l?Bt.current?.focus():Ht.current?.focus()},[l]);(0,G.useEffect)(()=>{let I=N=>{ve.current&&!ve.current.contains(N.target)&&lt()};return b&&document.addEventListener("mousedown",I),()=>document.removeEventListener("mousedown",I)},[b,lt]),(0,G.useEffect)(()=>{if(b&&ve.current){let I=ve.current.getBoundingClientRect(),N=window.innerWidth,Ze=window.innerHeight,Ut=e.length*44+24,oe={position:"absolute"};I.right+200>N?(oe.right="100%",oe.marginRight="6px",oe.left="auto"):(oe.left="100%",oe.marginLeft="6px",oe.right="auto");let ha=Ze-I.bottom,Fp=I.top;ha<Ut&&Fp>ha?(oe.top="auto",oe.bottom="100%",oe.marginBottom="6px",delete oe.transform):ha<Ut||I.top<Ut?(oe.top="100%",oe.marginTop="6px",oe.bottom="auto",delete oe.transform):(oe.top="50%",oe.transform="translateY(-50%)",oe.bottom="auto"),C(oe),requestAnimationFrame(()=>{R(!0)})}else b||R(!1)},[b,e.length]),(0,G.useEffect)(()=>{if(!l)return;let I=Bt.current;if(I){if(u!==null){b&&I.focus();return}b&&I.focus()}},[b,l,u,n]),(0,G.useEffect)(()=>{if(!b){d(null);return}d(I=>te.some(N=>N.key===I)?I:te.find(N=>N.key===n)?.key??te[0]?.key??null)},[b,n,te]);let Bs=(0,G.useCallback)(I=>{t(I),lt(),jo()},[t,lt,jo]),Vs=I=>{if(!te.length)return;let N=te.findIndex(Ut=>Ut.key===p),Ze=N<0?I===1?0:te.length-1:(N+I+te.length)%te.length;d(te[Ze].key)},jp=I=>{if(i||!(I.target===Ht.current||I.target===Bt.current))return;let{key:N}=I;if(!b){(N==="Enter"||N===" "||N==="ArrowDown"||N==="ArrowUp")&&(I.preventDefault(),M(!0));return}if(N==="Escape"){if(I.preventDefault(),l&&u){y(null),h?.("");return}lt(),jo()}else N==="ArrowDown"?(I.preventDefault(),Vs(1)):N==="ArrowUp"?(I.preventDefault(),Vs(-1)):N==="Home"?(I.preventDefault(),te[0]&&d(te[0].key)):N==="End"?(I.preventDefault(),te.length&&d(te[te.length-1].key)):(N==="Enter"||N===" "&&!l)&&(I.preventDefault(),p&&te.some(Ze=>Ze.key===p)&&Bs(p))},Dp=a&&!!n&&!i&&X,Us={"aria-haspopup":"listbox","aria-expanded":b,"aria-controls":b?Fs:void 0,"aria-activedescendant":b&&p?Hs(p):void 0,"aria-label":x,"aria-labelledby":w};return(0,ge.jsxs)("div",{ref:ve,className:`${me.wrapper} ${i?me.disabled:""}`,onKeyDown:jp,onMouseEnter:()=>L(!0),onMouseLeave:()=>L(!1),children:[(0,ge.jsxs)("div",{ref:Ht,className:`${me.trigger} ${b?me.open:""}`,onClick:I=>{i||I.target===Bt.current&&b||(b?lt():M(!0))},role:l?void 0:"combobox",tabIndex:l||i?void 0:0,"aria-disabled":l?void 0:i||void 0,...l?{}:Us,children:[l?(0,ge.jsx)("input",{ref:Bt,className:me.searchInput,role:"combobox","aria-autocomplete":"list","aria-disabled":i||void 0,...Us,value:b?u??Vt:Vt,placeholder:o,disabled:i,autoComplete:"off",onChange:I=>{let N=I.target.value,Ze=u===null&&n&&Vt!==""&&N.startsWith(Vt)?N.slice(Vt.length):N;y(Ze),h?.(Ze),b||M(!0)}}):(0,ge.jsx)("span",{className:n?me.value:me.placeholder,children:js}),Dp&&(0,ge.jsx)("button",{type:"button",className:me.clear,"aria-label":s,onClick:I=>{I.stopPropagation(),t(""),r?.(),jo()},onMouseDown:I=>I.preventDefault(),children:(0,ge.jsx)(Ms,{size:12})}),(0,ge.jsx)("span",{className:me.arrow,"aria-hidden":!0,children:(0,ge.jsx)("svg",{width:"12",height:"12",viewBox:"0 0 12 12",fill:"none",children:(0,ge.jsx)("path",{d:"M3 4.5L6 7.5L9 4.5",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})})})]}),b&&S&&(0,ge.jsx)("div",{className:me.dropdown,style:k,role:"listbox",id:Fs,"aria-label":x,"aria-labelledby":w,children:te.length===0?(0,ge.jsx)("div",{className:me.notFound,role:"option","aria-disabled":"true","aria-selected":"false",children:g}):te.map(I=>{let N=n===I.key;return(0,ge.jsxs)("div",{id:Hs(I.key),role:"option","aria-selected":N,className:`${me.option} ${N?me.active:""}`,onClick:()=>Bs(I.key),onMouseEnter:()=>{d(I.key)},children:[(0,ge.jsx)("span",{className:me.optionDot,"aria-hidden":!0}),I.label,N&&(0,ge.jsx)("div",{className:me.pillBar})]},I.key)})})]})};rt.displayName="Select";E();z();O();var xe=ke(yn(),1),bn=ke(Ep(),1);E();z();O();var kg="animal-title-3j08r",Cg="animal-ribbon-S4CL0",Sg="animal-ribbonText-FUXBT",Rg="animal-ribbonBack-cW93o",Ig="animal-ribbonBackLeft-TZiON",Eg="animal-ribbonBackRight-AipiN",zg="animal-ribbonFold-qTBSV",Og="animal-ribbonFoldLeft-gVuCs",Tg="animal-ribbonFoldRight-94--n",Lg="animal-ribbonFront-qihIp",Ng="animal-layer-bqKhN",Ag="animal-layerFront-3DCJ-",Pg="animal-tab-9tdIL",Mg="animal-tabText-4dty4",jg="animal-color-app-pink-m6nip",Dg="animal-color-purple-atkjz",Fg="animal-color-app-blue-Y3iTY",Hg="animal-color-app-yellow-JDjDu",Bg="animal-color-app-orange-NmeMm",Vg="animal-color-app-teal-QdItW",Ug="animal-color-app-green-E-Bfq",Wg="animal-color-app-red-Bn9jO",Gg="animal-color-lime-green-TD3ck",$g="animal-color-yellow-green-KnmJ5",Qg="animal-color-brown-Xr3XB",Kg="animal-color-warm-peach-pink-4dp6n",J={title:kg,ribbon:Cg,ribbonText:Sg,ribbonBack:Rg,ribbonBackLeft:Ig,ribbonBackRight:Eg,ribbonFold:zg,ribbonFoldLeft:Og,ribbonFoldRight:Tg,ribbonFront:Lg,layer:Ng,layerFront:Ag,tab:Pg,tabText:Mg,"color-app-pink":"animal-color-app-pink-m6nip",colorAppPink:jg,"color-purple":"animal-color-purple-atkjz",colorPurple:Dg,"color-app-blue":"animal-color-app-blue-Y3iTY",colorAppBlue:Fg,"color-app-yellow":"animal-color-app-yellow-JDjDu",colorAppYellow:Hg,"color-app-orange":"animal-color-app-orange-NmeMm",colorAppOrange:Bg,"color-app-teal":"animal-color-app-teal-QdItW",colorAppTeal:Vg,"color-app-green":"animal-color-app-green-E-Bfq",colorAppGreen:Ug,"color-app-red":"animal-color-app-red-Bn9jO",colorAppRed:Wg,"color-lime-green":"animal-color-lime-green-TD3ck",colorLimeGreen:Gg,"color-yellow-green":"animal-color-yellow-green-KnmJ5",colorYellowGreen:$g,"color-brown":"animal-color-brown-Xr3XB",colorBrown:Qg,"color-warm-peach-pink":"animal-color-warm-peach-pink-4dp6n",colorWarmPeachPink:Kg};var Yg={small:14,middle:20,large:28},qg=({children:e,fontSize:n,color:t})=>(0,xe.jsxs)("span",{className:(0,bn.default)(J.ribbon,t&&t!=="default"&&J[`color-${t}`]),style:{fontSize:`${n}px`},children:[(0,xe.jsx)("span",{className:(0,bn.default)(J.ribbonBack,J.ribbonBackLeft),"aria-hidden":!0}),(0,xe.jsx)("span",{className:(0,bn.default)(J.ribbonBack,J.ribbonBackRight),"aria-hidden":!0}),(0,xe.jsx)("span",{className:(0,bn.default)(J.ribbonFold,J.ribbonFoldLeft),"aria-hidden":!0}),(0,xe.jsx)("span",{className:(0,bn.default)(J.ribbonFold,J.ribbonFoldRight),"aria-hidden":!0}),(0,xe.jsx)("span",{className:J.ribbonFront,"aria-hidden":!0}),(0,xe.jsx)("span",{className:J.ribbonText,children:e})]}),Xg=({children:e,fontSize:n,color:t})=>(0,xe.jsx)("span",{className:(0,bn.default)(J.layer,t&&t!=="default"&&J[`color-${t}`]),style:{fontSize:`${n}px`},children:(0,xe.jsx)("span",{className:J.layerFront,children:e})}),Zg=({children:e,fontSize:n,color:t})=>(0,xe.jsx)("span",{className:(0,bn.default)(J.tab,t&&t!=="default"&&J[`color-${t}`]),style:{fontSize:`${n}px`},children:(0,xe.jsx)("span",{className:J.tabText,children:e})}),Jg={ribbon:qg,layer:Xg,tab:Zg},pa=({children:e,size:n="middle",color:t="default",variant:o="ribbon",className:i,style:a})=>{let r=Jg[o];return(0,xe.jsx)("span",{className:(0,bn.default)(J.title,i),style:a,children:(0,xe.jsx)(r,{fontSize:Yg[n],color:t,children:e})})};pa.displayName="Title";E();z();O();var m=ke(yn(),1),Bn=F,we=H,Ap={card:"Card",chip:"Chip \u5B50\u9879",badge:"Template Badge"};function Pp({src:e,alt:n,width:t,height:o}){let[i,a]=(0,st.useState)(!1),[r,s]=(0,st.useState)(!1),l=!!(t&&o&&t>0&&o>0);return i?(0,m.jsx)("div",{className:"missing",children:"\u622A\u56FE\u6587\u4EF6\u4E0D\u53EF\u7528\uFF0C\u4E0D\u80FD\u4F5C\u4E3A\u89C6\u89C9\u9A8C\u8BC1\u8BC1\u636E\u3002"}):(0,m.jsxs)("div",{className:l?"image-slot":void 0,style:l?{width:"100%",maxWidth:t,aspectRatio:`${t} / ${o}`}:{},children:[l&&!r&&(0,m.jsx)("span",{className:"image-placeholder","aria-hidden":"true",children:"\u52A0\u8F7D\u539F\u59CB\u622A\u56FE"}),(0,m.jsx)("img",{src:e,alt:n,width:t,height:o,loading:"lazy",onLoad:()=>s(!0),onError:()=>a(!0)})]})}function ua(e,n,t){return!!(["card:empty","chip:spacer"].includes(e.id)&&n?.status==="expected-blank"&&n.host&&Object.hasOwn(n,"state")&&n.dimensions&&t in n.dimensions&&n[t]===null)}function ef({ev:e,side:n}){let t=e.dimensions?.[n];return(0,m.jsxs)("details",{children:[(0,m.jsx)("summary",{children:"\u5B9E\u9645\u8FD0\u884C\u914D\u7F6E / \u72B6\u6001 / bbox"}),(0,m.jsxs)("p",{children:["\u5BBF\u4E3B\uFF1A",e.host," \xB7 HA ",e.haVersion||we.haVersion," \xB7 \u6355\u83B7\uFF1A",we.generatedAt||"\u672A\u8BB0\u5F55"]}),(0,m.jsxs)("p",{children:["\u8FD0\u884C commit\uFF1A",we.commit||"\u672A\u8BB0\u5F55"," \xB7 \u72B6\u6001\u6807\u7B7E\uFF1A",e.state??"\u65E0\u5B9E\u4F53\u72B6\u6001\uFF08\u5E03\u5C40\u6216\u5BFC\u822A\uFF09"]}),(0,m.jsxs)("p",{children:["bbox\uFF1A",t?`x ${t.x}, y ${t.y}, width ${t.width}px, height ${t.height}px`:"null / \u65E0\u53EF\u89C1\u8FB9\u754C\u6846"]}),(0,m.jsx)("pre",{children:JSON.stringify(e.config?.[n]||{},null,2)}),(0,m.jsxs)("details",{children:[(0,m.jsx)("summary",{children:"\u672C\u7EC4\u4EF6\u5B9E\u9645\u5B9E\u4F53\u72B6\u6001\u4E0E\u8BA1\u7B97\u6837\u5F0F"}),(0,m.jsx)("pre",{children:JSON.stringify({entity:e.entityStates?.[n],computedStyles:e.computedStyles?.[n]},null,2)})]}),(0,m.jsxs)("details",{children:[(0,m.jsx)("summary",{children:"\u8FD0\u884C\u65F6\u5408\u6210\u5B9E\u4F53\u72B6\u6001\u4E0E attributes"}),(0,m.jsx)("pre",{children:JSON.stringify(we.fixtureStates||{},null,2)})]})]})}function nf({row:e,state:n}){let t=we.cases[e.id],o=B[e.id],i=!!(t?.host&&Object.hasOwn(t,"state")&&["original","island"].every(a=>t[a]||ua(e,t,a))&&(n==="all"||t.state===n));return(0,m.jsx)("div",{className:"pair",children:["original","island"].map(a=>(0,m.jsxs)("article",{children:[(0,m.jsx)("h3",{children:a==="original"?"Mushroom v5.2.3":"Animal Island fork"}),(0,m.jsx)("p",{className:"tag",children:String(a==="original"?e.original_config.type:e.island_config.type)}),i&&ua(e,t,a)?(0,m.jsx)(_n,{children:(0,m.jsxs)("div",{className:"expected-blank",children:[(0,m.jsx)("strong",{children:"\u771F\u5B9E HA\uFF1A\u9884\u671F\u7A7A\u767D / \u65E0\u53EF\u89C1\u5185\u5BB9"}),(0,m.jsxs)("p",{children:[e.id==="card:empty"?"Empty \u662F\u6709\u610F\u4E0D\u53EF\u89C1\u7684\u5E03\u5C40\u5360\u4F4D\u5361\u3002":"Spacer \u662F Chips \u5BB9\u5668\u7684\u5F39\u6027\u95F4\u9694\uFF0C\u4E0D\u662F\u53EF\u89C1 Chip\u3002"," \u6B64\u72B6\u6001\u4E0D\u751F\u6210\u4F2A\u9020\u622A\u56FE\u3002"]}),(0,m.jsx)("p",{children:"\u6355\u83B7\u72B6\u6001\uFF1Aexpected-blank\uFF1B\u8BB0\u5F55\u672C\u6B21\u5B9E\u9645\u5E03\u5C40\u7ED3\u679C\u3002"})]})}):i?(0,m.jsxs)("figure",{children:[(0,m.jsx)(Pp,{src:t[a],width:t.dimensions?.[a]?.width,height:t.dimensions?.[a]?.height,alt:`${e.id} ${a} in ${t.host}; state ${t.state}`}),(0,m.jsxs)("figcaption",{children:["\u5B9E\u9645 HA \u539F\u59CB\u77E9\u5F62\u622A\u56FE\u533A\u57DF\uFF08\u975E\u5361\u7247\u5916\u5F62\uFF09 \xB7 ",t.state??"\u65E0\u5B9E\u4F53\u72B6\u6001\uFF08\u5E03\u5C40\u6216\u5BFC\u822A\uFF09"," \xB7 ",t.host," \xB7 HA ",t.haVersion||we.haVersion||"\u7248\u672C\u672A\u8BB0\u5F55",(0,m.jsx)("br",{}),"\u622A\u56FE\u62A5\u544A\u72B6\u6001\uFF1A",t.status||"\u672A\u62A5\u544A"," \xB7 ",t.grid||"\u5E03\u5C40\u89C1\u8FD0\u884C\u62A5\u544A"]})]}):a==="original"&&o?(0,m.jsxs)("figure",{children:[(0,m.jsx)(Pp,{src:o.path,width:o.width,height:o.height,alt:`${e.id} \u5B98\u65B9 v5.2.3 \u6587\u6863\u9759\u6001\u6837\u4F8B\uFF0C\u975E\u5F53\u524D fixture \u72B6\u6001`}),(0,m.jsxs)("figcaption",{children:["\u5B98\u65B9\u6587\u6863\u9759\u6001\u622A\u56FE\uFF1B\u539F\u56FE\u7684\u72B6\u6001\u3001\u5C3A\u5BF8\u53CA HA \u5BBF\u4E3B\u7248\u672C\u672A\u8BB0\u5F55\uFF0C\u4E0D\u968F\u7B5B\u9009\u53D8\u5316\u3002",(0,m.jsx)("br",{}),(0,m.jsx)("a",{href:o.source,children:"\u67E5\u770B\u56FA\u5B9A\u7248\u672C\u539F\u56FE"})]})]}):(0,m.jsx)(_n,{children:(0,m.jsxs)("div",{className:"missing",children:[(0,m.jsx)("strong",{children:a==="original"?"\u6682\u65E0\u6B64\u9879\u72EC\u7ACB\u5B98\u65B9\u622A\u56FE":"\u7B49\u5F85\u771F\u5B9E HA \u540C\u72B6\u6001\u622A\u56FE"}),(0,m.jsx)("p",{children:a==="original"?"\u4E0D\u501F\u7528\u5176\u4ED6\u7EC4\u4EF6\u56FE\u7247\uFF0C\u4E0D\u6A21\u62DF\u539F\u7248\u5BBF\u4E3B\u3002":"\u5B9E\u73B0\u5305\u5DF2\u4E0E\u9884\u89C8\u5206\u79BB\u3002\u6B64\u5904\u4E0D\u4EE5 React \u753B\u7A3F\u6216\u5047 HA DOM \u4EE3\u66FF\u5B9E\u9645 fork \u6E32\u67D3\u3002"}),(0,m.jsxs)("p",{children:["\u6D4B\u8BD5 fixture\uFF1A",e.initial_state," \xB7 \u8BC1\u636E\uFF1A\u672A\u9A8C\u8BC1"]})]})}),i&&t&&(0,m.jsx)(ef,{ev:t,side:a})]},a))})}var tf={"press-scale":"\u6309\u538B\u7F29\u5C0F","release-bounce":"\u677E\u624B\u8F7B\u56DE\u5F39","pointer-ripple":"\u89E6\u70B9\u6CE2\u7EB9","slider-sync":"\u6ED1\u5757\u540C\u6B65","backend-state-change":"HA \u540E\u7AEF\u72B6\u6001\u53D8\u5316","reduced-motion":"\u51CF\u5C11\u52A8\u6001\u6548\u679C\u8BBE\u7F6E"};function of(){let e=we.motion;return(0,m.jsxs)("section",{className:"section",children:[(0,m.jsx)("h2",{children:"\u52A8\u6548 \xB7 \u771F\u5B9E HA \u5B9E\u5F55"}),e?(0,m.jsxs)(m.Fragment,{children:[(0,m.jsxs)("p",{children:["\u5DF2\u767B\u5F55\u7684\u72EC\u7ACB\u5408\u6210\u4EEA\u8868\u76D8\u5F55\u5236\uFF0CHA ",e.haVersion," \xB7 ",e.durationSeconds," \u79D2\u3002\u70B9\u51FB\u64AD\u653E\u67E5\u770B\uFF0C\u9ED8\u8BA4\u4E0D\u81EA\u52A8\u64AD\u653E\u3001\u4E0D\u5FAA\u73AF\uFF1B\u4E0D\u662F React \u7ED8\u5236\u7684\u6A21\u62DF\u5361\u7247\u3002"]}),(0,m.jsxs)("video",{className:"motion-video",controls:!0,playsInline:!0,preload:"none",width:e.width,height:e.height,style:{aspectRatio:`${e.width} / ${e.height}`},"aria-label":"\u771F\u5B9E Home Assistant \u52A8\u6548\u5B9E\u5F55",children:[(0,m.jsx)("source",{src:e.video,type:"video/webm"}),"\u6B64\u6D4F\u89C8\u5668\u4E0D\u652F\u6301 WebM\uFF0C\u8BF7\u4E0B\u8F7D\u5B9E\u5F55\u89C2\u770B\u3002"]}),(0,m.jsxs)("p",{children:["\u672C\u6B21\u8BB0\u5F55\uFF1A",e.observed.map(n=>tf[n]||n).join(" \xB7 "),"\u3002",(0,m.jsx)("a",{href:e.video,download:!0,children:"\u4E0B\u8F7D\u5B9E\u5F55"})]})]}):(0,m.jsx)("p",{children:"\u771F\u5B9E HA \u52A8\u6548\u5B9E\u5F55\u5C1A\u672A\u751F\u6210\uFF1B\u8FD9\u91CC\u4E0D\u4EE5\u9759\u6001\u622A\u56FE\u6216\u7F51\u9875\u52A8\u753B\u4EE3\u66FF\u8FD0\u884C\u8BC1\u636E\u3002"})]})}function af(){let[e,n]=(0,st.useState)("all"),[t,o]=(0,st.useState)("all"),[i,a]=(0,st.useState)("all"),[r,s]=(0,st.useState)("all"),l=Bn.cases.filter(h=>(e==="all"||h.kind===e)&&(t==="all"||h.id===t)&&(i==="all"||h.states.includes(i)||h.initial_state===i)&&(r==="all"||(r==="grid"?!!h.grid:r==="badge"?h.kind==="badge":h.kind==="chip"||["chips","title"].includes(h.name)))),c=Object.values(we.cases).filter(h=>h.original&&h.island&&h.host&&Object.hasOwn(h,"state")).length,f=Bn.cases.filter(h=>ua(h,we.cases[h.id],"original")&&ua(h,we.cases[h.id],"island")).length;return(0,m.jsxs)("main",{children:[(0,m.jsxs)("header",{children:[(0,m.jsx)("p",{className:"eyebrow",children:"MUSHROOM \xD7 ANIMAL ISLAND \xB7 v5.2.3"}),(0,m.jsx)("h1",{children:(0,m.jsx)(pa,{variant:"ribbon",size:"small",children:"\u5C0F\u5C9B\u7EC4\u4EF6 \xB7 \u5168\u91CF\u5BF9\u6807"})}),(0,m.jsx)("p",{children:"18 \u5F20\u73B0\u884C\u5361\u7247\u30011 \u4E2A\u72EC\u7ACB Template Badge\u300111 \u79CD Chip \u5B50\u9879\u3002\u9010\u9879\u770B\u6765\u6E90\u3001\u914D\u7F6E\u4E0E\u9A8C\u8BC1\u8BC1\u636E\u3002"}),(0,m.jsxs)("div",{className:"metrics",children:[(0,m.jsxs)(_n,{children:[(0,m.jsx)("strong",{children:"18"}),(0,m.jsx)("span",{children:"Cards \xB7 \u4E0D\u542B Legacy"})]}),(0,m.jsxs)(_n,{children:[(0,m.jsx)("strong",{children:"1"}),(0,m.jsx)("span",{children:"Template Badge"})]}),(0,m.jsxs)(_n,{children:[(0,m.jsx)("strong",{children:"11"}),(0,m.jsx)("span",{children:"Chips \u5BB9\u5668\u5185\u7684\u5B50\u7C7B\u578B"})]})]})]}),(0,m.jsxs)("section",{className:"section",children:[(0,m.jsx)("h2",{children:"\u9A8C\u8BC1\u72B6\u6001"}),we.validation?(0,m.jsxs)("p",{children:[(0,m.jsxs)("strong",{children:["\u5168 30 \u9879\u7EC4\u4EF6\u5DF2\u5B9E\u73B0\uFF1A",c," \u9879 HA \u540C\u72B6\u6001\u53CC\u4FA7\u622A\u56FE\uFF0C",f," \u9879\u9884\u671F\u7A7A\u767D\uFF1B\u672C\u6B21 ",we.validation.aggregateTests," \u9879\u5B9E\u9645\u6D4B\u8BD5\u3001",we.validation.aggregateExecutions," \u6B21\u6267\u884C\u901A\u8FC7\u3002"]})," \u5B8C\u6574\u914D\u7F6E\u7EC4\u5408\u4E0E\u771F\u5B9E\u786C\u4EF6\u6548\u679C\u5C1A\u672A\u7A77\u5C3D\u3002",(0,m.jsx)("a",{href:"./validation-summary.json",children:"\u67E5\u770B\u5DF2\u6D4B\u8303\u56F4\u4E0E\u9A8C\u6536\u6620\u5C04\u6458\u8981"})]}):(0,m.jsxs)("p",{children:[(0,m.jsxs)("strong",{children:[c," / 30 \u9879\u63D0\u4F9B\u540C\u72B6\u6001 HA \u53CC\u4FA7\u622A\u56FE"]})," \xB7 ",f," \u9879\u8BB0\u5F55\u53CC\u4FA7\u9884\u671F\u7A7A\u767D\u3002\u5B9E\u9645\u6D4B\u8BD5\u4ECD\u5F85\u9A8C\u8BC1\uFF0C\u5F53\u524D\u72B6\u6001\uFF1A",we.status||"\u5DF2\u6355\u83B7\uFF0C\u5C1A\u672A\u5B8C\u6210\u6D4B\u8BD5\u5BA1\u6838","\u3002"]}),(0,m.jsxs)("p",{children:["\u8FD9\u662F\u9759\u6001\u5BF9\u7167\u7F51\u7AD9\uFF0C\u53EF\u6D4F\u89C8\u914D\u7F6E\u3001\u6765\u6E90\u4E0E\u8FD0\u884C\u622A\u56FE\uFF0C\u4E0D\u63A7\u5236\u8BBE\u5907\u6216\u8FD0\u884C HA \u7F16\u8F91\u5668\u3002\u539F\u7248\u57FA\u7EBF\uFF1AMushroom v5.2.3 \xB7 \u6E90\u7801\u6811 ",Bn.commit.slice(0,12),"\u3002"]}),we.validation&&(0,m.jsxs)("p",{children:[(0,m.jsx)("a",{href:"./downloads/animal-island-ha-cards.zip",download:!0,children:"\u4E0B\u8F7D\u5B8C\u6574\u624B\u52A8\u5B89\u88C5\u5305\uFF08JS + LICENSE / NOTICE / \u4F9D\u8D56\u8BB8\u53EF / \u6765\u6E90\u6E05\u5355\uFF09"})," \xB7 ",(0,m.jsx)("a",{href:"./downloads/SHA256SUMS",children:"\u6821\u9A8C ZIP SHA-256"}),(0,m.jsx)("br",{}),"\u89E3\u538B\u540E\u5C06\u5168\u5305\u590D\u5236\u5230 config/www/island-ha-cards/\uFF0C\u6DFB\u52A0 JavaScript \u6A21\u5757\u8D44\u6E90 /local/island-ha-cards/island-ha-cards.js\u3002\u5B89\u88C5\u8BF4\u660E\u5728\u5305\u5185\uFF1B\u5F53\u524D\u4E0D\u63D0\u4F9B HACS \u76F4\u63A5\u5B89\u88C5\u3002"]}),(0,m.jsxs)("div",{className:"links",children:[(0,m.jsx)("a",{href:"./fixtures.json",download:!0,children:"\u4E0B\u8F7D 30 \u9879 fixtures"}),(0,m.jsx)("a",{href:"./runtime-evidence.json",children:"\u67E5\u770B\u8FD0\u884C\u8BC1\u636E\u6E05\u5355"}),(0,m.jsx)("a",{href:"./THIRD_PARTY_NOTICES.md",children:"\u8BB8\u53EF\u4E0E\u5F52\u5C5E"})]})]}),(0,m.jsx)(of,{}),(0,m.jsxs)("section",{className:"section",children:[(0,m.jsx)("h2",{children:"\u627E\u5230\u4E00\u9879\uFF0C\u9010\u5C42\u6BD4\u8F83"}),(0,m.jsxs)("div",{className:"filters",children:[(0,m.jsxs)("div",{className:"filter-field",children:[(0,m.jsx)("span",{children:"\u7EC4\u4EF6\u7C7B\u522B"}),(0,m.jsx)(rt,{"aria-label":"\u7EC4\u4EF6\u7C7B\u522B",value:e,onChange:n,options:[{key:"all",label:"\u5168\u90E8\u7C7B\u522B"},...Object.entries(Ap).map(([h,g])=>({key:h,label:g}))]})]}),(0,m.jsxs)("div",{className:"filter-field",children:[(0,m.jsx)("span",{children:"\u72EC\u7ACB\u7EC4\u4EF6"}),(0,m.jsx)(rt,{"aria-label":"\u72EC\u7ACB\u7EC4\u4EF6",showSearch:!0,value:t,onChange:o,options:[{key:"all",label:"\u5168\u90E8 30 \u9879"},...Bn.cases.map(h=>({key:h.id,label:h.id}))]})]}),(0,m.jsxs)("div",{className:"filter-field",children:[(0,m.jsx)("span",{children:"\u72B6\u6001\u8986\u76D6\u8981\u6C42"}),(0,m.jsx)(rt,{"aria-label":"\u72B6\u6001\u8986\u76D6\u8981\u6C42",showSearch:!0,value:i,onChange:a,options:[{key:"all",label:"\u5168\u90E8\u8981\u6C42"},...[...new Set(Bn.cases.flatMap(h=>[h.initial_state,...h.states]))].sort().map(h=>({key:h,label:h}))]})]}),(0,m.jsxs)("div",{className:"filter-field",children:[(0,m.jsx)("span",{children:"HA \u5C3A\u5BF8\u5951\u7EA6"}),(0,m.jsx)(rt,{"aria-label":"HA \u5C3A\u5BF8\u5951\u7EA6",value:r,onChange:s,options:[{key:"all",label:"\u5168\u90E8\u5E03\u5C40"},{key:"grid",label:"\u5361\u7247 Sections grid"},{key:"badge",label:"\u539F\u751F badge \u5BBF\u4E3B"},{key:"flow",label:"Chips / Title \u6D41\u5F0F\u5E03\u5C40"}]})]})]}),(0,m.jsx)("p",{children:"\u72B6\u6001\u7B5B\u9009\u53EA\u7B5B\u9009\u5F85\u9A8C\u6536\u573A\u666F\uFF0C\u4E0D\u4F1A\u4F2A\u9020\u8BE5\u72B6\u6001\u622A\u56FE\u3002Sections \u7684 columns / rows \u5C5E\u4E8E HA \u7F51\u683C\u8BED\u4E49\uFF0C\u4E0D\u7B49\u540C\u4E8E\u7F51\u9875\u89C6\u53E3\u5BBD\u5EA6\u3002"}),(0,m.jsx)(ca,{onClick:()=>{n("all"),o("all"),a("all"),s("all")},children:"\u91CD\u7F6E\u7B5B\u9009"})]}),(0,m.jsxs)("p",{role:"status",className:"count",children:["\u663E\u793A ",l.length," / 30 \u9879 \xB7 \u5DE6\u53F3\u7B49\u5BBD \xB7 \u5C0F\u5C4F\u6309\u539F\u7248\u3001\u65B0\u7248\u6392\u5217"]}),l.map(h=>(0,m.jsxs)("section",{className:"section module",id:h.id.replace(":","-"),"data-module":h.id,children:[(0,m.jsxs)("div",{className:"heading",children:[(0,m.jsxs)("h2",{children:[String(Bn.cases.indexOf(h)+1).padStart(2,"0")," \xB7 ",h.name]}),(0,m.jsx)("span",{children:Ap[h.kind]})]}),(0,m.jsx)(nf,{row:h,state:i}),(0,m.jsxs)("div",{className:"facts",children:[(0,m.jsxs)("div",{children:[(0,m.jsx)("h3",{children:"\u72B6\u6001\u4E0E\u52A8\u4F5C"}),(0,m.jsx)("p",{children:h.states.join(" / ")}),(0,m.jsxs)("p",{children:["\u63A7\u4EF6\uFF1A",h.controls.join(" \xB7 ")||"\u65E0\u72EC\u7ACB\u63A7\u5236\u9879"]}),(0,m.jsxs)("p",{children:["\u670D\u52A1 / \u534F\u8BAE\uFF1A",h.services.join(" \xB7 ")||"\u4F9D\u914D\u7F6E\u53CA HA \u5BBF\u4E3B\u5904\u7406"]})]}),(0,m.jsxs)("div",{children:[(0,m.jsx)("h3",{children:"\u5C3A\u5BF8\u4E0E\u7F16\u8F91\u5668"}),(0,m.jsx)("p",{children:h.kind==="badge"?"\u72EC\u7ACB\u539F\u751F Badge\uFF1A36px \u9AD8\u5EA6\u57FA\u7EBF\uFF1B\u4E0D\u662F Chip\uFF0C\u4E0D\u8FDB\u5165 card grid\u3002":h.kind==="chip"?"\u53EA\u4F5C\u4E3A Chips \u5BB9\u5668\u5B50\u9879\uFF0C\u9075\u5B88 chip \u95F4\u8DDD\u53CA\u6362\u884C\uFF1B\u4E0D\u662F\u72EC\u7ACB\u5361\u7247\u3002":h.grid?"Sections fixture \u4F7F\u7528 columns: 6\uFF1Brows \u7531\u7EC4\u4EF6\u914D\u7F6E\u3001controls \u548C\u5E03\u5C40\u63A8\u5BFC\uFF0C\u89C1\u6E90\u7801\u65B9\u6CD5\u3002":"\u4E0A\u6E38\u6CA1\u6709 getGridOptions\uFF1B\u4E0D\u634F\u9020 6\xD71 \u8FD4\u56DE\u503C\u3002"}),(0,m.jsx)("p",{children:h.editor_contract.length?h.editor_contract.join(" \xB7 "):"\u65E0\u4E13\u7528\u7F16\u8F91\u5668\u5951\u7EA6"})]})]}),(0,m.jsxs)("details",{children:[(0,m.jsxs)("summary",{children:["\u914D\u7F6E\u5BF9\u7167 \xB7 ",h.config_keys.length," \u4E2A\u652F\u6301\u5B57\u6BB5"]}),(0,m.jsx)("p",{children:h.kind==="chip"?"\u4E0B\u5217 Chip \u901A\u8FC7 chips \u6570\u7EC4\u5D4C\u5165\u5BB9\u5668\uFF1B\u4E0D\u6CE8\u518C\u4E3A\u72EC\u7ACB Lovelace \u5361\u3002":"\u4EC5\u9876\u5C42 custom \u7C7B\u578B\u6362\u540D\uFF0C\u914D\u7F6E\u8BED\u4E49\u4FDD\u6301\u5BF9\u5E94\u3002"}),(0,m.jsx)("div",{className:"pair config",children:[h.original_config,h.island_config].map((g,x)=>(0,m.jsx)("pre",{children:JSON.stringify(g,null,2)},x))}),(0,m.jsxs)("p",{children:["\u5B8C\u6574\u5B57\u6BB5\uFF1A",h.config_keys.join(", ")]})]}),(0,m.jsxs)("details",{children:[(0,m.jsx)("summary",{children:"\u5B9E\u73B0\u8FB9\u754C\u3001\u5C3A\u5BF8\u6E90\u7801\u4E0E\u9A8C\u6536\u6CE8\u610F"}),(0,m.jsx)("ul",{children:h.details.map(g=>(0,m.jsx)("li",{children:g},g))}),Object.entries(h.sizing).map(([g,x])=>(0,m.jsxs)("div",{children:[(0,m.jsx)("h3",{children:g}),(0,m.jsx)("pre",{children:x})]},g)),(0,m.jsx)("p",{children:"\u5B57\u6BB5\u5168\u96C6\u89C1\u6E90\u7801\uFF1B\u5177\u4F53\u5DF2\u6D4B\u8303\u56F4\u89C1\u9876\u90E8\u9A8C\u8BC1\u6458\u8981\uFF0C\u4E0D\u80FD\u7531\u4E00\u5F20\u622A\u56FE\u63A8\u65AD\u6240\u6709\u914D\u7F6E\u7EC4\u5408\u3002"})]}),(0,m.jsxs)("div",{className:"links",children:[(0,m.jsx)("a",{href:h.source,children:"v5.2.3 \u7EC4\u4EF6\u6E90\u7801"}),(0,m.jsx)("a",{href:h.config_source,children:"\u914D\u7F6E\u5B9A\u4E49"}),h.editor_source&&(0,m.jsx)("a",{href:h.editor_source,children:"\u7F16\u8F91\u5668\u6E90\u7801"})]})]},h.id)),!l.length&&(0,m.jsx)(_n,{children:"\u6CA1\u6709\u5339\u914D\u9879\uFF0C\u8BF7\u8C03\u6574\u7B5B\u9009\u3002"}),(0,m.jsxs)("section",{className:"section",children:[(0,m.jsx)("h2",{children:"\u6587\u6863\u4E0E\u8FD0\u884C\u65F6\u6709\u5DEE\u5F02\u65F6\uFF0C\u4EE5\u4EE3\u7801\u4E3A\u51C6"}),(0,m.jsxs)("details",{children:[(0,m.jsxs)("summary",{children:[Bn.source_conflicts.length," \u6761\u5DF2\u8BB0\u5F55\u5DEE\u5F02"]}),(0,m.jsx)("ul",{children:Bn.source_conflicts.map(h=>(0,m.jsx)("li",{children:h.finding},h.id))})]})]}),(0,m.jsxs)("footer",{children:[(0,m.jsx)("p",{children:"\u771F\u5B9E Animal Island UI 3.0.0 \u7EC4\u4EF6\u6784\u6210\u9875\u9762\u5916\u58F3\uFF1B\u5361\u7247 fork \u4F7F\u7528 Lit \u4E0E HA \u5BBF\u4E3B\u3002"}),(0,m.jsx)("p",{children:"\u65E0\u5B57\u4F53\u4E0B\u8F7D\u3001\u65E0\u5B57\u4F53 CDN\uFF0C\u4F7F\u7528\u7CFB\u7EDF\u5B57\u4F53\u3002\u6F14\u793A\u5B9E\u4F53\u4E3A\u5408\u6210\u6570\u636E\u3002"})]})]})}(0,Mp.createRoot)(document.getElementById("root")).render((0,m.jsx)(af,{}));})();
/*! Bundled license information:

react/cjs/react.production.min.js:
  (**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

scheduler/cjs/scheduler.production.min.js:
  (**
   * @license React
   * scheduler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.min.js:
  (**
   * @license React
   * react-dom.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react/cjs/react-jsx-runtime.production.min.js:
  (**
   * @license React
   * react-jsx-runtime.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

classnames/index.js:
  (*!
  	Copyright (c) 2018 Jed Watson.
  	Licensed under the MIT License (MIT), see
  	http://jedwatson.github.io/classnames
  *)
*/
